# Cron Job Readme - cron_steps_from_csv.sh

This is the script which will be used by the cron job (has to be configured separately)
https://code.tutsplus.com/tutorials/scheduling-tasks-with-cron-jobs--net-8800


To configure the cron script, edit the following parameters with the appropriate values for the environment
DOCUMENT_GROUP_ID  - is the id of document group of the answers skill
API_SERVER  - the URL for the avaamo dashboard server
ACCESS_TOKEN  - the access token of a user with permissions to edit the answers skill
RESOURCE_PATH_LIST  - a csv file containing the list of URLs which need to be considered for the answers skill, any document in csv and not in skill will be uploaded, any document present in both the csv and the skill will be checked and updated, and no action will be taken for documents present in skill but not in csv

The RESOURCE_PATH_LIST follows the same format as of the parsing utility (check README.md)
### Retaining Training Data

All the documents present in answers skill are fetched, and the existing chunks are compared with the newly parsed chunks.
Chunks with trainig data are compared to all the new chunks and if a match is found, the training data is carried over to the new chunk and is uploaded along with the new chunks.
