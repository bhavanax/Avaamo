import datetime
import os
import re
from urllib.parse import quote, urljoin, urlparse

import colorama
import pandas as pd
from bs4 import BeautifulSoup
from lxml import etree

from commons.custom_requests import CustomRequests as requests
from logger import Logger

LOGGER = Logger(__name__)

colorama.init()
GREEN = colorama.Fore.GREEN
GRAY = colorama.Fore.LIGHTBLACK_EX
RESET = colorama.Fore.RESET

# initialize the set of links
internal_urls = set()
external_urls = set()

global_base_url = ''

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 "
    "Safari/537.36")


def is_valid(url):
    """
    Checks whether `url` is a valid URL.
    """
    parsed = urlparse(url)
    return bool(parsed.netloc) and bool(parsed.scheme)


def get_all_website_links(url):
    """
    Returns all URLs that is found on `url` in which it belongs to the same website
    """
    # all URLs of `url`
    urls = set()
    # domain name of the URL without the protocol
    #domain_name = urlparse(url).netloc
    domain_name = global_base_url
    if os.path.exists(url):
        with open(url, 'r') as f:
            html_content = f.read()
    else:
        html_content = requests.get(
            url, headers={"User-Agent": USER_AGENT}).content

    soup = BeautifulSoup(html_content, "html.parser")
    for a_tag in soup.findAll("a"):
        href = a_tag.attrs.get("href")
        if href == "" or href is None:
            # href empty tag
            continue
        # join the URL if it's relative (not absolute link)
        href = urljoin(url, href)
        parsed_href = urlparse(href)
        # remove URL GET parameters, URL fragments, etc.
        href = parsed_href.scheme + "://" + parsed_href.netloc + parsed_href.path
        if not is_valid(href):
            # not a valid URL
            continue
        if href in internal_urls:
            # already in the set
            continue
        if domain_name not in href:
            # external link
            if href not in external_urls:
                print(f"{GRAY}[!] External link: {href}{RESET}")
                external_urls.add(href)
            continue
        print(f"{GREEN}[*] Internal link: {href}{RESET}")
        urls.add(href)
        internal_urls.add(href)
    return urls


def crawl(url):
    """
    Crawls a web page and extracts all links.
    You'll find all links in `external_urls` and `internal_urls` global set variables.
    """
    links = get_all_website_links(url)
    for link in links:
        crawl(link)


def get_urls_from_base_page(base_url):
    global global_base_url
    global_base_url = base_url
    crawl(base_url)
    return external_urls, internal_urls


def generate_url_tuple_from_name(name, modified, should_crawl, base_url):
    if isinstance(should_crawl, str) and should_crawl.strip().lower() == "yes":
        if isinstance(name, str):
            loc = urljoin(base_url, quote(name.strip()))
            lastmod = datetime.datetime.utcnow().replace(
                tzinfo=datetime.timezone.utc).isoformat()
            if isinstance(modified, str):
                time_format = "%m/%d/%Y %I:%M %p"
                lastmod = datetime.datetime.strptime(
                    modified.strip(), time_format
                ).replace(tzinfo=datetime.timezone.utc).isoformat()
            return [loc, lastmod]
    return None


def generate_url_tuple_from_html_file(url, file_path, focus_element_xpath=None):

    with open(file_path, "r") as html_file:
        url_soup = BeautifulSoup(html_file, "html.parser")

    if focus_element_xpath:
        dom = etree.HTML(str(url_soup))
        url_soup = BeautifulSoup(''.join([
            etree.tostring(element).decode("utf-8") for element in dom.xpath(focus_element_xpath)]))

    all_urls = list({
        urljoin(url, anchor.get("href")) for anchor in url_soup.find_all('a')
        if anchor.get("href")})

    base_hostname = urlparse(url).hostname or ""
    all_urls = [
        [current_url, datetime.datetime.now()] if base_hostname in current_url else None
        for current_url in all_urls]

    return all_urls


def get_urls_from_sitemap(
        base_url, filter_criteria=None, sitemap_csv_path=None,
        focus_element_xpath=None):
    _external_urls = []

    if not sitemap_csv_path:
        LOGGER.info(f"Crawling sitemap URL: {base_url}")
        soup = BeautifulSoup(requests.get(
            base_url, headers={"User-Agent": USER_AGENT}).content, "html.parser")
        LOGGER.debug(f"soup {soup}")
        _internal_urls = [
            [tag.text, tag.parent.lastmod.text]
            for tag in soup.find_all('loc', string=re.compile("https://.*"))
        ]
    else:
        LOGGER.info(f"Processing sitemap CSV: {sitemap_csv_path}")
        sitemap_df = pd.read_csv(sitemap_csv_path)
        if ("Name" in sitemap_df.columns and "Modified" in sitemap_df.columns
                and "Crawl" in sitemap_df.columns):
            _internal_urls = sitemap_df.apply(lambda row: generate_url_tuple_from_name(
                row["Name"], row["Modified"], row["Crawl"], base_url), axis=1)
        elif "Path" in sitemap_df.columns and "Local Path" in sitemap_df.columns:
            _internal_urls = sitemap_df.apply(lambda row: generate_url_tuple_from_html_file(
                row["Path"], row["Local Path"], focus_element_xpath), axis=1)
            _internal_urls = [
                url for internal_urls_list in _internal_urls for url in internal_urls_list]
        else:
            raise ValueError(
                f"Got sitemap CSV with columns {list(sitemap_df.columns)}. "
                "Expected ['Name', 'Modified', 'Crawl'] or ['Path', 'Local Path']"
            )
        _external_urls += [url for url in _internal_urls if url is None]
        _internal_urls = [url for url in _internal_urls if url is not None]

    if filter_criteria is not None:
        filter_criteria = r'' + filter_criteria
        LOGGER.info(f"Filtering URLs from sitemap using '{filter_criteria}'")
        _external_urls += [
            url for url in _internal_urls if not re.search(filter_criteria, url[0])]
        _internal_urls = [url for url in _internal_urls if re.search(
            filter_criteria, url[0])]

    return _external_urls, _internal_urls


def crawl_base_url(
        base_url, save_path="urls.csv", is_sitemap=False, nested_sitemap_filter_criteria=None,
        filter_criteria=None, sitemap_csv_path=None,
        focus_element_xpath=None):

    if is_sitemap:
        if ".nested." in base_url:
            _external_urls, _internal_urls = get_urls_from_sitemap(
                base_url, nested_sitemap_filter_criteria, sitemap_csv_path, focus_element_xpath)

            all_internal_urls = []
            for url, _mod in _internal_urls:
                _external_urls, _internal_urls = get_urls_from_sitemap(
                    url, filter_criteria, sitemap_csv_path, focus_element_xpath)

                all_internal_urls += _internal_urls

        else:
            _external_urls, _internal_urls = get_urls_from_sitemap(
                base_url, filter_criteria, sitemap_csv_path, focus_element_xpath)

            all_internal_urls = _internal_urls

        urls_csv = pd.DataFrame(all_internal_urls, columns=['Path', 'Lastmod'])

    else:
        _external_urls, _internal_urls = get_urls_from_base_page(base_url)
        urls_csv = pd.DataFrame(_internal_urls, columns=['Path'])

    LOGGER.info("[+] Total External links:", len(_external_urls))
    LOGGER.info("[+] Total Internal links:", len(_internal_urls))
    LOGGER.info("[+] Total:", len(_external_urls) + len(_internal_urls))

    urls_csv.to_csv(save_path, index=False)
