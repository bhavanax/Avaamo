import json
import os
from kp_manager.api_helper import APIHelper, LOGGER
from document_parsing_lib.nlp.text_normalizer import EnglishTextNormalizer
from logger import Logger

LOGGER = Logger(__name__)


class JobHandler:
    def __init__(self, document_group_id, api_server, access_token, parsed_docs_path, extra_doc_group_ids=None):
        extra_doc_group_ids = extra_doc_group_ids or list()
        self.document_group_id = document_group_id
        self.api_server = api_server
        self.access_token = access_token
        self.api_helper = APIHelper(api_server, access_token, document_group_id)
        self.workdir = os.path.dirname(os.path.abspath(parsed_docs_path))
        self.agent_kp_apis = [
            APIHelper(api_server, access_token, document_group_id=doc_group_id)
            for doc_group_id in extra_doc_group_ids if int(doc_group_id) != int(document_group_id)]
        with open(parsed_docs_path, "r") as f:
            self.parsed_docs = json.load(f)

    def fetch_documents_from_kp(self):
        all_documents = self.api_helper.fetch_documents()
        for kp_api in self.agent_kp_apis:
            all_documents += kp_api.fetch_documents()

        url_documents = {}
        for doc in all_documents:
            if doc["document_type"] == "url":
                url_documents[doc["source_url"]] = doc

        self.url_documents = url_documents

    def evaluate_documents(self):
        LOGGER.debug(f"Starting document evaluation")
        deleted_training_data_documents = []
        for url, new_doc_data in self.parsed_docs.items():

            try:
                doc = self.url_documents[url]
                LOGGER.debug(f"Evaluation doc {doc['id']}")
            except KeyError:
                LOGGER.debug(f"Uploading new document {url}")
                self.upload_new_chunks(new_doc_data)
                continue

            doc_dashboard_chunks = self.api_helper.fetch_document_chunks(
                doc['id'])

            doc_new_chunks = new_doc_data["chunks"]

            is_doc_changed, has_training_data = self.compare_doc_chunks(
                doc_dashboard_chunks, doc_new_chunks)

            if not is_doc_changed:
                LOGGER.debug(
                    f"Doc is not changed {doc['id']} | Sending process request")

            if has_training_data:
                LOGGER.debug(f"Doc has training data {doc['id']}")
                new_chunks, deleted_training_data_chunks = self.copy_training_data(
                    doc_dashboard_chunks, doc_new_chunks)
                new_doc_data["chunks"] = new_chunks

                if deleted_training_data_chunks:
                    doc_copy = doc.copy()
                    doc_copy["chunks"] = deleted_training_data_chunks
                    deleted_training_data_documents.append({
                        "document": doc_copy
                    })

            self.upload_new_chunks(new_doc_data)

        if deleted_training_data_documents:
            json_file_path = os.path.join(self.workdir, f"{self.document_group_id}_deleted_training_data.json")
            with open(json_file_path, 'w') as json_file:
                json.dump({
                    "document_group_id": self.document_group_id,
                    "instance": self.api_server,
                    "documents": deleted_training_data_documents
                }, json_file)
            LOGGER.warning((
                f"Dropped training data in {len(deleted_training_data_documents)} document. "
                f"Logged deleted data in {json_file_path}"
            ))

    def get_new_doc_data(self, doc):
        if doc["url"] in self.parsed_docs:
            return self.parsed_docs[doc["url"]]
        else:
            return None

    def compare_doc_chunks(self, old_chunks, new_chunks):
        has_training_data = False
        for chunk in old_chunks:
            if len(chunk["training_data"]) > 0:
                has_training_data = True
                break

        is_doc_changed = False
        if len(old_chunks) != len(new_chunks):
            is_doc_changed = True
        else:
            for old_chunk, new_chunk in zip(old_chunks, new_chunks):
                if old_chunk["text"] != new_chunk["text"]:
                    is_doc_changed = True
                    break

        return is_doc_changed, has_training_data

    def copy_training_data(self, old_chunks, new_chunks):
        text_normalizer = EnglishTextNormalizer()
        new_chunks_text = [
            text_normalizer.preprocess(
                chunk["text"], tokenize=False, stem=False,
                remove_stop_words=False, convert_numbers=False)
            for chunk in new_chunks
        ]
        deleted_training_data_chunks = []
        for old_chunk in old_chunks:
            training_data = old_chunk["training_data"]
            if len(training_data) == 0:
                continue

            training_data = [data["text"] for data in training_data]

            old_chunk_text = text_normalizer.preprocess(
                old_chunk["text"], tokenize=False, stem=False,
                remove_stop_words=False, convert_numbers=False)
            matching_chunk_found = False
            for i, new_chunk in enumerate(new_chunks):
                if old_chunk_text == new_chunks_text[i]:
                    new_chunk["training_data"] = training_data
                    matching_chunk_found = True
                    LOGGER.debug(
                        f"Training data copied for chunk {old_chunk['id']}")
                    break

            if not matching_chunk_found:
                LOGGER.debug(
                    f"No chunk match found for training data copy {old_chunk['id']}")
                deleted_training_data_chunks.append(old_chunk)

        return new_chunks, deleted_training_data_chunks

    def upload_new_chunks(self, doc_data):
        LOGGER.info(f"Updating document {doc_data['name']}")
        _response, _ = self.api_helper.import_document(doc_data)
