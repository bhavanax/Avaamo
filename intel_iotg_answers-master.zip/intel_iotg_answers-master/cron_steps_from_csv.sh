export PATH=/Users/varunagarwal/.local/bin:~/.asdf/shims/:/usr/local/sbin:/Users/varunagarwal/.asdf/shims:/usr/local/opt/asdf/bin:/opt/local/bin:/opt/local/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/munki:/Library/Apple/usr/bin:/Users/varunagarwal/.local/bin
python --version
DOCUMENT_GROUP_ID=7180
API_SERVER=https://m2.avaamo.com
ACCESS_TOKEN=xxxxxxxxxxxxxx
PARSING_TEMPLATE_ID=6
RESOURCE_PATH_LIST=output/documents_classes.csv
RESOURCE_TYPE=url

OUTPUT_PATH=${API_SERVER}_${DOCUMENT_GROUP_ID}_$(date +"%d_%m_%Y_%H_%M_%S")
OUTPUT_PATH=$(echo "$OUTPUT_PATH" | sed 's/[^a-zA-Z0-9_]//g')

echo "Ensuring output dir is clean" $OUTPUT_PATH
mkdir $OUTPUT_PATH
rm -rf $OUTPUT_PATH/*

# For authenticated URLs, uncomment next 4 lines
# echo "Running Authentication Script"
# python authenticator.py -c auth_config.txt --output_path $OUTPUT_PATH --resource_path_list $RESOURCE_PATH_LIST
# RESOURCE_PATH_LIST=${OUTPUT_PATH}/resource_list_local_paths.csv
# RESOURCE_TYPE=html

echo "" > tmpconfig.txt

echo "Running Parsing Script"
./run_parsing -c tmpconfig.txt --resource_type $RESOURCE_TYPE --resource_path_list $RESOURCE_PATH_LIST --output_path $OUTPUT_PATH --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN --parsing_template_id $PARSING_TEMPLATE_ID Parse

echo "Running Documents Update Script"
python document_update_controller.py --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN --parsed_documents_dir $OUTPUT_PATH