DOCUMENT_GROUP_ID=1111
API_SERVER=https://abc.avaamo.com
ACCESS_TOKEN=avaamo_access_token
BASE_URL=https://www.example.com/site/pages/base/url/
IS_SITEMAP_URL=true
SITEMAP_FILTER_CRITERIA=filtering_criteria_regex_for_url
SITEMAP_CSV_FILE_NAME=name_of_sitemap_file.csv
RESOURCE_TYPE=url

SITEMAP_URL=https://www.example.com/path/to/sitemap/table/page


LOGIN_METHOD=your-login-method
USERNAME=your-email@example.com
PASSWORD=SomeStrongP@ssword
USE_SECURE_TOKEN=true
CLICK_ELEMENT_XPATH=xpath_to_download_button

OUTPUT_PATH=${API_SERVER}_${DOCUMENT_GROUP_ID}_$(date +"%d_%m_%Y_%H_%M_%S")
OUTPUT_PATH=output/$(echo "$OUTPUT_PATH" | sed 's/[^a-zA-Z0-9_]//g')

echo "Ensuring output dir is clean" $OUTPUT_PATH
mkdir $OUTPUT_PATH
rm -rf $OUTPUT_PATH/*

# For authenticated Sitemap
echo "Running Authentication Script for Sitemap..."

SITEMAP_RESOURCE_PATH=$OUTPUT_PATH/sitemap_url.csv

printf "Path\n${SITEMAP_URL}" > $SITEMAP_RESOURCE_PATH

echo "" > tmpauthconfig.txt
python authenticator.py -c tmpauthconfig.txt --output_path $OUTPUT_PATH --resource_path_list $SITEMAP_RESOURCE_PATH --login_method $LOGIN_METHOD --username $USERNAME --password $PASSWORD --use_secure_token $USE_SECURE_TOKEN --click_element_xpath $CLICK_ELEMENT_XPATH

echo "" > tmpconfig.txt

echo "Running Document Crawling and Classification Script..."
./run_parsing -c tmpconfig.txt --resource_type $RESOURCE_TYPE --base_url $BASE_URL --is_sitemap_url $IS_SITEMAP_URL --sitemap_csv_file_name $SITEMAP_CSV_FILE_NAME --output_path $OUTPUT_PATH --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN Crawl Classify Delete

# For authenticated URLs
echo "Running Authentication..."

SITE_PATH_LIST=$OUTPUT_PATH/documents_classes.csv

echo "" > tmpauthconfig.txt
python authenticator.py -c tmpauthconfig.txt --output_path $OUTPUT_PATH --resource_path_list $SITE_PATH_LIST --login_method $LOGIN_METHOD --username $USERNAME --password $PASSWORD --use_secure_token $USE_SECURE_TOKEN


echo "Running Document Parsing Script..."
echo "" > tmpconfig.txt
RESOURCE_PATH_LIST=$OUTPUT_PATH/html_paths.csv
RESOURCE_TYPE=html

./run_parsing -c tmpconfig.txt --resource_type $RESOURCE_TYPE --resource_path_list $RESOURCE_PATH_LIST --output_path $OUTPUT_PATH --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN Parse

echo "Running Documents Update Script"
python document_update_controller.py --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN --parsed_documents_dir $OUTPUT_PATH
