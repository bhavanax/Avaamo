import codecs
import json
import os

import platform
import multiprocessing
import configargparse
import pandas as pd
from commons.custom_requests import CustomRequests as requests
from logger import Logger

import crawler
from kp_manager.categorise_documents import CategoriseDocuments
from parsing_manager import ParsingManager

LOGGER = Logger(__name__)


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise TypeError('Boolean value expected.')


def main():

    parser = configargparse.ArgParser()

    parser.add(
        "-c", "--config", required=True, is_config_file=True, help="config file path"
    )
    parser.add(
        "pipeline",
        nargs="+",
        type=str,
        metavar="STEP",
        choices=["Crawl", "Classify", "Delete", "Parse", "Learn", "Upload"],
        help="The step(s) of pipeline that you want the program to run.",
    )
    parser.add(
        "--resource_path",
        default=None,
        type=str,
        help="The URL of the website/local file path of the document that needs to be parsed",
    )
    parser.add(
        "--resource_path_list",
        default=None,
        type=str,
        help="Local file path to the file that contains a list of URLs/list of local file paths for documents that need to be parsed",
    )
    parser.add(
        "--resource_type",
        default=None,
        choices=["html", "url", "xls", "csv", "pptx",
                 "zip", "plain", "doc", "txt", "pdf"],
        type=str,
        help="The type of the resource you want to parse. Eg. url/pdf/txt/xls",
    )
    parser.add(
        "--chunks_path",
        default=None,
        type=str,
        help="Local file system path to chunks that you want to upload",
    )
    parser.add(
        "--base_url",
        default=None,
        type=str,
        help="Provide the base url you would like to extract all the related urls and document chunks from",
    )
    parser.add(
        "--is_sitemap_url",
        default=False,
        type=str2bool,
        help="Whether the given base_url is a path to a sitemap.xml",
    )
    parser.add(
        "--sitemap_filter_criteria",
        default=None,
        type=str,
        help="Regular Expression that URLs from sitemap should match with",
    )
    parser.add(
        "--nested_sitemap_filter_criteria",
        default=None,
        type=str,
        help="Regular Expression that sitemaps from nested sitemap should match with",
    )
    parser.add(
        "--sitemap_csv_file_name",
        default=None,
        type=str,
        help="File name of sitemap csv file, defaults to None",
    )
    parser.add(
        "--focus_element_xpath",
        default=None,
        type=str,
        help="XPATH of the main content to extract urls from in base html file, defaults to None",
    )
    parser.add(
        "--output_path",
        default=None,
        type=str,
        required=True,
        help="Path to the output dir where results will be stored",
    )
    parser.add(
        "--language",
        default="en-US",
        choices=["en-US", "ko-KR"],
        type=str,
        help="The language of the documents to be processed",
    )

    parser.add(
        "--parsing_template",
        default=None,
        type=str,
        help="A text file containing the parsing template to be used for parsing the document/url",
    )
    parser.add(
        "--parsing_template_key",
        default="cli_parser_tool",
        type=str,
        help="A key for the template to be used for parsing the document/url. Leave it un-set if not sure what to put.",
    )
    parser.add(
        "--parsing_template_id",
        default=0,
        type=int,
        help="Parsing Template ID to be added to the documents to upload. The parsing template used for parsing needs to be added to the skill and its ID needs to be used here.",
    )
    parser.add(
        "--add_preview_url",
        default=False,
        type=str2bool,
        help="Whether the parser should extract preview url for each chunk or not (applicable only for URLs and HTMLs). Should be a boolean value.",
    )
    parser.add(
        "--index_pages",
        default=0,
        type=int,
        help="Number of index pages in document. Applicable for PDFs.",
    )

    parser.add(
        "--access_token", default=None, type=str, help="Access Token",
    )
    parser.add(
        "--instance",
        default=None,
        type=str,
        help="URL to the instance where the documents should be uploaded. Ex. https://c7.avaamo.com",
    )
    parser.add(
        "--document_group_id", default=None, type=str, help="Document Group ID",
    )
    parser.add(
        "--pool_size", default=1, type=int, help="Number of processes"
    )
    parser.add(
        "--parsing_lib", default="pdfbox", type=str, help="Document parsing lib"
    )

    args = parser.parse_args()

    # Validate pipeline and raise errors if required
    if "Crawl" in args.pipeline and "Upload" in args.pipeline and not "Parse" in args.pipeline:
        raise Exception(
            "'Parse' step skipped. Pipeline needs to be continuous.")

    # Ensure proper output path for storing result files
    if not args.output_path:
        raise IOError(
            f"Invalid output path '{args.output_path}'. Please provide a valid output path."
        )
    if os.path.exists(args.output_path):
        if not os.path.isdir(args.output_path):
            raise IOError(
                f"The provided output path '{args.output_path}' is not a directory."
            )
    else:
        os.makedirs(args.output_path)
    output_path = os.path.abspath(args.output_path)
    LOGGER.debug(f"Using output path '{output_path}'")

    # Prepare the default parsing template based on user inputs
    parsing_template = {}
    parsing_template_path = args.parsing_template
    if "Parse" in args.pipeline and parsing_template_path:
        with open(parsing_template_path, "r") as json_file:
            parsing_template["template_json"] = json.load(json_file)
        LOGGER.debug(
            f"Using parsing template from file '{parsing_template_path}'")
    else:
        parsing_template["template_json"] = None
        LOGGER.debug(f"Using parsing template 'None'")
    parsing_template["key"] = args.parsing_template_key
    LOGGER.debug(f"Using parsing template key '{args.parsing_template_key}'")

    # Prepare default paths
    default_resource_path_list = os.path.join(output_path, "urls.csv")
    default_chunks_path = os.path.join(output_path, "chunks.json")
    default_resource_type = "url"

    sitemap_csv_path = None
    if args.sitemap_csv_file_name:
        sitemap_csv_path = os.path.join(args.output_path, args.sitemap_csv_file_name)

    # Start Pipeline
    if "Crawl" in args.pipeline:
        if args.base_url:
            LOGGER.info(f"Starting to crawl '{args.base_url}'")

            crawler.crawl_base_url(
                args.base_url,
                save_path=default_resource_path_list,
                is_sitemap=args.is_sitemap_url,
                nested_sitemap_filter_criteria=args.nested_sitemap_filter_criteria,
                filter_criteria=args.sitemap_filter_criteria,
                sitemap_csv_path=sitemap_csv_path,
                focus_element_xpath=args.focus_element_xpath
            )
        else:
            raise Exception("Please provide a valid base_url to crawl.")

    if "Classify" in args.pipeline:
        verify_user_config(args.access_token, args.instance,
                           args.document_group_id)
        categorise_documents = CategoriseDocuments(
            args.document_group_id, args.instance, args.access_token, output_path)

        path = args.resource_path_list or default_resource_path_list
        categorise_documents.compare_documents_from_csv(path=path)
        classes_path = os.path.join(output_path, 'documents_classes.csv')
        default_resource_path_list = classes_path

    if "Delete" in args.pipeline:
        verify_user_config(args.access_token, args.instance,
                           args.document_group_id)
        categorise_documents = CategoriseDocuments(
            args.document_group_id, args.instance, args.access_token, output_path)

        path = args.resource_path_list or default_resource_path_list
        categorise_documents.delete_documents(path=path)

    if "Parse" in args.pipeline:

        resource_type = args.resource_type
        if not args.language:
            raise Exception(
                f"No language provided. Unable to parse documents.")
        if not resource_type:
            raise Exception(
                f"No resource type provided. Unable to parse documents.")

        parsing_template_id = args.parsing_template_id
        if parsing_template_id is None:
            raise Exception(
                "Parsing Template ID is required for parsing documents")

        resource_path_list = args.resource_path_list or default_resource_path_list
        pool_size = args.pool_size

        if args.resource_path_list or not args.resource_path:
            if os.path.exists(resource_path_list):
                LOGGER.info(
                    f"Found valid path to list of resources '{resource_path_list}'. Starting parsing procedure."
                )
                resource_path_list = os.path.abspath(resource_path_list)
            else:
                raise IOError(
                    f"Found invalid path to list of resources '{resource_path_list}' Please provide a valid path."
                )
            summaries, documents = ParsingManager.parse_documents_bulk(
                resource_path_list, parsing_template, args.language, resource_type, args.index_pages, parsing_template_id,
                add_preview_url=args.add_preview_url, pool_size=pool_size, parsing_lib=args.parsing_lib
            )

        elif args.resource_path:
            if os.path.exists(args.resource_path):
                LOGGER.info(
                    f"Found valid path to resource '{args.resource_path}'. Starting parsing procedure."
                )
                resource_path = os.path.abspath(args.resource_path)

            elif requests.get(args.resource_path).status_code in (200, 201, 401, 403):
                LOGGER.info(
                    f"Found valid URL '{args.resource_path}'. Starting parsing procedure."
                )
                resource_path = args.resource_path
            else:
                raise IOError(
                    f"Found invalid path to resource '{args.resource_path}' Please provide a valid path."
                )
            summaries, documents = ParsingManager.parse_document(
                resource_path, resource_type, parsing_template, args.language, None, None, None, args.index_pages, parsing_template_id,
                add_preview_url=args.add_preview_url, parsing_lib=args.parsing_lib
            )
            summaries = [summaries]

        else:
            raise Exception(
                "Please provide a valid resource_path or resource_path_list to parse.")

        summary_path = os.path.join(output_path, "summary.csv")
        pd.DataFrame(summaries).to_csv(summary_path)
        LOGGER.debug(f"Saved summary file to '{summary_path}'")

        with codecs.open(default_chunks_path, "w") as json_file:
            json.dump(documents, json_file, indent=4)
        LOGGER.debug(f"Saved documents file to '{default_chunks_path}'")

    if "Learn" in args.pipeline:
        chunks_path = args.chunks_path or default_chunks_path
        if chunks_path and os.path.exists(chunks_path):
            LOGGER.info(
                f"Found valid path to chunks '{chunks_path}'. Starting chunk learning procedure."
            )
        else:
            raise IOError(
                (f"Found invalid path to chunks '{chunks_path}'"
                 " Please provide a valid path in order to learn from chunks.")
            )
        chunks_path = os.path.abspath(chunks_path)
        learnt_documents = ParsingManager.learn_from_documents(
            chunks_path, args.language)
        with codecs.open(default_chunks_path, "w") as json_file:
            json.dump(learnt_documents, json_file, indent=4)
        LOGGER.debug(f"Saved documents file to '{default_chunks_path}'")

    if "Upload" in args.pipeline:
        pool_size = args.pool_size
        verify_user_config(args.access_token, args.instance,
                           args.document_group_id)

        chunks_path = (
            args.chunks_path or default_chunks_path
            if "Learn" not in args.pipeline else default_chunks_path
        )
        if chunks_path and os.path.exists(chunks_path):
            LOGGER.info(
                f"Found valid path to chunks '{chunks_path}'. Starting chunk upload procedure."
            )
        else:
            raise IOError(
                (f"Found invalid path to chunks '{chunks_path}'"
                 " Please provide a valid path in order to upload chunks.")
            )
        chunks_path = os.path.abspath(chunks_path)
        status_dictionary = ParsingManager.upload_chunks(
            chunks_path, args.instance, args.access_token, args.document_group_id, pool_size=pool_size
        )
        status_path = os.path.join(output_path, "upload_status.csv")
        dict_to_df(status_dictionary).to_csv(status_path)

    LOGGER.info("----- COMPLETED -----")


def dict_to_df(status_dictionary):
    transposed_dict = {}
    transposed_dict['Path'] = list(status_dictionary.keys())
    transposed_dict['Status'] = list(status_dictionary.values())
    return pd.DataFrame(transposed_dict)


def verify_user_config(access_token, instance, document_group_id):
    if not access_token:
        raise Exception(f"No access token provided. Unable to upload chunks.")
    if not instance:
        raise Exception(f"No instance provided. Unable to upload chunks.")
    if not document_group_id:
        raise Exception(f"No KP-ID provided. Unable to upload chunks.")


if __name__ == "__main__":
    if platform.system() == "Darwin":
        multiprocessing.set_start_method('spawn')
    main()
