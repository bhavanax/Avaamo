DOCUMENT_GROUP_ID=1111
API_SERVER=https://abc.avaamo.com
ACCESS_TOKEN=avaamo_access_token
BASE_URL=https://www.example.com/sitemap.xml
PARSING_TEMPLATE_ID=6
IS_SITEMAP_URL=true
SITEMAP_FILTER_CRITERIA=filtering_criteria_regex_for_url
RESOURCE_TYPE=url

OUTPUT_PATH=${API_SERVER}_${DOCUMENT_GROUP_ID}_$(date +"%d_%m_%Y_%H_%M_%S")
OUTPUT_PATH=output/$(echo "$OUTPUT_PATH" | sed 's/[^a-zA-Z0-9_]//g')

echo "Ensuring output dir is clean" $OUTPUT_PATH
mkdir $OUTPUT_PATH
rm -rf $OUTPUT_PATH/*

# For authenticated URLs, uncomment next 4 lines
# echo "Running Authentication Script"
# python authenticator.py -c auth_config.txt --output_path $OUTPUT_PATH --resource_path_list $RESOURCE_PATH_LIST
# RESOURCE_PATH_LIST=${OUTPUT_PATH}/resource_list_local_paths.csv
# RESOURCE_TYPE=html

echo "" > tmpconfig.txt

echo "Running Parsing Script"
./run_parsing -c tmpconfig.txt --resource_type $RESOURCE_TYPE --base_url $BASE_URL --is_sitemap_url $IS_SITEMAP_URL --sitemap_filter_criteria $SITEMAP_FILTER_CRITERIA --output_path $OUTPUT_PATH --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN --parsing_template_id $PARSING_TEMPLATE_ID Crawl Classify Delete Parse

echo "Running Documents Update Script"
python document_update_controller.py --instance $API_SERVER --document_group_id $DOCUMENT_GROUP_ID --access_token $ACCESS_TOKEN --parsed_documents_dir $OUTPUT_PATH