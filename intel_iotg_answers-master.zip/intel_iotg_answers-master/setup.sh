#Get Virtualenv
pip install virtualenv 
virtualenv -p python document_parsing

#Activate env
source document_parsing/bin/activate

#Install PyPi packages
document_parsing/bin/pip install -r requirements.txt

#Get required nltk packages
python -m nltk.downloader stopwords
python -m nltk.downloader punkt
python -m nltk.downloader wordnet

#Get SpaCy models
python -m spacy download en_core_web_md

