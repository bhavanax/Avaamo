# Document Parsing

A powerful tool which crawls all the URLs from the base URL, parses these URLs to get appropriate chunks/sections and then uploads them to an instance of your choice!

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

#### Python Installation

Please make sure you have Python 3.6.9 or a higher version. You can follow the steps in the following link if you don't already have it.

[https://realpython.com/installing-python/](https://realpython.com/installing-python/)

#### JAVA Installation

Please make sure you have JAVA openjdk-11.0.1. You can follow the steps in the following link if you don't already have it.

[https://openjdk.java.net/install/](https://openjdk.java.net/install/)

#### PIP Installation

Follow the steps in the following link to get pip.

[https://pip.pypa.io/en/stable/installing/](https://pip.pypa.io/en/stable/installing/)

### Setup

The setup.sh script will download the required packages and models needed for running the tool.
To run the setup file run the following command in the folder where setup.sh file is present:-

```
bash setup.sh
```

This will create a virtual environment named 'document_parsing' in the same folder where you run the command, and install the packages in the environment, to avoid conflicts with packages on your local system.


## Running the script

To run the tests, you need to get into the virtual environment which has all the packages downloaded. To do this, run the following command in the same directory where you ran `bash setup.sh`

```
source document_parsing/bin/activate
```

> **_NOTE:_** If the content you want to parse requires authentication, follow the [instructions for authentication](#authenticating) before running the parsing script.

Once you are in the virtual environment, you are ready to run the command line parsing tool! For help on running the script run:
```
./run_parsing -h
```


### Arguments for the Config File

The config file will contain all the arguments needed to be passed to the parsing tool. Here is a list of arguments you can put in the config file.

| Argument | Description | Mandatory (yes/no) | Default value if not specified |
| --- | --- | --- | --- |
| **resource_type** | The choices you have are "html", "url", "xls", "csv", "zip", "plain", "doc", "txt", "pdf" | Yes for Crawl; Parse; Crawl and Parse; Crawl,Parse and Upload | None |
| **resource_path** | The URL of the website/local file path of the document that needs to be parsed  | Yes for Parse | None |
| **resource_path_list** | If multiple URLs/PDFs need to be parsed, provide the csv which contains these URLs/PDFs | Yes for Parse | None |
| **language**  | You can choose English or Korean. For english, choose - "en-US", for Korean, choose - "ko-KR" | No | English |
| **parsing_template** | A json file containing the parsing template to be used for parsing the document/url. Providing a customer template helps us parse the files better. | No | Default PDF file Parser |
| **add_preview_url** | Whether the parser should extract preview url for each chunk or not (applicable only for URLs and HTMLs). Should be a boolean value. | No | False |
| **base_url** | Provide the base URL you would like to extract all the related URLs from | Yes for Crawl | None |
| **chunks_path** | Local file system path where the chunks are stored | Yes for Upload | None |
| **instance** | The Avaamo instance where you would like to upload the chunks. for eg. https://m2.avaamo.com | Yes for Upload; Parse and Upload; Crawl, Parse and Upload | None |
| **access_token** | User Access Token | Yes for Upload; Parse and Upload; Crawl, Parse and Upload | None |
| **document_group_id** | ID of the document group you would like to upload the chunks in | Yes for Upload; Parse and Upload; Crawl, Parse and Upload | None |
| **parsing_template_id** | ID of parsing template for document. Can be found in Parsing Templates inside Skill | Yes | None |
| **output_path** | Local file system folder path where you'd like to save the chunks, summary csv and csv containing all the scraped URLs | Yes for all operations | None |
| **parsing_template_key** | A key for the template to be used for parsing the document/url. Leave it un-set if not sure what to put. | No | None |
| **index_pages** | Number of index pages in document. Applicable for PDFs. | No | None |

### Crawl - Crawling Base URL

* Here is an example config.txt to just crawl all the embedded URLs in a base URL, and NOT generate chunks,

```
resource_type=url
base_url=https://docs.avaamo.com/v5/
output_path=results
```

* To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Crawl
```

Since here, we want to crawl all the URLs only, we pass Crawl argument. The **-c** argument requries you to give a config.txt, which contains all the arguments you wish to pass to the pipeline. Additionally you can provide the arguments to run the part of the pipeline you would like, Crawl, Parse or/and Upload.

* **Output** - A csv file containing all the crawled urls will get generated in the results directory.

### Parse - Parsing URLs to get chunks

* If you want to get chunks from a single url and not upload them to an instance, here is an example config.txt,

```
resource_type=url
resource_path=https://docs.avaamo.com/v5/
output_path=results
parsing_template=parsing_template.json
```

* If you have multiple URLs/documents, then make a csv with 1 column called **Path**, which contains URLs or the local file system path to PDFs that need to be processed, and use the following config.txt,

```
resource_type=url
resource_path_list=results/urls.csv
output_path=results
parsing_template=parsing_template.json
```

* To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Parse
```

Since here, we want to parse the URLs only, we pass Parse argument.

* **Output** - A json file containing all the parsed chunks will get generated in the results directory.


### Parse - Parsing saved HTMLs to get chunks


* The HTMLs csv should contain 2 columns called **Path** and **Local Path**. **Path** Column should contain the URL of the HTML page. **Local Path** should contain the local file system path where the content of the HTML that need to be processed, is saved, and use the following config.txt,

```
resource_type=html
resource_path_list=results/htmls.csv
output_path=results
parsing_template=parsing_template.json
```

* To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Parse
```

Since here, we want to parse the URLs only, we pass Parse argument.

* **Output** - A json file containing all the parsed chunks will get generated in the results directory.


### Upload - Uploading chunks to an instance

* Example config.txt to upload the chunks to an instance :-

```
chunks_path=results/chunks.json
instance=https://m2.avaamo.com
access_token=xxxxxxxxxxxxxxxxx
document_group_id=xx
parsing_template_id=6
output_path=results
```

To run the parsing tool, run the following command :-

* **Output** - The Answers Skill for the kp_id given, will get populated with chunks in knowledge tab.


```
./run_parsing -c config.txt Upload
```

Since here, we want to only upload chunks to the instance, we only pass Upload argument.

### Crawl and Parse

* If you'd like to crawl all the embedded URLs and get their chunks too, here is an example config.txt,

```
resource_type=url
base_url=https://docs.avaamo.com/v5/
output_path=results
parsing_template=parsing_template.json
```

To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Crawl Parse
```

Since here, we want to crawl and parse the URLs, we pass Crawl and Parse arguments.

### Parse and Upload

* Example config.txt to get chunks from a urls csv and upload the chunks to an instance :-

```
resource_type=url
resource_path_list=results/urls.csv
output_path=results
instance=https://m2.avaamo.com
access_token=xxxxxxxxxxxxxxxxx
document_group_id=xx
parsing_template_id=6
parsing_template=parsing_template.json
```

To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Parse Upload
```

Since here, we want to crawl and parse the URLs, and then upload the chunks to an instance, we pass Crawl, Parse and Upload arguments.

The URLs csv, will have 1 compulsory column called **Path**, which contains URL or the local file system path to a PDF that needs to be processed. Other than this column, there are 6 additional optional columns, namely <br>
**Custom Response** (The response of the URL html, whether it is html format or json format),<br>
**Auth Token** (To provide access to the URL if permission is required),<br>
**Document Options** (Similar field to the one in UI, if unsure, leave blank/do not include column),<br>
**Index Pages** (Relavent for PDFs),<br>
**Parsing Template** (The Parsing Template you'd like to use for the particular resource provided in the Path Column),<br>
**Parsing Template Key** (The Parsing Template Key, if unsure, leave empty, or do not add the column).

**If you are unsure of any column or their use, please do not include that column in the csv**

### Crawl, Parse and Upload -- Running the whole pipeline

* If you'd like to run the whole pipeline, which is crawl all the URLs, get their chunks and upload these chunks to an instance, here is an example config.txt,

```
resource_type=url
base_url=https://docs.avaamo.com/v5/how-to/build-skills/create-skill/using-avaamo-answers-1/manage-avaamo-answers-1
output_path=results
instance=https://m2.avaamo.com
access_token=xxxxxxxxxxxxxxxxx
document_group_id=xx
parsing_template_id=6
parsing_template=parsing_template.json
```

To run the parsing tool, run the following command :-

```
./run_parsing -c config.txt Crawl Parse Upload
```

Since here, we want to crawl and parse the URLs, and then upload the chunks to an instance, we pass Crawl, Parse and Upload arguments.

## Authenticating

### Configuring the Authenticator

Here are the configuration arguments for authentication. You can store these in a config file, which is refereced by passing `-c path/to/config/file`.

| Argument | Description | Mandatory (yes/no) | Default value if not specified |
| --- | --- | --- | --- |
| **resource_path_list** | Local file path to the csv file that contains a list of URLs | Yes | None |
| **output_path** | Local folder path where a list of html paths will be stored. This list can be used as `resource_path_list` for the parser, with `resource_type=html` | Yes | None |
| **username** | Username to be used for authentication | Yes | None |
| **password** | Password to be used for authentication | Yes | None |
| **use_secure_token** | Set this to true if authentication requires a secure token, False otherwise | No | True |
| **login_method** | Login method to be used. Choose one of `ericsson` or `azure`, other methods aren't supported as of now | Yes | None |

Run the authenticator by executing

```
python authenticator.py -c path/to/config/file
```

# Cron Script Walkthrough

1. Configuring the environment in which the python utility scripts can run. This can be done by formatting the PATH variable to include the paths of all relevant libraries

2. Variables to configure in cron script.
    - DOCUMENT_GROUP_ID : ID of the answers skill (Found in route as document-knowledge when an answers skill is opened)
    - API_SERVER : URL where the avaamo platform is hosted
    - ACCESS_TOKEN : Avaamo access token of the user to be used for the updates
    - RESOURCE_PATH_LIST : Path to the csv file which holds the list of URLs that will be parsed. The format of csv file can be understood from README.md

3. A cronjob should be created with the configured script with the desired frequency, and a desired path to logs file.

## Functioning of the script

- Creates an output dir with api_server, kp_id, and timestamp as name
- If enabled, runs the authentication script and saves the htmls along with a new csv which contains path of htmls
- Runs the parsing script for all the URLs in the csv and creates chunks
- Fetches all the documents from the skill and compares the chunks of each one to the newly parsed chunks
- No action is taken if the document contains training data, or if the document is not present in csv
- Only chunk text is compared, changes in headers are ignored as there is scope for manual edits
- No action is taken for the URLs that are present in the csv file but not in the skill
- If changes in number of chunks or chunk text is detected, the new chunks are uploaded for the document and old chunks are cleared. The document is put in queue for knowledge extraction.