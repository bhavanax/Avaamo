import codecs
import os

import pandas as pd
from commons.custom_requests import CustomRequests as requests
from bs4 import BeautifulSoup
from document_parsing_lib.config.app_config import LANGUAGES
from document_parsing_lib.document_extractor import (ExcelReader, PptxReader,
                                                     TextReader)
from document_parsing_lib.document_extractor.parsing import (
    DocumentRunsChunkizer, HTMLTextChunkizer, HTMLTextExtractor)
from document_parsing_lib.nlp.text_normalizer import TextNormalizer
from document_parsing_lib.web_extractor.parsing import Parser as WebParser
from logger import Logger

ALLOWED_SHEET_TYPES = ("xlsx", "xls", "csv", "zip")
ALLOWED_TEXT_TYPES = ("plain", "doc", "text/plain", "txt")
ALLOWED_PDF_TYPES = ("pdf", "application/pdf")
ALLOWED_PPT_TYPES = ("pptx")

LOGGER = Logger(__name__)


class Parser:

    def convert_pdf_to_text(self, document_path):
        with codecs.open(document_path, "r", encoding="utf-8") as html_file:
            html_string = html_file.read()
        soup = BeautifulSoup(html_string, "html.parser")
        simple_text = soup.get_text()
        with codecs.open(document_path, "w", encoding="utf-8") as text_file:
            text_file.write(simple_text)

    def extract_pdf_document(
        self,
        doc_id,
        kp_id,
        parsing_template=None,
        document_path=None,
        language="en-US",
        index_pages=0,
        parsing_lib=None
    ):
        document_attributes = dict()
        (
            document_text,
            title,
            approx_no_of_pages,
            html_file_path,
        ) = HTMLTextExtractor.extract_text_from_pdf(
            document_path, parsing_template=parsing_template, parsing_lib=parsing_lib
        )

        document_chunks = HTMLTextChunkizer.format_text(
            document_text,
            title,
            parsing_template=parsing_template,
            index_pages=index_pages,
            language=language,
        )

        document_chunks = HTMLTextChunkizer.chunkize_text(
            document_chunks, doc_id, language=language
        )
        document_attributes["document_text"] = document_text

        document_attributes["title"] = os.path.basename(document_path)
        document_attributes["no_of_pages"] = approx_no_of_pages

        return document_chunks, document_attributes

    def extract_web_page(
        self,
        auth,
        custom_response,
        doc_id,
        kp_id,
        document_path=None,
        parsing_template=None,
        url=None,
        language="en-US",
        web=True,
        local_path=None,
        add_preview_url=True
    ):
        document_attributes = dict()
        web_page_chunks, title, doc_runs, contains_iframe, body = WebParser.process_url(
            auth, custom_response, url, kp_id, parsing_template, web, local_path
        )
        document_attributes["doc_runs"] = doc_runs
        document_attributes["title"] = title
        web_page_chunks = WebParser.get_paragraph_level_chunks(
            web_page_chunks, doc_id, language, url, body,
            add_preview_url=add_preview_url
        )
        web_page_meta = dict()
        # No number of pages for web pages
        web_page_meta["number_of_pages"] = 1

        document_attributes["contains_iframe"] = contains_iframe
        return web_page_chunks, document_attributes

    def extract_txt_document(
        self,
        doc_id, parsing_template=None, document_path=None, language="en-US"
    ):
        document_attributes = dict()
        document_text = TextReader.extract_text(document_path)
        document_attributes["document_text"] = document_text
        split_text = TextReader.split_text(
            document_text, parsing_template=parsing_template, language=language
        )
        document_chunks = TextReader.chunkize_text(
            split_text, doc_id, language=language)
        return document_chunks, document_attributes

    def extract_excel_sheet(
        self,
        doc_id,
        parsing_template=None,
        document_path=None,
        resource_type=None,
        language=LANGUAGES.EN,
    ):
        document_attributes = dict()
        excel_text, total_rows = ExcelReader.extract_text(
            document_path, resource_type=resource_type, language=language
        )
        split_text = ExcelReader.split_text(
            excel_text, parsing_template, language)
        document_chunks = ExcelReader.chunkize_text(
            split_text, doc_id, language=language)
        document_attributes["title"] = os.path.basename(document_path)
        document_attributes["total_rows"] = total_rows
        document_attributes["excel_text"] = excel_text

        return document_chunks, document_attributes

    def extract_pptx_document(
        self,
        document_path=None,
        parsing_template=None,
        language=LANGUAGES.EN,
    ):
        document_attributes = dict()
        document_chunks = PptxReader.extract_chunks(document_path)
        document_attributes["title"] = os.path.basename(document_path)
        return document_chunks, document_attributes

    def extract_qa_excel_sheet(
        self,
        doc_id,
        parsing_template="QAExcelDocumentTemplate",
        document_path=None,
        language=LANGUAGES.DEFAULT,
        resource_type=None,
    ):
        LOGGER.info(f"Parsing QA excel template")
        document_df = pd.read_csv(document_path)
        document_records = document_df.to_dict("records")

        for i, record in enumerate(document_records):
            training_data = record["training_data"]
            if isinstance(training_data, str):
                training_data_list = training_data.split("|")
            else:
                training_data_list = []
            training_data_list.append(record["question"])
            training_data_list = [data.strip() for data in training_data_list]
            record["training_data"] = training_data_list
            LOGGER.debug(f"Training data \n {training_data_list}")
            document_records[i] = record

        chunks = []

        for i, record in enumerate(document_records):
            chunk = self.generate_chunk(record, doc_id, i, language)
            chunks.append(chunk)

        document_attributes = {
            "total_rows": len(document_df),
            "excel_text": "TODO",
            "document_text": "TODO",
        }
        LOGGER.info(f"Chunks extracted for QA {len(chunks)}")
        return chunks, document_attributes

    def learn_from_qa_chunks(self, chunks, language, doc_id):
        learnt_chunks = list()
        text_normalizer = TextNormalizer(language=language)
        paragraph_number = 0

        for chunk in chunks:

            text = chunk["text"]
            header = chunk["header"]

            stem_text = text_normalizer.preprocess(text, tokenize=False)
            stem_headers = text_normalizer.preprocess(header, tokenize=False)

            paragraph_number += 1

            learnt_chunk = {
                'text': text,
                "stem_headers": stem_headers,
                "augmented_text": stem_headers + " " + stem_text,
                "stem_text": stem_text,
                'header': chunk['header'],
                'section_headers': chunk['section_headers'],
                'doc_id': doc_id,
                'page': chunk['page'],
                'paragraph_number': paragraph_number,
                "training_data": chunk["training_data"],
            }
            learnt_chunk.update(chunk)
            learnt_chunks.append(learnt_chunk)

        return learnt_chunks

    def generate_chunk(self, record, doc_id, para_number, language=LANGUAGES.DEFAULT):
        text = record["response"]
        header = record["question"]

        chunk = {
            "text": text,
            "header": header,
            "section_headers": [{"header": header, "rank": 2}],
            "page": 1,
            "training_data": record["training_data"],
        }

        return chunk

    def learn_from_chunks(
        self,
        chunks,
        language,
        doc_id=0,
        resource_type=None,
    ):

        document_chunks = []

        if resource_type in ("url", "html"):
            document_chunks = WebParser.learn_from_paragraph_level_chunks(
                chunks, language, doc_id)
        elif resource_type in ALLOWED_PDF_TYPES:
            document_chunks = DocumentRunsChunkizer.learn_from_paragraph_level_chunks(
                chunks, language, doc_id)

        elif resource_type in ALLOWED_SHEET_TYPES:
            document_chunks = ExcelReader.learn_from_paragraph_level_chunks(
                chunks, language, doc_id)

        elif resource_type in ALLOWED_TEXT_TYPES:
            document_chunks = TextReader.learn_from_paragraph_level_chunks(
                chunks, language, doc_id)

        elif resource_type in ALLOWED_PPT_TYPES:
            document_chunks = DocumentRunsChunkizer.learn_from_paragraph_level_chunks(
                chunks, language, doc_id)

        elif resource_type == "QAExcelDocument":
            document_chunks = self.learn_from_qa_chunks(
                chunks, language, doc_id)

        else:
            raise IOError(f"Unknown resource type: {resource_type}")

        return document_chunks

    def parse_document(
        self,
        auth,
        custom_response,
        language,
        document_path=None,
        doc_id=0,
        kp_id=0,
        parsing_template=None,
        resource_type=False,
        index_pages=0,
        local_path=None,
        add_preview_url=True,
        parsing_lib=None
    ):

        document_chunks = []

        if resource_type == "url":
            response = requests.get(document_path)
            if response.ok or response.status_code in (401, 403):
                document_chunks, document_attributes = self.extract_web_page(
                    auth,
                    custom_response,
                    doc_id,
                    kp_id,
                    parsing_template=parsing_template,
                    url=document_path,
                    language=language,
                    add_preview_url=add_preview_url
                )
            else:
                response.raise_for_status()

        elif resource_type == "html":
            document_chunks, document_attributes = self.extract_web_page(
                auth,
                custom_response,
                doc_id,
                kp_id,
                parsing_template=parsing_template,
                url=document_path,
                language=language,
                web=False,
                local_path=local_path,
                add_preview_url=add_preview_url
            )
        else:
            if os.path.exists(document_path):
                if resource_type in ALLOWED_PDF_TYPES:
                    document_chunks, document_attributes = self.extract_pdf_document(
                        doc_id,
                        kp_id,
                        parsing_template=parsing_template,
                        document_path=document_path,
                        language=language,
                        index_pages=index_pages,
                        parsing_lib=parsing_lib
                    )

                elif resource_type in ALLOWED_SHEET_TYPES:
                    document_chunks, document_attributes = self.extract_excel_sheet(
                        doc_id,
                        parsing_template=parsing_template,
                        document_path=document_path,
                        language=language,
                        resource_type=resource_type,
                    )

                elif resource_type in ALLOWED_TEXT_TYPES:
                    document_chunks, document_attributes = self.extract_txt_document(
                        doc_id,
                        parsing_template=parsing_template,
                        document_path=document_path,
                        language=language,
                    )

                elif resource_type in ALLOWED_PPT_TYPES:
                    document_chunks, document_attributes = self.extract_pptx_document(
                        document_path,
                        parsing_template=parsing_template,
                        language=language,
                    )

                elif parsing_template and parsing_template["key"] == "QAExcelDocumentTemplate":
                    document_chunks, document_attributes = self.extract_qa_excel_sheet(
                        doc_id,
                        parsing_template=parsing_template,
                        document_path=document_path,
                        language=language,
                        resource_type=resource_type,
                    )

                else:
                    raise IOError(f"Unknown resource type: {resource_type}")
            else:
                raise IOError(
                    f"Input filepath '{document_path}' doesn't exist")

        return document_chunks, len(document_chunks), document_attributes
