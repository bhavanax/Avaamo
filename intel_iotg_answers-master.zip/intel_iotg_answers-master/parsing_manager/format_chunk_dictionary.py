import base64
import json
import os

from commons.mime_types import get_mime_type


def format_chunk_dictionary(chunk_dictionary, parsing_template_id):
    for path, document in chunk_dictionary.items():
        document = document["document"]
        for i, chunk in enumerate(document["chunks"]):
            chunk["paragraph_number"] = chunk.get("paragraph_number", i+1)
            chunk["chunk_headers"] = chunk.pop("section_headers")

            for header in chunk["chunk_headers"]:
                header["text"] = header.get(
                    "text", "") or header.get("header", "")

        document["parsing_template"] = parsing_template_id

        if document["document_type"] not in ("url", "html"):
            document_details = {}
            with open(document['path'], "rb") as local_file:
                document_details["data"] = base64.b64encode(
                    local_file.read()).decode("utf-8")

            mime_type = get_mime_type(
                document["document_type"], os.path.splitext(document['path']))

            document_details["type"] = mime_type
            document_details["name"] = document["name"]
            document["document_file_64"] = document_details

        chunk_dictionary[path] = document

    return chunk_dictionary
