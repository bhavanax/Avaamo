import base64
import json
import os
import traceback

import multiprocessing
import numpy as np
import pandas as pd

from commons.mime_types import get_mime_type
from kp_manager.api_helper import APIHelper
from logger import Logger

from .parser import Parser
from .format_chunk_dictionary import format_chunk_dictionary

LOGGER = Logger(__name__)


class ParsingManager:
    @staticmethod
    def upload_chunks(chunks_path, instance, access_token, document_group_id, pool_size=1):

        if not os.path.isfile(chunks_path):
            raise IOError(
                f"Given path to chunks '{chunks_path}' is not a file.")
        with open(chunks_path, "r") as chunks_file:
            chunk_dictionary = json.load(chunks_file)

        api_helper = APIHelper(instance, access_token, document_group_id)

        status_dictionary = {}

        chunksize = 10
        arguments_list = [(document_path, document, api_helper)
                          for document_path, document in chunk_dictionary.items()]
        pool_size = min(pool_size, int(len(arguments_list)/chunksize))
        pool_size = max(pool_size, 1)

        pool = multiprocessing.Pool(pool_size)
        chunked_results = pool.starmap(
            ParsingManager.upload_document, arguments_list, chunksize=chunksize)

        for result in chunked_results:
            status_dictionary.update(result)

        return status_dictionary

    @staticmethod
    def upload_document(document_path, document, api_helper):
        status = False
        try:
            response, chunks_count = api_helper.import_document(document)
            if response is None:
                LOGGER.warning(f"Failed to upload '{document_path}'")

            else:
                status = True
                LOGGER.info(f"Successfully uploaded '{document_path}'")

        except Exception as exc:
            LOGGER.error(f"Failed to upload '{document_path}'")
            LOGGER.error(traceback.format_exc())

        return {
            document_path: {
                "status": status,
                "chunks": chunks_count
            }
        }

    @staticmethod
    def parse_document(
        path,
        resource_type,
        parsing_template,
        language,
        custom_response,
        auth_token,
        document_options,
        index_pages,
        parsing_template_id,
        local_path=None,
        add_preview_url=True,
        parsing_lib=None
    ):
        LOGGER.info(f"Processing path ----- {path}")
        try:
            (
                document_chunks,
                number_of_chunks,
                document_attributes,
            ) = Parser().parse_document(
                auth_token,
                custom_response,
                language,
                document_path=path,
                parsing_template=parsing_template,
                resource_type=resource_type,
                index_pages=index_pages,
                local_path=local_path,
                add_preview_url=add_preview_url,
                parsing_lib=parsing_lib
            )
        except Exception as exc:
            LOGGER.error(traceback.format_exc())
            LOGGER.warning(
                f"Error occurred while parsing '{path}': {exc.__class__.__name__}: {exc}")
            (
                document_chunks,
                number_of_chunks,
                document_attributes,
            ) = [], 0, {"title": path}
        LOGGER.debug(
            f"Number of chunks found for {path} ---- {number_of_chunks}"
        )

        summary_dictionary = dict()

        summary_dictionary["Path"] = path
        summary_dictionary["Number Of Chunks"] = number_of_chunks

        number_of_sentences = []
        for chunk in document_chunks:
            number_of_sentences.append(len(chunk["text"].split(".")))
        if number_of_sentences:
            if number_of_sentences and max(number_of_sentences) > 25:
                summary_dictionary["Parsing Quality"] = "Bad"
            else:
                summary_dictionary["Parsing Quality"] = "Good"

        chunk_dictionary = dict()
        chunk_dictionary[path] = {}
        chunk_dictionary[path]["document"] = {}
        chunk_dictionary[path]["document"][
            "chunks"
        ] = document_chunks
        chunk_dictionary[path]["document"][
            "name"
        ] = document_attributes["title"]
        chunk_dictionary[path]["document"][
            "document_type"
        ] = resource_type
        if resource_type in ("url", "html"):
            chunk_dictionary[path]["document"]["url"] = path
        else:
            chunk_dictionary[path]["document"]["path"] = path
        if document_options:
            chunk_dictionary[path]["document"][
                "document_properties"
            ] = document_options

        chunk_dictionary = format_chunk_dictionary(
            chunk_dictionary, parsing_template_id)

        return summary_dictionary, chunk_dictionary

    @staticmethod
    def parse_documents_bulk(
        resource_path_list,
        default_parsing_template,
        language,
        resource_type,
        default_index_pages,
        parsing_template_id,
        add_preview_url=True,
        pool_size=1,
        parsing_lib=None
    ):
        resource_data = pd.read_csv(resource_path_list)
        summaries = list()
        documents = dict()

        if "category" in resource_data.columns:
            resource_data = resource_data[resource_data.category.isin(
                ["UPDATE", "NEW"])]

        arguments_list = []

        for _idx, row in resource_data.iterrows():
            parsing_template = default_parsing_template.copy()
            path = row["Path"].strip()
            if "Custom Response" in row and isinstance(row["Custom Response"], str):
                custom_response = json.loads(row["Custom Response"])
            else:
                custom_response = None
            if "Auth Token" in row and isinstance(row["Auth Token"], str):
                auth_token = json.loads(row["Auth Token"])
            else:
                auth_token = None
            if "Document Options" in row and isinstance(row["Document Options"], str):
                document_options = json.loads(row["Document Options"])
                document_options = json.dumps(document_options)
            else:
                document_options = None
            if "Index Pages" in row and not np.isnan(row["Index Pages"]):
                index_pages = row["Index Pages"]
            else:
                index_pages = default_index_pages
            if "Parsing Template" in row and isinstance(row["Parsing Template"], str):
                with open(row["Parsing Template"], "r") as json_file:
                    parsing_template["template_json"] = json.load(json_file)
            if "Parsing Template Key" in row and row["Parsing Template Key"]:
                parsing_template["key"] = row["Parsing Template Key"]

            local_path = None
            if "Local Path" in row and isinstance(row["Local Path"], str):
                local_path = row["Local Path"].strip()

            if path:
                arguments_list.append((path, resource_type, parsing_template, language, custom_response,
                                       auth_token, document_options, index_pages, parsing_template_id, local_path, add_preview_url, parsing_lib))

        document_list = []
        chunksize = 10
        pool_size = min(pool_size, int(len(arguments_list)/chunksize))
        pool_size = max(pool_size, 1)
        pool = multiprocessing.Pool(pool_size)
        chunked_results = pool.starmap(
            ParsingManager.parse_document, arguments_list, chunksize=chunksize)

        for chunk in chunked_results:
            summaries.append(chunk[0])
            document_list.append(chunk[1])

        for document in document_list:
            documents.update(document)

        return summaries, documents

    @staticmethod
    def validate_extracted_document(document):
        assert isinstance(document, dict)
        assert "document" in document
        assert "name" in document["document"]
        assert "document_type" in document["document"]
        assert "path" in document["document"] or "url" in document["document"]
        if "path" in document["document"]:
            assert os.path.exists(document["document"]["path"])

        assert "chunks" in document["document"] and isinstance(
            document["document"]["chunks"], list)
        for chunk in document["document"]["chunks"]:
            assert "text" in chunk and isinstance(chunk["text"], str)
            assert "page" in chunk and isinstance(chunk["page"], int)

            assert "section_headers" in chunk and isinstance(
                chunk["section_headers"], list)
            for section_header in chunk["section_headers"]:
                assert "header" in section_header and isinstance(
                    section_header["header"], str)
                assert "rank" in section_header and isinstance(
                    section_header["rank"], int) and section_header["rank"] >= 0

    @staticmethod
    def learn_from_document(document, language):
        LOGGER.info(
            f"Processing document ----- {document['document']['name']}")

        learnt_chunks = Parser().learn_from_chunks(
            document["document"]["chunks"], language,
            resource_type=document["document"]["document_type"])

        document["document"]["chunks"] = learnt_chunks

        if document["document"]["document_type"] not in ("url", "html"):
            document_details = dict()
            document_details["name"] = document['document']['name']
            with open(document['document']['path'], "rb") as local_file:
                document_details["data"] = base64.b64encode(
                    local_file.read()).decode("utf-8")
            document_details["size"] = os.stat(
                document['document']['path']).st_size

            mime_type = get_mime_type(
                document["document"]["document_type"], os.path.splitext(
                    document['document']['path']))

            document_details["type"] = mime_type
            document["document"]["document_file_64"] = document_details
            document["document"][
                "document_type"
            ] = mime_type

        return document

    @staticmethod
    def learn_from_documents(chunks_path, language):
        with open(chunks_path, 'r') as chunks_json_file:
            chunks = json.load(chunks_json_file)

        assert isinstance(chunks, dict)

        learnt_chunks = dict()
        for document_key, document in chunks.items():
            ParsingManager.validate_extracted_document(document)
            learnt_chunks[document_key] = ParsingManager.learn_from_document(
                document, language)

        return learnt_chunks
