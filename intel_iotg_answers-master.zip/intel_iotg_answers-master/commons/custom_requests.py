import requests

from commons.config import SSL_CERT_PATH, USE_SSL_CERT, VERIFY_SSL


class CustomRequests:

    @staticmethod
    def __update_keyword_args(kwargs):
        if "verify" not in kwargs:
            verification = VERIFY_SSL
            if VERIFY_SSL and USE_SSL_CERT:
                verification = SSL_CERT_PATH
            kwargs.update({"verify": verification})
        return kwargs

    @staticmethod
    def get(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.get(*args, **kwargs)

    @staticmethod
    def post(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.post(*args, **kwargs)

    @staticmethod
    def put(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.put(*args, **kwargs)

    @staticmethod
    def delete(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.delete(*args, **kwargs)

    @staticmethod
    def head(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.head(*args, **kwargs)

    @staticmethod
    def request(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.request(*args, **kwargs)

    @staticmethod
    def session(*args, **kwargs):
        kwargs = CustomRequests.__update_keyword_args(kwargs)
        return requests.session(*args, **kwargs)
