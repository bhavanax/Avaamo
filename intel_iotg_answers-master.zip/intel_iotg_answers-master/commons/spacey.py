import spacy

from commons.config import SPACY_MODEL

SPACY = spacy.load(SPACY_MODEL)


def spacy_tokenize(doc):
    doc_type = "list" if isinstance(doc, list) else "str"

    if doc_type == "str":
        doc = [doc]

    tokens = []
    for text in SPACY.pipe(doc, disable=["tagger", "parser", "ner"]):
        tokens.append([tok.text for tok in text if tok.text.strip()])

    return tokens if doc_type == "list" else tokens[0]
