
def get_mime_type(resource_type, extension):
    mime_type = "text/html"

    if resource_type in ("pdf", "application/pdf"):
        mime_type = "application/pdf"
    elif resource_type in ("xls", "csv", "zip", "excel", "text/csv"):
        if extension == "xls":
            mime_type = "application/vnd.ms-excel"
        elif extension == "xlsx":
            mime_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            mime_type = "text/csv"
    elif resource_type in ("plain", "doc", "txt", "text", "text/plain"):
        if extension == "doc":
            mime_type = "application/msword"
        elif extension == "docx":
            mime_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        else:
            mime_type = "text/plain"
    elif resource_type in ("pptx"):
        mime_type = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    else:
        raise TypeError(f"Unknown resource_type '{resource_type}'")

    return mime_type
