import os


def get_bool(env_var, default=False):
    env_var = os.getenv(env_var)
    if env_var and env_var.lower() == "false":
        return False
    if env_var and env_var.lower() == "true":
        return True
    return default

SPACY_MODEL = os.getenv("SPACY_MODEL") or 'en_core_web_md'

VERIFY_SSL = get_bool("VERIFY_SSL", default=True)
USE_SSL_CERT = get_bool("USE_SSL_CERT")
SSL_CERT_PATH = os.getenv("SSL_CERT_PATH")
