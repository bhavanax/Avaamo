import os
from time import time

class Timer():

    def __init__(self):
        self.started_at = time()

    def lap(self):
        lap_time = time()-self.started_at
        self.started_at += lap_time
        return lap_time

def batch(iterable, batch_size=1):
    total_length = len(iterable)
    for ndx in range(0, total_length, batch_size):
        yield iterable[ndx:min(ndx + batch_size, total_length)]

def convert_bytes(number):
    """
    this function will convert bytes to MB.... GB... etc
    """
    for size_type in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if number < 1024.0:
            return "%3.1f %s" % (number, size_type)
        number /= 1024.0

def file_size(file_path):
    """
    this function will return the file size
    """
    if os.path.isfile(file_path):
        file_info = os.stat(file_path)
        return file_info.st_size

def str2list(value):
    if isinstance(value, list):
        return value
    if not value:
        return list()
    if isinstance(value, str):
        raise TypeError('String value expected.')
    return [int(val.strip()) for val in value.split(",")]
