import json
import os
import statistics

import pandas as pd

from commons.spacey import spacy_tokenize
from logger import Logger

LOGGER = Logger(__name__)


class Metrics:
    def __init__(self, workdir):
        self.workdir = workdir

    def get_chunk_distribution(self, chunks):
        chunk_tokens = spacy_tokenize(chunks)
        chunk_sizes = [len(tokens) for tokens in chunk_tokens]

        mean = statistics.mean(chunk_sizes)
        std_dev = statistics.stdev(chunk_sizes)

        small = 0
        moderate = 0
        large = 0
        low_thresh = min(20, mean-2*std_dev)
        high_thresh = max(200, mean+2*std_dev)

        for size in chunk_sizes:
            if size <= low_thresh:
                small += 1
            elif size >= high_thresh:
                large += 1
            else:
                moderate += 1

        stats = {
            "small chunks": small,
            "moderate chunks": moderate,
            "large chunks": large
        }

        return stats

    def process_docs(self, path=None):
        if path is None:
            path = os.path.join(self.workdir, 'documents.json')
        documents = json.loads(path)
        documents = documents["documents"]

        document_stats = []
        for url, document in documents.items():
            chunks = document["chunks"]
            stats = self.get_chunk_distribution(chunks)
            stats["url"] = url
            document_stats.append(stats)

        document_stats = pd.DataFrame(document_stats, columns=[
                                      "Path", "small chunks", "moderate chunks", "large chunks"])

        path = os.path.join(self.workdir, 'document_metrics.csv')
        document_stats.to_csv(path)
