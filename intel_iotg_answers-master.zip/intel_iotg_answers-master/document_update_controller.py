import os

import configargparse

from commons.utils import str2list
from cron_job.job_handler import JobHandler


def main(args):
    document_group_id = args.document_group_id
    api_server = args.instance
    access_token = args.access_token
    parsed_documents_path = os.path.join(
        args.parsed_documents_dir, "chunks.json")

    job_handler = JobHandler(
        document_group_id, api_server, access_token, parsed_documents_path,
        args.extra_document_group_ids)
    job_handler.fetch_documents_from_kp()
    job_handler.evaluate_documents()


if __name__ == "__main__":

    PARSER = configargparse.ArgParser()

    PARSER.add(
        "--parsed_documents_dir",
        default=None,
        type=str,
        required=True,
        help="Local file path to the file that contains a list of URLs",
    )
    PARSER.add(
        "--access_token", default=None, type=str, help="Access Token",
    )
    PARSER.add(
        "--instance",
        default=None,
        type=str,
        help="URL to the instance where the documents should be uploaded. Ex. https://c7.avaamo.com",
    )
    PARSER.add(
        "--document_group_id", default=None, type=str, help="Document Group ID",
    )
    PARSER.add(
        "--extra_document_group_ids", default=None, type=str2list, help="Extra Document Group IDs",
    )

    ARGS = PARSER.parse_args()

    main(ARGS)
