import datetime
import json
import logging
import os
import traceback
import colorama

import bugsnag
from bugsnag.handlers import BugsnagHandler

bugsnag.configure(
    api_key=os.getenv('BUGSNAG_KEY'),
    project_root="../",
    app_version=os.getenv('RELEASE_VERSION')
)

STRING_LIMIT = 5000

colorama.init()
GREEN = colorama.Fore.GREEN
RED = colorama.Fore.RED
YELLOW = colorama.Fore.YELLOW
CYAN = colorama.Fore.CYAN
BLUE = colorama.Fore.BLUE
WHITE = colorama.Fore.WHITE
GRAY = colorama.Fore.LIGHTBLACK_EX
RESET = colorama.Fore.RESET
class Logger:
    """docstring for Logger"""

    def __init__(self, name=__name__, level="INFO"):
        handler = BugsnagHandler()
        handler.setLevel(logging.ERROR)
        # create and configure main logger
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        # create console handler with a higher log level
        handler = logging.StreamHandler()
        handler.setLevel(logging.DEBUG)
        # create formatter and add it to the handler
        formatter = logging.Formatter('[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s')
        handler.setFormatter(formatter)
        # add the handler to the logger
        logger.addHandler(handler)
        self.logger = logger


    def safe_str(self, obj):
        try:
            ret_str = str(obj)
            info = ret_str[:STRING_LIMIT] + (ret_str[STRING_LIMIT:] and '...')
            return info
        except UnicodeEncodeError:
            ret_str = obj.encode('utf-8', 'ignore').decode('utf-8')
            info = ret_str[:STRING_LIMIT] + (ret_str[STRING_LIMIT:] and '...')
            return info
        return ""

    def get_log_text(self, arr):
        return ' '.join(self.safe_str(a) for a in arr)

    def info(self, *args):
        self.logger.info(f"{GREEN}{self.get_log_text(args)}{RESET}")

    def debug(self, *args):
        self.logger.debug(f"{GRAY}{self.get_log_text(args)}{RESET}")

    def warning(self, *args):
        self.logger.warning(f"{YELLOW}{self.get_log_text(args)}{RESET}")

    def error(self, *args):
        self.logger.error(f"{RED}{self.get_log_text(args)}{RESET}")

    def critical(self, *args):
        self.logger.critical(f"{CYAN}{self.get_log_text(args)}{RESET}")

    def exception(self, *args):
        self.logger.exception(f"{BLUE}{self.get_log_text(args)}{RESET}")

    def log(self, *args):
        self.logger.log(f"{WHITE}{self.get_log_text(args)}{RESET}")

    def notify(self, exc, context=None, metadata=None):
        bugsnag.notify(exc, context=context, metadata=metadata)
