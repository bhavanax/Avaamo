export PYTHONPATH=$PWD

export eval $(cat .env .env.local | egrep -v '^#' | sed '/^[[:space:]]*$/d' | xargs -0)

JAVA_HOME=$(asdf where java) FLASK_APP=application CURRENT_DIR=$PWD gunicorn -c application/gunicorn_conf.py application:app 2>&1
