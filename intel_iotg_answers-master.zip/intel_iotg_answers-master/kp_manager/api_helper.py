import traceback

from commons.custom_requests import CustomRequests as requests
from requests.exceptions import RequestException

from logger import Logger

LOGGER = Logger(__name__)

IMPORT_DOCUMENT = "{api_server}/answers/external/document-groups/{document_group_id}/documents/import"
FETCH_DOCUMENTS = "{api_server}/answers/external/document_groups/{document_group_id}/documents"
DELETE_DOCUMENT = "{api_server}/answers/external/documents"
FETCH_CHUNKS = "{api_server}/answers/external/documents/{document_id}/chunks"


class APIHelper:

    DELIMITER = "#$%^!@#$"
    MAX_STR_LEN = 250

    def __init__(self, api_server, access_token, document_group_id=None):
        self.api_server = api_server
        self.access_token = access_token
        self.document_group_id = document_group_id

    def _validate_document(self, document_data):
        assert "chunks" in document_data
        assert isinstance(document_data["chunks"], list)
        assert "name" in document_data

    def _modify_chunks(self, document_data):
        for chunk in document_data["chunks"]:
            headers = chunk["chunk_headers"]
            for header in headers:
                header["text"] = header["text"][:APIHelper.MAX_STR_LEN]
        return document_data

    def import_document(self, data):
        LOGGER.debug(f"Importing document")
        headers = {
            "Access-Token": self.access_token,
            "Content-Type": "application/json",
        }
        endpoint = IMPORT_DOCUMENT.format(
            api_server=self.api_server, document_group_id=self.document_group_id)

        self._validate_document(data)
        data = self._modify_chunks(data)

        response = requests.post(
            endpoint, headers=headers, json=data, verify=False)
        try:
            response.raise_for_status()
            response = response.json()
        except RequestException:
            LOGGER.error(response.text)
            LOGGER.error(traceback.format_exc())
            response = None

        return response, len(data["chunks"])

    def fetch_documents(self):
        LOGGER.debug(f"Fetching documents for kp id {self.document_group_id}")
        headers = {
            "Access-Token": self.access_token,
            "Content-Type": "application/json",
        }
        next_payload_url = FETCH_DOCUMENTS.format(
            api_server=self.api_server, document_group_id=self.document_group_id)

        all_documents = []
        while next_payload_url:
            LOGGER.info(f"Sending request: URL ---> {next_payload_url}")
            response = requests.get(next_payload_url, headers=headers)

            try:
                response.raise_for_status()
                response_data = response.json()
                next_payload_url = response_data["next"]
                all_documents += response_data["results"]
            except Exception:
                LOGGER.error(traceback.format_exc())
                raise(
                    f"We were unable to fetch documents from document group id {self.document_group_id}")

        return all_documents

    def delete_document(self, data):
        LOGGER.debug(f"Deleting document with  {data}")
        headers = {
            "Access-Token": self.access_token,
            "Content-Type": "application/json",
        }
        endpoint = DELETE_DOCUMENT.format(api_server=self.api_server)

        try:
            response = requests.delete(
                endpoint, json=data, headers=headers, verify=False)
            response.raise_for_status()
            response = True
        except RequestException:
            LOGGER.error(traceback.format_exc())
            response = None

        return response

    def fetch_document_chunks(self, doc_id):
        LOGGER.debug(f"Fetching chunks for doc id {doc_id}")
        headers = {
            "Access-Token": self.access_token,
            "Content-Type": "application/json",
        }
        payload_url = FETCH_CHUNKS.format(
            api_server=self.api_server, document_id=doc_id)

        all_documents = []
        LOGGER.info(f"Sending request: URL ---> {payload_url}")
        response = requests.get(payload_url, headers=headers)

        try:
            response.raise_for_status()
            response_data = response.json()
            all_documents += response_data
        except Exception:
            LOGGER.error(traceback.format_exc())
            raise(
                f"We were unable to fetch chunks from document id {doc_id}")

        return all_documents
