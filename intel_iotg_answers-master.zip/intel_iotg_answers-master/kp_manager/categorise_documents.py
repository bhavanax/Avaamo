import os

import pandas as pd
from commons.custom_requests import CustomRequests as requests
from dateutil import parser

import crawler
from kp_manager.api_helper import APIHelper
from logger import Logger

LOGGER = Logger(__name__)


class CategoriseDocuments:
    def __init__(self, kp_id, api_server, access_token, workdir):
        self.kp_id = kp_id
        self.api_server = api_server
        self.access_token = access_token
        self.workdir = workdir
        self.api = APIHelper(api_server, access_token, document_group_id=kp_id)
        self.fetch_documents()

    def fetch_documents(self):
        documents = self.api.fetch_documents()
        trimmed_documents = []
        for doc in documents:
            if doc["document_type"] != 'url':
                continue

            document = {
                "id": doc["id"],
                "Path": doc["source_url"],
                "status": doc["status"],
                "updated_at": doc["updated_at"]
            }
            trimmed_documents.append(document)

        self.documents = pd.DataFrame(trimmed_documents, columns=[
                                      'id', "Path", 'status', 'updated_at'])

    def get_category(self, data, lastmods_df=None):
        if data["Path"] not in self.new_documents:
            return "DELETED"

        new_time = None
        if lastmods_df is not None and not lastmods_df.loc[lastmods_df["Path"] == data["Path"]].empty:
            new_time = parser.parse(
                lastmods_df.loc[lastmods_df["Path"] == data["Path"]]["Lastmod"].values[0])

        else:
            response = requests.get(data["Path"])
            if not response.ok:
                return 'NA'

            if "Last-Modified" in response.headers:
                new_time = parser.parse(response.headers["Last-Modified"])

        if new_time:
            new_time = int(new_time.timestamp())
            updated_at_time = int(parser.parse(data["updated_at"]).timestamp())
            if new_time > updated_at_time or ("status" in data and data["status"] == "ERROR"):
                return 'UPDATE'
            else:
                return "PRESENT"
        else:
            return 'FAILED'

    def compare_documents(self, new_documents, lastmods=None):
        documents_result = pd.DataFrame(
            columns=['id', "Path", 'category', 'status', 'updated_at'])
        documents_result = documents_result.append(self.documents)
        self.new_documents = new_documents

        lastmods_df = None
        if lastmods:
            lastmods_df = pd.DataFrame(zip(new_documents, lastmods), columns=['Path', 'Lastmod'])

        documents_result["category"] = documents_result[["Path", "updated_at", "status"]].apply(
            lambda x: self.get_category(x, lastmods_df), axis=1).values.tolist()

        new_docs = set(new_documents) - set(documents_result["Path"].tolist())
        documents_to_upload = pd.DataFrame(columns=['id', "Path", 'category'])
        documents_to_upload["Path"] = list(new_docs)
        documents_to_upload['category'] = ["NEW"] * len(new_docs)

        documents_result = documents_result.append(documents_to_upload)
        documents_result = documents_result.drop(columns=["updated_at"])
        path = os.path.join(self.workdir, 'documents_classes.csv')
        documents_result.to_csv(path, index=False)

    def delete_documents(self, path=None):
        if path is None:
            path = os.path.join(self.workdir, 'documents_classes.csv')
        document_status = pd.read_csv(path)

        docs_for_delete = document_status.loc[document_status['category'] == 'DELETED']

        status = []
        for doc_id in docs_for_delete["id"].tolist():
            status.append(self.delete_document(int(doc_id)))
        docs_for_delete['status'] = status

        path = os.path.join(self.workdir, 'delete_documents_summary.csv')
        docs_for_delete.to_csv(path, index=False)

    def delete_document(self, doc_id):
        res = self.api.delete_document(doc_id)

        if res is not None:
            return "Success"
        else:
            return "Failed"

    def scrape_and_compare_urls(self, url):
        path = os.path.join(self.workdir, "scraped_urls.csv")
        crawler.crawl_base_url(url, save_path=path)

        urls = pd.read_csv(path)
        urls = urls["Path"].tolist()

        self.compare_documents(urls)

    def compare_documents_from_csv(self, path=None):
        if path is None:
            path = os.path.join(self.workdir, "urls.csv")
        urls_df = pd.read_csv(path)
        urls = urls_df["Path"].tolist()

        lastmods = None
        if 'Lastmod' in urls_df.columns:
            lastmods = urls_df["Lastmod"].tolist()

        self.compare_documents(urls, lastmods)
