from pptx import Presentation
from logger import Logger
from nltk.tokenize import word_tokenize

LOGGER = Logger(__name__)


class PptxReader:
    @staticmethod
    def extract_chunks(document_file_path):
        pptxobj = Presentation(document_file_path)
        chunks = []
        for i, slide in enumerate(pptxobj.slides):
            slide_texts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    shape_text = shape.text
                    if len(word_tokenize(shape_text)) > 3:
                        slide_texts.append(shape_text)

            if len(slide_texts) < 2:
                LOGGER.debug(f"Content not found in page {i+1}")
                continue

            header = slide_texts[0]
            text = "\n".join(slide_texts[1:])

            chunk = {
                "section_headers": [{
                    "header": header,
                    "rank": 2
                }],
                "text": text,
                "page": i+1
            }
            chunks.append(chunk)

        return chunks
