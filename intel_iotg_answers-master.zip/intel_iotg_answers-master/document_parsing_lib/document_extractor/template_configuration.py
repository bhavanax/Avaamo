import os
import re

from document_parsing_lib.errors import ParsingError
from logger import Logger

LOGGER = Logger(__name__)


class CustomizableTemplateConfig:

    def __init__(self, configuration=None):

        self.paragraph_attributes = [
            "b",
            "i",
            "p",
            "upper_case",
            "u",
            "title_case",
            "lower_case"
        ]
        self.binary_operators = {
            "__and__": "and",
            "__or__": "or",
            "__not__": "not"
        }
        self.brackets = {
            "(": "(",
            ")": ")",
            "[": "(",
            "]": ")",
            "{": "(",
            "}": ")"
        }
        self.run_splits = []
        self.paragraph_properties = {}
        self.junk = []
        self.headers = None
        self.ranks = None
        if configuration and "properties" in configuration:
            self.update_properties(configuration["properties"])
            if self.headers and not configuration["ranks"]:
                LOGGER.debug(
                    f"CustomizableTemplateConfig.__init__: ranks for properties not provided in parser config")
                raise ParsingError(
                    "Incorrect template format provided: define 'ranks' with 'proerties")
            self.ranks = configuration["ranks"]
        else:
            LOGGER.debug(
                f"CustomizableTemplateConfig.__init__: properties not provided in parser config"
            )
        if configuration and "extras" in configuration:
            self.update_extras(configuration["extras"])
        else:
            LOGGER.debug(
                f"CustomizableTemplateConfig.__init__: extras not provided in parser config"
            )
        if configuration and "run_splits" in configuration:
            self.run_splits += configuration["run_splits"]

    def update_properties(self, configuration):
        if configuration is not None and bool(configuration):
            if isinstance(configuration, dict):
                for key, value in configuration.items():
                    styles = value["attributes"]
                    if isinstance(styles, str):
                        continue
                    new_styles = []
                    for style in styles:
                        if style not in self.paragraph_attributes:
                            LOGGER.debug(f"CustomizableTemplateConfig.update_config:"
                                         f"Incorrect style - {style} provided for header {key}"
                                         )
                        else:
                            new_styles.append(style)
                        new_styles.append(style)
                    value["attributes"] = new_styles
                self.headers = configuration
            else:
                LOGGER.debug("CustomizableTemplateConfig.update_config: configuration is not in the correct format."
                             )
                self.headers = {}
                raise ParsingError(
                    "Provided dynamic template is in incorrect format")
        else:
            LOGGER.debug("CustomizableTemplateConfig.update_config: configuration is NoneType or empty."
                         )
            self.headers = {}
            raise ParsingError("Dynamic template is empty or None")

    def update_extras(self, extras):
        if extras is not None and bool(extras):
            if isinstance(extras, dict):
                for key, value in extras.items():
                    setattr(self, key, value)
            else:
                LOGGER.debug(
                    f"CustomizableTemplateConfig.update_extras: Extras is provided in incorrect format, unused")
                raise ParsingError(
                    "Extras in the dynamic template are in incorrect format")
        else:
            LOGGER.debug(
                f"CustomizableTemplateConfig.update_extras: Extras is NoneType or empty")
