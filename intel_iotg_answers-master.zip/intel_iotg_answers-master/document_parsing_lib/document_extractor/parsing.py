import codecs
import os
import re
import subprocess
import traceback
import unicodedata

from bs4 import BeautifulSoup
from document_parsing_lib.config.app_config import LANGUAGES
from document_parsing_lib.document_extractor.document_parser_templates import *
from document_parsing_lib.document_extractor.document_templates import (
    DocumentTemplateIndexed, DocumentTemplatePPTX)
from document_parsing_lib.errors import ParsingError
from document_parsing_lib.nlp.text_normalizer import TextNormalizer
from logger import Logger
from tika import parser

# import docx

PDF_BOX = {
    "key": "pdfbox-app-2.0.15.jar",
    "local": "document_parsing_lib/assets/parser/pdfbox-app-2.0.15.jar"
}

LOGGER = Logger(__name__)

DOCUMENT_TEMPLATE = DocumentTemplateBOW
TEMPLATES = {
    'DocumentTemplateBOW': DocumentTemplateBOW,
    'DocumentTemplateEricsson': DocumentTemplateEricsson,
    'DocumentTemplateEricssonChapters': DocumentTemplateEricssonChapters,
    'DocumentTemplateUBSBasel': DocumentTemplateUBSBasel,
    'DocumentTemplateUBSMiFID': DocumentTemplateUBSMiFID,
    'DocumentTemplateUBSStaffVetting': DocumentTemplateUBSStaffVetting,
    'DocumentTemplateStarhubFAQ': DocumentTemplateStarhubFAQ,
    'DocumentTemplateSamsungDDStudentInsurance': DocumentTemplateSamsungDDStudentInsurance,
    'DocumentTemplateStanleyProductManual': DocumentTemplateStanleyProductManual,
    'DocumentTemplateTokyoElectron': DocumentTemplateTokyoElectron,
    'DocumentTemplateIndexed': DocumentTemplateIndexed,
    'DocumentTemplatePPTX': DocumentTemplatePPTX
}


class HTMLDocumentRunsParser():

    MAX_NO_OF_PAGES = 1000

    @staticmethod
    def replace_unicode(text):
        try:
            text.encode('utf-32', 'surrogateescape').decode('utf-8', 'ignore')
        except UnicodeEncodeError:
            return ""
        for idx, character in enumerate(text):
            try:
                replacement = character
                # For Latin 1 circled digits
                if character == "ⓛ":
                    character = "①"
                # For weird numerals like ①
                if (unicodedata.name(character)).startswith('CIRCLED DIGIT'):
                    value = unicodedata.digit(character)
                    replacement = f'{value}).'
                    LOGGER.debug(f'HTMLDocumentRunsParser.replace_unicode: \
                        Replacing {character} with {replacement}')
                text = text[:idx] + replacement + text[idx+1:]
            except:
                pass

        text = text.replace("\u200b", "")
        text = text.replace("\u00a0", " ")
        return text

    @staticmethod
    def get_text_attributes(text):
        attrs = []
        if text.islower():
            attrs.append("lower_case")
        if text.isupper():
            attrs.append("upper_case")
        if text.istitle():
            attrs.append("title_case")
        return attrs

    @staticmethod
    def parse_paragraph(paragraph):
        if paragraph.name:
            run = []
            for content in paragraph.contents:
                single_run = HTMLDocumentRunsParser.parse_paragraph(content)
                for single in single_run:
                    single['attributes'].append(paragraph.name)
                    try:
                        single['attributes'] += paragraph['class']
                    except KeyError:
                        pass
                run += single_run
        else:
            plain_text = HTMLDocumentRunsParser.replace_unicode(str(paragraph))
            run = [{
                'text': plain_text,
                'attributes': HTMLDocumentRunsParser.get_text_attributes(plain_text)
            }]
        return run

    @staticmethod
    def split_paragraphs(doc):
        modified_doc = []
        for page in doc:
            modified_page = []
            for paragraph in page:
                modified_paragraphs = []
                current_paragraph = []
                for run in paragraph:
                    split, idxs = DOCUMENT_TEMPLATE.split_by_run(run)
                    if split:
                        curr_idx = 0
                        if idxs:
                            idx = idxs[0]
                            text = run['text'][curr_idx:idx]
                            curr_idx = idx
                            if text:
                                current_run = {
                                    'text': text,
                                    'attributes': run['attributes']
                                }
                                current_paragraph.append(current_run)
                        if current_paragraph:
                            modified_paragraphs.append(current_paragraph)

                        current_paragraph = []
                        for idx in idxs:
                            if idx > len(run['text']):
                                break
                            text = run['text'][curr_idx:idx]
                            curr_idx = idx
                            if text:
                                current_run = {
                                    'text': text,
                                    'attributes': run['attributes']
                                }
                                current_paragraph.append(current_run)
                            if current_paragraph:
                                modified_paragraphs.append(current_paragraph)
                            current_paragraph = []

                        text = run['text'][curr_idx:]
                        if text:
                            current_run = {
                                'text': text,
                                'attributes': run['attributes']
                            }
                            current_paragraph.append(current_run)
                    else:
                        current_paragraph.append(run)

                if current_paragraph:
                    modified_paragraphs.append(current_paragraph)

                modified_page += modified_paragraphs
            modified_doc.append(modified_page)
        return modified_doc

    @staticmethod
    def get_runs(html, parsing_template=None, parsing_lib=None):
        base_template, parsing_data = HTMLTextChunkizer.get_template_data(
            parsing_template)
        global DOCUMENT_TEMPLATE
        global TEMPLATES
        system_document_template = DOCUMENT_TEMPLATE
        if base_template and base_template in TEMPLATES:
            DOCUMENT_TEMPLATE = TEMPLATES[base_template]
            base_template = TEMPLATES[base_template]
        if parsing_data:
            DOCUMENT_TEMPLATE = CustomizableTemplate(
                configuration=parsing_data, base_template=base_template)

        LOGGER.info(
            f"Template data given: base_template={base_template.__class__}; parsing_data given={str(parsing_data is not None)} Using template {DOCUMENT_TEMPLATE}")

        soup = BeautifulSoup(html, "html.parser")
        title = "Document"
        html_title = soup.title.get_text().strip() if soup.title else ""
        if html_title:
            title = html_title
        divs = [div for div in soup.find_all(
            'div') if len(div.find_all('div')) == 0]
        runs = []
        no_of_pages = len(divs)
        # if no_of_pages > HTMLDocumentRunsParser.MAX_NO_OF_PAGES:
        #     raise Exception(("File size exceeds the maximum allowed "
        #                      f"size of {HTMLDocumentRunsParser.MAX_NO_OF_PAGES} pages."))
        for div in divs:
            if parsing_lib == "pdftotree":
                paragraphs = div.find_all(
                    ['paragraph', 'header', 'section_header', 'table', 'table_caption'])
            else:
                paragraphs = div.find_all('p')

            orig_runs = [HTMLDocumentRunsParser.parse_paragraph(paragraph)
                         for paragraph in paragraphs]

            if parsing_lib == "pdftotree":
                combined_runs = []
                current_run = None
                for run in orig_runs:
                    if len(run) > 1:
                        combined_runs.append(run)
                        continue
                    elif len(run) == 0:
                        continue
                    else:
                        mrun = run[0]
                        if not mrun["text"].strip():
                            continue
                    if current_run is not None:
                        current_run["text"] = current_run["text"].strip(
                        ) + " " + mrun["text"].strip()
                        combined_runs.append([current_run])
                        current_run = None
                        continue

                    else:
                        if re.match(r"^\d+\.", mrun["text"]):
                            current_run = mrun
                        else:
                            combined_runs.append(run)

                for i, paragraph in enumerate(combined_runs):
                    for run in paragraph:
                        run["attributes"].append(str(i))

            else:
                combined_runs = orig_runs

            runs.append(combined_runs)

        runs = HTMLDocumentRunsParser.split_paragraphs(runs)
        LOGGER.debug(runs)

        DOCUMENT_TEMPLATE = system_document_template

        return runs, title, no_of_pages


class SimpleTextExtractor(object):

    @staticmethod
    def extract_text_from_pdf(pdf_file_path):
        return parser.from_file(pdf_file_path)['content']

    # @staticmethod
    # def extract_text_from_docx(docx_file_path):
    #     doc = docx.Document(docx_file_path)
    #     fullText = []
    #     for para in doc.paragraphs:
    #         fullText.append(para.text)
    #     return '\n'.join(fullText)


class HTMLTextExtractor(object):
    permission_error = "You do not have permission to extract text"
    permission_error_display_message = "Document is encrypted. \
        Please try a different document or remove security encryption."

    @staticmethod
    def convert_pdf_to_html(pdf_file_path, parsing_lib="pdfbox"):
        html_file_path = pdf_file_path + '.html'

        if parsing_lib == "pdfbox":
            command = f'java -jar {PDF_BOX["local"]} ExtractText -html ' + \
                pdf_file_path.replace(" ", "\ ") + ' ' + \
                html_file_path.replace(" ", "\ ")

        elif parsing_lib == "pdftotree":
            command = f'pdftotree ' + \
                pdf_file_path.replace(" ", "\ ") + " > " + \
                html_file_path.replace(" ", "\ ")

        completed_process = subprocess.run(
            [command], shell=True, stderr=subprocess.PIPE)

        LOGGER.debug(f"PDFBox logs \n{completed_process.stderr}")
        if not os.path.isfile(html_file_path):
            if HTMLTextExtractor.permission_error in str(completed_process.stderr):
                raise PermissionError(
                    HTMLTextExtractor.permission_error_display_message)
            raise IOError(f"Error occured while converting {pdf_file_path} to HTML \n\
                {completed_process.stderr}")

        return html_file_path

    @staticmethod
    def extract_text_from_pdf(pdf_file_path, parsing_template=None, parsing_lib=None):
        html_file_path = HTMLTextExtractor.convert_pdf_to_html(
            pdf_file_path, parsing_lib=parsing_lib)
        with codecs.open(html_file_path, 'r', encoding='utf-8') as html_file:
            html_string = html_file.read()

        main_soup = BeautifulSoup(html_string, 'html.parser')
        for soup in main_soup.findAll():
            for k in list(soup.attrs.keys()):
                if k in ["left", "right", "top", "bottom", "char"]:
                    soup.attrs.pop(k, None)

        with open(html_file_path, "w") as f:
            f.write(str(main_soup))

        intermediate_document, title, no_of_pages = \
            HTMLDocumentRunsParser.get_runs(
                str(main_soup), parsing_template, parsing_lib=parsing_lib)
        return intermediate_document, title, no_of_pages, html_file_path


class DocumentRunsChunkizer():

    batch_length = 10000

    @staticmethod
    def _segment_text(text):
        # For now
        return [text]

    @staticmethod
    def _resolve_section_hierarchy(paragraph, section_hierarchy, language=LANGUAGES.EN, parsing_data=None):
        rank = DOCUMENT_TEMPLATE.get_paragraph_rank(
            paragraph, language=language, parsing_data=parsing_data)
        if rank == 1:
            header = DOCUMENT_TEMPLATE.get_subsection_header_text(
                paragraph, section_hierarchy=section_hierarchy, language=language)
        else:
            header = DOCUMENT_TEMPLATE.get_section_header_text(paragraph)
        header = header.strip()
        if header:
            if section_hierarchy:
                for i, section in enumerate(section_hierarchy):
                    if section['rank'] <= rank:
                        section_hierarchy = section_hierarchy[:i]
                        break
            existing_headers = [section['header']
                                for section in section_hierarchy]
            if header not in existing_headers:
                section_hierarchy.append({
                    'rank': rank,
                    'header': header
                })

        return section_hierarchy

    @staticmethod
    def get_current_lowest_section(section_hierarchy, title):
        if section_hierarchy:
            header = section_hierarchy[-1]['header'].strip()
        else:
            section_hierarchy = [{
                'rank': 1,
                'header': title.strip()
            }]
            header = title.strip()
        return section_hierarchy, header

    @staticmethod
    def merge_and_split(document, title, base_template=None, index_pages=0, language=LANGUAGES.EN, parsing_data=None):
        global DOCUMENT_TEMPLATE
        global TEMPLATES
        system_document_template = DOCUMENT_TEMPLATE
        if base_template and base_template in TEMPLATES:
            DOCUMENT_TEMPLATE = TEMPLATES[base_template]
            base_template = TEMPLATES[base_template]
        if parsing_data:
            DOCUMENT_TEMPLATE = CustomizableTemplate(
                configuration=parsing_data, base_template=base_template)

        LOGGER.info(
            f"Template data given: base_template={base_template.__class__}; parsing_data given={str(parsing_data is not None)} Using template {DOCUMENT_TEMPLATE}")

        formatted_document = {
            'title': title,
            'paragraphs': []
        }
        section_hierarchy = []
        text = ''
        start_page = 0
        i = 0
        for i, page in enumerate(document):
            if i < index_pages:
                continue
            for j, paragraph in enumerate(page):
                rank = DOCUMENT_TEMPLATE.get_paragraph_rank(
                    paragraph, language=language, parsing_data=parsing_data)
                if not DOCUMENT_TEMPLATE._is_useless(paragraph, DOCUMENT_TEMPLATE):
                    if rank > 0:
                        sentences = DocumentRunsChunkizer._segment_text(text)
                        formatted_paragraph = {
                            'sentences': [sentence.strip() for sentence in sentences],
                            'section_headers': section_hierarchy,
                            'start_page': start_page+1,
                            'end_page': i+1
                        }
                        formatted_document['paragraphs'].append(
                            formatted_paragraph.copy())
                        section_hierarchy = DocumentRunsChunkizer._resolve_section_hierarchy(
                            paragraph, section_hierarchy.copy(), language=language, parsing_data=parsing_data)
                        if rank == 1:
                            text = DOCUMENT_TEMPLATE.get_subsection_text(
                                paragraph, language=language)
                        else:
                            text = ''
                        start_page = i
                    else:
                        text += "\n" + \
                            DOCUMENT_TEMPLATE.get_plain_text(paragraph)
        sentences = DocumentRunsChunkizer._segment_text(text)
        formatted_paragraph = {
            'sentences': [sentence.strip() for sentence in sentences],
            'section_headers': section_hierarchy,
            'start_page': start_page+1,
            'end_page': i+1
        }
        formatted_document['paragraphs'].append(formatted_paragraph.copy())

        DOCUMENT_TEMPLATE = system_document_template

        return formatted_document

    @staticmethod
    def is_junk_chunk(chunk):
        return len(chunk.strip().split()) < 3

    @staticmethod
    def get_headers_with_keywords(orig_text, section_headers, language):
        headers_with_keywords = []
        text_normalizer = TextNormalizer(language=language)
        text = text_normalizer.preprocess(orig_text)

        for header in section_headers[::-1]:
            header_text = header['header']
            header_tokens = text_normalizer.preprocess(header_text)
            for token in header_tokens:
                if token not in text:
                    headers_with_keywords.append(header_text)
                    text += header_tokens.copy()
                    break

        return headers_with_keywords

    @staticmethod
    def augment_section_text(sentences, section_headers, language):
        orig_text = ' '.join(sentences)
        orig_text = orig_text.replace("󰠏", "")
        if orig_text.strip() == "":
            return ""

        augmented_headers = \
            DocumentRunsChunkizer.get_headers_with_keywords(
                orig_text, section_headers, language)
        augmented_headers = ' - '.join(augmented_headers)

        return augmented_headers

    @staticmethod
    def learn_from_paragraph_level_chunks(chunks, language, doc_id):
        learnt_chunks = list()
        text_normalizer = TextNormalizer(language=language)
        paragraph_number = 0

        for chunk in chunks:

            text = chunk["text"]
            augmented_headers = DocumentRunsChunkizer.augment_section_text(
                [text], chunk['section_headers'], language)
            paragraph_number += 1

            learnt_chunk = {
                'text': text,
                'stem_headers': text_normalizer.preprocess(
                    augmented_headers, tokenize=False),
                'augmented_text': augmented_headers + f" {text}",
                'stem_text': text_normalizer.preprocess(text, tokenize=False),
                'section_headers': chunk['section_headers'],
                'doc_id': doc_id,
                'page': chunk['page'],
                'paragraph_number': paragraph_number,
            }
            learnt_chunk.update(chunk)
            learnt_chunks.append(learnt_chunk)

        return learnt_chunks

    @staticmethod
    def get_paragraph_level_chunks(document, doc_id, language):
        text_normalizer = TextNormalizer(language=language)
        chunks = []
        title = document['title']
        paragraph_number = 1

        for paragraph in document['paragraphs']:
            chunk_template = paragraph.copy()
            chunk_template['sentences'] = paragraph['sentences'].copy()
            chunk_template['section_headers'] = paragraph['section_headers'].copy()
            chunk_template['doc_id'] = doc_id

            text = '\n'.join(paragraph['sentences'].copy())

            chunk_template['augmented_headers'] = DocumentRunsChunkizer.augment_section_text(
                chunk_template['sentences'], chunk_template['section_headers'], language)

            chunk_template['stem_headers'] = text_normalizer.preprocess(
                chunk_template['augmented_headers'], tokenize=False)

            chunk_template['section_headers'], chunk_template['header'] = DocumentRunsChunkizer.\
                get_current_lowest_section(paragraph['section_headers'], title)

            def batch(text, batch_size):
                l = len(text)
                small_texts = []
                idx = 0
                for ndx in range(0, l, batch_size):
                    ndx = ndx - idx
                    batch_text = text[ndx:min(ndx + batch_size, l)]
                    reversed_text = batch_text[::-1]
                    len_rev_text = len(reversed_text)

                    if reversed_text.find("\n"):
                        idx = reversed_text.find("\n")
                    elif reversed_text.find("."):
                        idx = reversed_text.find(".")
                    elif reversed_text.find(" "):
                        idx = reversed_text.find(" ")
                    else:
                        idx = 0

                    small_texts.append(text[ndx: ndx + len_rev_text - idx])
                return small_texts

            if len(text) > DocumentRunsChunkizer.batch_length:
                for small_text in batch(text, DocumentRunsChunkizer.batch_length):
                    chunk_detail = {'text': small_text}
                    chunk_detail['paragraph_number'] = paragraph_number
                    paragraph_number += 1
                    chunk_detail['augmented_text'] = chunk_template['augmented_headers'] + " " + \
                        small_text
                    chunk_detail['stem_text'] = text_normalizer.preprocess(small_text,
                                                                           tokenize=False)
                    new_chunk = DocumentRunsChunkizer.create_chunk(
                        chunk_template, chunk_detail)
                    chunks.append(new_chunk)

            else:
                chunk_detail = {'text': text}
                chunk_detail['paragraph_number'] = paragraph_number
                paragraph_number += 1
                chunk_detail['augmented_text'] = chunk_template['augmented_headers'] + \
                    " " + text
                chunk_detail['stem_text'] = text_normalizer.preprocess(text,
                                                                       tokenize=False)
                new_chunk = DocumentRunsChunkizer.create_chunk(
                    chunk_template, chunk_detail)
                chunks.append(new_chunk)

        chunks = [chunk for chunk in chunks
                  if not DocumentRunsChunkizer.is_junk_chunk(chunk['text'])]

        return chunks

    @staticmethod
    def create_chunk(chunk_template, chunk_detail):
        chunk = {
            'text': chunk_detail['text'],
            'header': chunk_template['header'],
            'section_headers': chunk_template['section_headers'],
            'page': chunk_template['start_page'],
        }

        return chunk


class SimpleTextChunkizer(object):

    @staticmethod
    def chunkize_text(text, min_word_limit=30):
        all_chunks = re.split(r"\s*\n\n\s*", text)

        merged_chunks = [""]
        for chunk in all_chunks:
            if len(merged_chunks[-1].split()) < min_word_limit:
                merged_chunks[-1] += '\n' + chunk
            else:
                merged_chunks.append(chunk)
        return merged_chunks


class HTMLTextChunkizer(object):

    @staticmethod
    def chunkize_text(formatted_document, doc_id, language='en-US'):
        document_chunks = DocumentRunsChunkizer.get_paragraph_level_chunks(
            formatted_document, doc_id, language=language)
        return document_chunks

    @staticmethod
    def get_template_data(parsing_template):
        base_template = None
        parsing_data = None
        if parsing_template and "key" in parsing_template:
            base_template = parsing_template["key"]
        if (
            parsing_template and "template_json" in parsing_template
            and parsing_template["template_json"]
        ):
            parsing_data = parsing_template["template_json"]
        return base_template, parsing_data

    @staticmethod
    def format_text(document, title, parsing_template=None, index_pages=0, language=LANGUAGES.EN):
        base_template, parsing_data = HTMLTextChunkizer.get_template_data(
            parsing_template)
        LOGGER.debug(f"The parsing data is -->>>> {parsing_data}")
        LOGGER.debug(f"The parsing template is -->>>> {base_template}")
        try:
            formatted_document = \
                DocumentRunsChunkizer.merge_and_split(document, title, base_template,
                                                      index_pages=index_pages, language=language, parsing_data=parsing_data)
        except:
            LOGGER.debug(
                "HTMLTextChunkizer.format_text: Dynamic parsing failed, switching to fallback parser", traceback.format_exc())
            template = None
            parsing_data = None
            if parsing_template and "key" in parsing_template:
                template = parsing_template["key"]
            LOGGER.debug(f"The parsing template is -->>>> {template}")
            try:
                formatted_document = \
                    DocumentRunsChunkizer.merge_and_split(document, title, template,
                                                          index_pages=index_pages, language=language, parsing_data=parsing_data)
            except:
                raise ParsingError(
                    f"Error in parsing using template {template}")

        return formatted_document
