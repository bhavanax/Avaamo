import re

from document_parsing_lib.config.app_config import LANGUAGES
from document_parsing_lib.document_extractor.template_configuration import \
    CustomizableTemplateConfig
from document_parsing_lib.errors import ParsingError
from logger import Logger

from .document_templates import DocumentTemplateAbstract

LOGGER = Logger(__name__)


class DocumentTemplateBOW(DocumentTemplateAbstract):

    junk = ['INTERNAL USE ONLY', '......']

    @staticmethod
    def _get_paragraph_properties(paragraph):
        all_caps = [run['text'].strip().isupper()
                    for run in paragraph if run['text'].strip() != '']
        bold = ['b' in run['attributes']
                for run in paragraph if run['text'].strip() != '']
        italics = ['i' in run['attributes']
                   for run in paragraph if run['text'].strip() != '']
        return all_caps, bold, italics

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        rank = 0
        all_caps, bold, italics = DocumentTemplateBOW._get_paragraph_properties(
            paragraph)

        if len(all_caps) >= 1 and all(all_caps) and len(bold) >= 1 and all(bold):
            rank = 3
        elif len(bold) >= 1 and all(bold) and \
                DocumentTemplateAbstract._get_token_lengths(paragraph) <= 15:
            rank = 2
        elif len(all_caps) >= 1 and all(all_caps):
            rank = 2
        elif bold and bold[0] and \
                len(DocumentTemplateBOW.get_subsection_header_text(paragraph).split()) <= 15:
            rank = 1
        elif len(bold) > 1 and italics[0] and bold[1] \
                and len(DocumentTemplateAbstract._get_clean_runs(paragraph)[0]['text'].split()) < 3 and not DocumentTemplateAbstract.get_plain_text(paragraph).strip().startswith("Note:"):
            rank = 1
        # elif re.match(r"^\(?(\w|\d+)[\)\.]", DocumentTemplateAbstract.get_plain_text(paragraph)):
        #     rank = 1
        else:
            rank = 0

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        _, bold, italics = DocumentTemplateBOW._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = DocumentTemplateAbstract.get_plain_text(paragraph[i:])
        elif len(bold) > 1 and italics[0] and bold[1]:
            i = 1
            for b in bold[1:]:
                if not b:
                    break
                i += 1
            text = DocumentTemplateAbstract.get_plain_text(paragraph[i:])
        elif re.match(r"^\(?(\w|\d+)[\)\.]", DocumentTemplateAbstract.get_plain_text(paragraph)):
            header_length = len(re.match(
                r"^\(?(\w|\d+)[\)\.]", DocumentTemplateAbstract.get_plain_text(paragraph))[0])
            text = DocumentTemplateAbstract.get_plain_text(
                paragraph)[header_length:].strip()
        else:
            text = ''
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        _, bold, italics = DocumentTemplateBOW._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = ''.join([run['text'].strip('\n') for run in
                            DocumentTemplateAbstract._get_clean_runs(paragraph)[:i]])

        elif len(bold) > 1 and italics[0] and bold[1]:
            i = 1
            for b in bold[1:]:
                if not b:
                    break
                i += 1
            text = ''.join([run['text'].strip('\n') for run in
                            DocumentTemplateAbstract._get_clean_runs(paragraph)[:i]])

        elif re.match(r"^\(?(\w|\d+)[\)\.]", DocumentTemplateAbstract.get_plain_text(paragraph)):
            if not section_hierarchy:
                section_hierarchy = []
            text = ' '.join(DocumentTemplateAbstract.get_plain_text(
                paragraph).split()[:5])
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    text = section['header'][:]
                    break
        else:
            text = ''
        return text


class DocumentTemplateEricsson(DocumentTemplateAbstract):

    junk = ['.....', 'Ericsson Internal', 'Prepared (Subject resp) No.', '2018-11-15 G',
            '2020-05-27', '2020-09-07', '2020-01-24', '2019-12-17',
            'Confidentiality Class External', 'Prepared By (Subject Responsible)',
            'Document Number Revision Date', '2019-10-21 C', 'Document Type Page', 'D 2020-04-02',
            'F 2020-04-02', '2017-10-31 A', '2019-10-21 F', '2019-10-21 E']

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        if not clean_runs:
            return "", [""], []
        section_indexes = []
        section_reference = ""
        bold = ['b' in run['attributes']
                for run in paragraph if run['text'].strip() != '']

        text = DocumentTemplateAbstract.get_plain_text(paragraph).strip()
        if re.match(r"^\d+\.?\s+\w+", text):
            section_reference = "number."

        elif re.match(r"^\d+\.\d+\s+", text):
            section_reference = "number.number"

        elif re.match(r"^\d+\.\d+\.\d+\s+", text):
            section_reference = "number.number.number"

        elif re.match(r"^\d+\.\d+\.\d+\.\d+\s+", text):
            section_reference = "number.number.number.number"

        elif re.match(r"^\d+\.\d+\.\d+\.\d+\.\d+\s+", text):
            section_reference = "number.number.number.number.number"

        if len(text) > 1 and text.isupper() and not bool(re.search(r'\d', text)):
            section_reference = "UPPER"

        for run in clean_runs:
            text = run['text'].strip()
            m1 = re.match(r"(^[A-Z\.\d]+\.)", text)

            if m1:
                section_indexes.append(m1.group(0))
            else:
                section_indexes.append("")

        return section_reference, section_indexes, bold

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, section_indexes, bold = DocumentTemplateEricsson._get_paragraph_properties(
            paragraph)

        rank = 0

        if section_reference == "number." and ((bold and all(bold)) or (len(bold) > 1 and bold[1])):
            rank = 6
        elif section_reference in ["number.number", "UPPER"]:
            rank = 5
        elif section_reference == "number.number.number":
            rank = 4
        elif section_reference == "number.number.number.number":
            rank = 3
        elif section_reference == "number.number.number.number.number":
            rank = 2
        elif len(bold) >= 1 and all(bold) and \
                DocumentTemplateAbstract._get_token_lengths(paragraph) <= 15:
            rank = 2
        elif bold and bold[0]:
            rank = 1
        # elif len(section_indexes) > 1:
        #     rank = 0
        # else:
        #     index_len = len([x for x in section_indexes[0].split('.') if x.strip() != ''])
        #     if index_len < 1:
        #         rank = 0
        #     else:
        #         rank = 4-index_len+2

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        _, _, bold = DocumentTemplateEricsson._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = DocumentTemplateAbstract.get_plain_text(paragraph[i:])
        else:
            text = DocumentTemplateAbstract.get_plain_text(paragraph)
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        _, _, bold = DocumentTemplateEricsson._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = ''.join([run['text'].strip('\n') for run in
                            DocumentTemplateAbstract._get_clean_runs(paragraph)[:i]])
        else:
            text = ''
        return text


class DocumentTemplateEricssonChapters(DocumentTemplateEricsson):

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, section_indexes, bold = DocumentTemplateEricssonChapters._get_paragraph_properties(
            paragraph)

        text = DocumentTemplateEricssonChapters.get_plain_text(paragraph)
        all_caps = text.isupper()
        rank = 0

        if len(bold) >= 1 and all(bold) and all_caps and text.lower().startswith("chapter "):
            rank = 8
        elif len(bold) >= 1 and all(bold) and all_caps and text.lower().startswith("step "):
            rank = 7
        elif section_reference == "number." and ((bold and all(bold)) or (len(bold) > 1 and bold[1])):
            rank = 6
        elif section_reference in ["number.number", "UPPER"]:
            rank = 5
        elif section_reference == "number.number.number":
            rank = 4
        elif section_reference == "number.number.number.number":
            rank = 3
        elif section_reference == "number.number.number.number.number":
            rank = 2
        elif len(bold) >= 1 and all(bold) and \
                DocumentTemplateEricssonChapters._get_token_lengths(paragraph) <= 10:
            rank = 2

        return rank


class DocumentTemplateTokyoElectron(DocumentTemplateAbstract):

    junk = ['.....']

    @staticmethod
    def ignore_paragraph(paragraph):
        text = DocumentTemplateAbstract.get_plain_text(paragraph)
        return len(text.split()) < 3 or len(text) < 6

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)

        bold = ['b' in run['attributes'] for run in clean_runs]
        section_reference = ""

        text = DocumentTemplateAbstract.get_plain_text(paragraph).strip()
        if re.match(r"^\d+\.\s", text):
            section_reference = "number."

        elif re.match(r"^\d+\.\d+\s", text):
            section_reference = "number.number"

        elif re.match(r"^\d+\.\d+\.\d+\s", text):
            section_reference = "number.number.number"

        elif re.match(r"^\d+\.\d+\.\d+\.\d+\s", text):
            section_reference = "number.number.number.number"

        return section_reference, bold

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, bold = DocumentTemplateTokyoElectron._get_paragraph_properties(
            paragraph)
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)

        rank = 0

        if bold and all(bold):
            if section_reference == "number.":
                rank = 7
            elif section_reference == "number.number":
                rank = 6
            elif section_reference == "number.number.number":
                rank = 5
            elif section_reference == "number.number.number.number":
                rank = 4
            else:
                rank = 2
        elif len(bold) > 1 and not bold[0]:
            if clean_runs[0]["text"].strip() in ["4", "6"] and bold[1]:
                rank = 3

        return rank


class DocumentTemplateUBSBasel(DocumentTemplateAbstract):

    junk = [".....", "Note: Basel III revisions published in December 2017 affect parts \
        of this publication. https://www.bis.org/bcbs/publ/d424.htm", "Basel III: A global \
            regulatory framework for more resilient banks and banking systems"]

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        italics = 0
        underlined = 0
        section_reference = ""
        rank1 = 0

        if len(clean_runs) != 1:
            return section_reference, bold, italics, underlined, rank1

        attributes = clean_runs[0]['attributes']
        text = clean_runs[0]['text']

        if text.startswith("Annex "):
            section_reference = "Annex"
        if 'b' in attributes:
            bold = 1
        if 'i' in attributes:
            italics = 1
        if 'u' in attributes:
            underlined = 1

        m = re.match(r"(^((\w|\d+|[IViv]+)\.)+\w?\s)", text)
        if m:
            section_reference = m.group(0).strip()

        if re.match(r"^(\(\w\)|\d+\.)\s", text):
            rank1 = 1

        return section_reference, bold, italics, underlined, rank1

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, bold, italics, _, rank1 = \
            DocumentTemplateUBSBasel._get_paragraph_properties(paragraph)

        rank = 0
        if bold == 1:
            if section_reference != "":
                if section_reference == "Annex":
                    rank = 6
                elif section_reference[0] == "I" or section_reference[0] == "V":
                    rank = 5
                elif section_reference[0].isupper():
                    rank = 4
                elif section_reference[0].isdigit():
                    rank = 3
            else:
                rank = 2
        elif italics == 1:
            rank = 2
        elif rank1 == 1:
            rank = 1

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):

        if re.match(r"^(\(\w\)|\d+\.)\s", DocumentTemplateAbstract.get_plain_text(paragraph)):
            header_length = len(re.match(r"^(\(\w\)|\d+\.)\s",
                                         DocumentTemplateAbstract.get_plain_text(paragraph)).groups(0)[0])
            text = DocumentTemplateAbstract.get_plain_text(
                paragraph)[header_length:].strip()
        else:
            text = ''
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        if not section_hierarchy:
            section_hierarchy = []

        if re.match(r"^(\(\w\)|\d+\.)\s", DocumentTemplateAbstract.get_plain_text(paragraph)):
            text = ' '.join(DocumentTemplateAbstract.get_plain_text(
                paragraph).split()[:5])
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    text = section['header'][:]
                    break
        else:
            text = ''
        return text


class DocumentTemplateUBSMiFID(DocumentTemplateAbstract):

    junk = ["Official Journal of the European Union"]

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        italics = 0
        underlined = 0
        section_reference = ""
        rank1 = 0
        all_caps = 0

        if len(clean_runs) == 1:

            attributes = clean_runs[0]['attributes']
            text = clean_runs[0]['text']
            if text.startswith("TITLE "):
                section_reference = "TITLE"
            if text.startswith("ANNEX "):
                section_reference = "ANNEX"
            if 'b' in attributes:
                bold = 1
            if 'i' in attributes:
                italics = 1
            if 'u' in attributes:
                underlined = 1
            if text.isupper():
                all_caps = 1

            m = re.match(r"(^((\w|\d+|[IViv]+)\.)+\w?\s)", text)
            if m:
                section_reference = m.group(0).strip()

            if re.match(r"^(\((\w|\d+)\)|\d+\.)\s", text):
                rank1 = 1

        return section_reference, bold, italics, underlined, all_caps, rank1

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, bold, italics, _, all_caps, rank1 = \
            DocumentTemplateUBSMiFID._get_paragraph_properties(paragraph)

        rank = 0

        if section_reference == "TITLE" or section_reference == "ANNEX":
            rank = 10
        elif section_reference == "":
            if all_caps == 1:
                if bold == 1:
                    rank = 9
                elif italics == 1:
                    rank = 8
                else:
                    rank = 3

            elif bold == 1:
                if italics == 1:
                    rank = 7
                elif re.match(r"^(\w\s){2,}\w", DocumentTemplateAbstract.get_plain_text(paragraph)):
                    rank = 5
                else:
                    rank = 2

            elif italics == 1:
                rank = 4
            elif re.match(r"^(\w\s){2,}\w", DocumentTemplateAbstract.get_plain_text(paragraph)):
                rank = 6
            elif rank1 == 1:
                rank = 1
        else:
            if all_caps == 1:
                rank = 3
            elif section_reference[0].isdigit():
                rank = 1
            else:
                rank = 2

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):

        if re.match(r"^(\((\w|\d+)\)|\d+\.)\s", DocumentTemplateAbstract.get_plain_text(paragraph)):
            header_length = len(re.match(r"^(\((\w|\d+)\)|\d+\.)\s",
                                         DocumentTemplateAbstract.get_plain_text(paragraph)).groups(0)[0])
            text = DocumentTemplateAbstract.get_plain_text(
                paragraph)[header_length:].strip()
        else:
            text = ''
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        if not section_hierarchy:
            section_hierarchy = []

        if re.match(r"^^(\((\w|\d+)\)|\d+\.)\s",
                    DocumentTemplateAbstract.get_plain_text(paragraph)):
            text = ' '.join(DocumentTemplateAbstract.get_plain_text(
                paragraph).split()[:5])
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    text = section['header'][:]
                    break
        else:
            text = ''
        return text

    @staticmethod
    def get_section_header_text(paragraph, language=LANGUAGES.EN):
        if re.match(r"^(\w\s){2,}\w", DocumentTemplateAbstract.get_plain_text(paragraph)):
            text = re.sub(" ", "", paragraph[0]['text'])
        else:
            text = DocumentTemplateAbstract.get_section_header_text(paragraph)

        return text


class DocumentTemplateUBSStaffVetting(DocumentTemplateAbstract):

    junk = ["Staff Vetting Level 2", "June 2018 Page", "Level 2"]

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        italics = 0
        underlined = 0
        section_reference = ""
        rank1 = 0
        all_caps = 0

        if clean_runs:
            attributes = clean_runs[0]['attributes']
            text = clean_runs[0]['text']

            if text.startswith("Annex"):
                section_reference = "Annex"

            if text.startswith("Category I"):
                section_reference = "Category"

            if 'b' in attributes:
                bold = 1
            if 'i' in attributes:
                italics = 1
            if 'u' in attributes:
                underlined = 1
            if text.isupper():
                all_caps = 1

            m = re.match(r"(^((\w|\d+|[IViv]+)\.)+\w?\s)", text)
            if m:
                section_reference = m.group(0).strip()

            if re.match(r"^(\([a-h]\))\s", text):
                rank1 = 1

            if re.match(r"^\"(\w+)\"\s", text):
                rank1 = 1

        return section_reference, bold, italics, underlined, all_caps, rank1

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, bold, _, _, _, rank1 = \
            DocumentTemplateUBSStaffVetting._get_paragraph_properties(
                paragraph)

        rank = 0

        if section_reference == "Annex":
            rank = 3

        elif bold == 1:
            if section_reference == "Category":
                rank = 2

            elif section_reference != "":
                section_count = section_reference.count('.')
                rank = 4-section_count

            elif rank1 == 1:
                rank = 1

        elif rank1 == 1:
            rank = 1

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):

        text = ""
        plain_text = DocumentTemplateAbstract.get_plain_text(paragraph)

        if re.match(r"^(\([a-h]\))\s", plain_text):
            header_length = len(
                re.match(r"^(\([a-h]\))\s", plain_text).groups(0)[0])
            text = plain_text[header_length:].strip()

        elif re.match(r"^\"(\w+)\"\s", plain_text):
            text = plain_text

        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        if not section_hierarchy:
            section_hierarchy = []
        plain_text = DocumentTemplateAbstract.get_plain_text(paragraph)

        if re.match(r"^(\([a-h]\))\s", plain_text):
            text = ' '.join(DocumentTemplateAbstract.get_plain_text(
                paragraph).split()[:5])
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    text = section['header'][:]
                    break

        else:
            m = re.match(r"^\"(\w+)\"\s", plain_text)
            if m:
                text = m.groups(0)[0]
            else:
                text = DocumentTemplateAbstract.get_section_header_text(
                    paragraph)

        return text


class DocumentTemplateStarhubFAQ(DocumentTemplateAbstract):

    junk = []

    @staticmethod
    def _get_paragraph_properties(paragraph):
        bold = False
        is_question = False
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        plain_text = DocumentTemplateAbstract.get_plain_text(paragraph)
        if clean_runs:
            attributes = clean_runs[0]
            if 'b' in attributes:
                bold = True
            if re.match(r"^Q\d+\:\s*", plain_text):
                is_question = True
        return bold, is_question

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        bold, is_question = DocumentTemplateStarhubFAQ._get_paragraph_properties(
            paragraph)
        if bold:
            return 2
        elif is_question:
            return 1
        else:
            return 0

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        return DocumentTemplateAbstract.get_plain_text(paragraph)

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        if not section_hierarchy:
            section_hierarchy = []
        _, is_question = DocumentTemplateStarhubFAQ._get_paragraph_properties(
            paragraph)
        if is_question:
            text = ' '.join(DocumentTemplateAbstract.get_plain_text(
                paragraph).split()[:5]) + '...'
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    text = section['header'][:]
                    break
        else:
            text = ''
        return text


class DocumentTemplateSamsungDDStudentInsurance(DocumentTemplateAbstract):

    junk = ["\uf06c", '.....']

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        section_reference = ""
        has_roman = 0
        split_chunk = 0
        if clean_runs:

            attributes = clean_runs[0]['attributes']
            text = clean_runs[0]['text']

            if text.startswith("Special Clause") or text.startswith("Additional Special Clause"):
                section_reference = "Clause"

            elif text.startswith("Chapter"):
                section_reference = "Chapter"

            elif text.startswith("Article"):
                section_reference = "Article"

            elif text.startswith("<Appendix"):
                section_reference = "Sub-Appendix"

            elif text.startswith("\u3010Appendix"):
                section_reference = "Main-Appendix"

            if 'b' in attributes:
                bold = 1

            if re.match(r"^I+\.?\s", text):
                has_roman = 1

            elif re.match(r"^\[\d+\]\s", text):
                section_reference = "[number]"

            elif re.match(r"^\d+\.\s", text):
                section_reference = "number."

            elif re.match(r"^[A-Z]\.\s", text):
                section_reference = "letter."

            elif re.match(r"^\d+\)\.?\s", text):
                split_chunk = 1

        return section_reference, bold, has_roman, split_chunk

    @staticmethod
    def _get_paragraph_properties_korean(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        section_reference = ""
        korean_numbers = ("가.", "나.", "다.", "라.", "마.")
        korean_letters = ("ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ",
                          "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ")
        has_roman = 0
        split_chunk = 0
        if clean_runs:

            attributes = clean_runs[0]['attributes']

            text = clean_runs[0]['text'].strip()
            text.replace("󰠏󰠏󰠏󰠏󰠏󰠏󰠏", "")

            if re.match(r"^제(\d+)관", text) or re.match(r"^(\d+)-(\d+)", text) or re.match(r"^●", text):
                section_reference = "Section"

            if re.match(r"^제(\d+)조", text) or re.match(r"^□", text):
                section_reference = "Article"

            if re.match(r"(\d+)\)", text) or re.match(r"^(\d+)급", text) or re.match(r"^✽", text) or re.match(r"^■", text) or re.match(r"^(\d+)\.", text):
                section_reference = "number)"

            # if re.match(r"(\d+)\.", text):
            #     section_reference = "number."

            # if text.startswith(korean_numbers):
            #     section_reference = "korean_letter."

            if section_reference == "":
                if re.match(r"Ⅰ-(\d+)", text):
                    section_reference = "page"

            if 'b' in attributes:
                bold = 1

            if re.match(r"^I+\.?\s", text):
                has_roman = 1

            elif re.match(r"^\[\d+\]\s", text):
                section_reference = "[number]"

            elif re.match(r"^[A-Z]\.\s", text):
                section_reference = "letter."

        return section_reference, bold, has_roman, split_chunk

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.DEFAULT, parsing_data=None):

        if language == LANGUAGES.EN:
            section_reference, bold, has_roman, split_chunk = \
                DocumentTemplateSamsungDDStudentInsurance._get_paragraph_properties(
                    paragraph)
            rank = 0

            if bold == 1:
                if has_roman == 1 or section_reference == "Main-Appendix":
                    rank = 5
                elif section_reference == "Clause" or section_reference == "[number]":
                    rank = 4
                elif section_reference in ["Chapter", "Sub-Appendix", "number."]:
                    rank = 3
                elif section_reference == "Article":
                    rank = 1
            elif section_reference == "letter.":
                rank = 2
            elif split_chunk == 1:
                rank = 1

        elif language == LANGUAGES.KO:
            section_reference, bold, has_roman, split_chunk = \
                DocumentTemplateSamsungDDStudentInsurance._get_paragraph_properties_korean(
                    paragraph)

            rank = 0
            # if bold == 1:
            if section_reference == "Section":
                rank = 3
            elif section_reference == "Article":
                rank = 2
            elif section_reference == "number)":
                rank = 1
            elif section_reference == "page":
                rank = 2
            # elif section_reference == "number.":
            #     rank = 2
            # elif section_reference == "korean_letter.":
            #     rank = 1

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.DEFAULT):

        if language == LANGUAGES.EN:
            clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
            subsection_text = ""

            if len(clean_runs) > 1:
                subsection_text = clean_runs[1]['text']
            elif len(clean_runs) == 1:
                text = clean_runs[0]['text']
                if re.match(r"^\d+\)\.?\s", text):
                    subsection_text = re.sub(r"^\d+\)\.?\s", "", text)

        elif language == LANGUAGES.KO:
            clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
            subsection_text = ""

            if len(clean_runs) > 1:
                subsection_text = clean_runs[1]['text']
            elif len(clean_runs) == 1:
                text = clean_runs[0]['text']
                if re.match(r"^\d+\)\.?\s", text):
                    subsection_text = re.sub(r"^\d+\)\.?\s", "", text)

        return subsection_text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.DEFAULT):

        if language == LANGUAGES.EN:
            if not section_hierarchy:
                section_hierarchy = []
            clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
            subsection_header = ""

            if not clean_runs:
                return subsection_header

            text = clean_runs[0]['text']

            if text.startswith("Article") and 'b' in clean_runs[0]['attributes']:
                subsection_header = text
            else:
                for section in section_hierarchy[::-1]:
                    if section['rank'] > 0:
                        text = section['header'][:]
                        break

        elif language == LANGUAGES.KO:
            if not section_hierarchy:
                section_hierarchy = []
            clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
            subsection_header = ""

            if not clean_runs:
                return subsection_header

            text = clean_runs[0]['text']

            if 'b' in clean_runs[0]['attributes'] or re.match(r"제(\d+)조", text) or re.match(r"제(\d+)관", text):
                subsection_header = text
            else:
                for section in section_hierarchy[::-1]:
                    if section['rank'] > 0:
                        text = section['header'][:]
                        break

        return subsection_header


class DocumentTemplateStanleyProductManual(DocumentTemplateAbstract):

    junk = ["ENGLISH", "PORTUGU", "....."]
    re_junk = re.compile(r"(^ENGLISH\s{3}\W\s\d+\s?)|(^\d+\s\W\sENGLISH\s?)")
    re_caps = re.compile(r"(^[A-Z0-9\s]{2,}\s)")
    re_number_bullet = re.compile(r"(^\d+\.[a-zA-Z\s]*\s)")
    re_letter_bullet = re.compile(r"(^[a-z]\.\s?)")
    re_right_arrow_bullet = re.compile(r"(^\sf\s)")
    re_caps_fig = re.compile(r"(^[A-Z\s]{2,}\s\(.*\)\s?)")
    re_fig = re.compile(r"(^[\w\s]{2,}\(.*\)\s?)")

    @staticmethod
    def split_by_run(run):
        text = run['text']
        bold = False
        if 'b' in run['attributes']:
            bold = True

        split = False
        indices = []
        # text = text.replace("\n", " ")
        if text.strip() == "":
            return split, indices

        junk = DocumentTemplateStanleyProductManual.re_junk.match(text)
        caps = DocumentTemplateStanleyProductManual.re_caps.match(text)
        number_bullet = DocumentTemplateStanleyProductManual.re_number_bullet.match(
            text)
        letter_bullet = DocumentTemplateStanleyProductManual.re_letter_bullet.match(
            text)
        right_arrow_bullet = DocumentTemplateStanleyProductManual.re_right_arrow_bullet.match(
            text)
        caps_fig = DocumentTemplateStanleyProductManual.re_caps_fig.match(text)
        fig = DocumentTemplateStanleyProductManual.re_fig.match(text)

        try:
            if junk:
                split = True
                indices.append(0)
                indices.append(len(junk.groups(0)[0]))

            elif number_bullet:
                split = True
                indices.append(0)
                indices.append(len(number_bullet.groups(0)[0]))

            elif letter_bullet:
                split = True
                indices.append(0)

            elif caps_fig:
                split = True
                indices.append(0)
                indices.append(len(caps_fig.groups(0)[0]))

            elif caps:
                split = True
                indices.append(0)
                indices.append(len(caps.groups(0)[0]))

            elif fig:
                split = True
                indices.append(0)
                indices.append(len(fig.groups(0)[0]))

            elif right_arrow_bullet:
                split = True
                indices.append(0)

        except:
            return False, []

        indices = list(set(indices))
        indices.sort()

        return split, indices

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        bold = 0
        caps = 0
        number_bullet = 0
        letter_bullet = 0
        fig = 0
        caps_fig = 0
        bullet = 0

        if clean_runs:

            attributes = clean_runs[0]['attributes']
            text = clean_runs[0]['text']

            if 'b' in attributes:
                bold = 1

            if text.isupper():
                caps = 1

            if DocumentTemplateStanleyProductManual.re_number_bullet.match(text):
                number_bullet = 1

            if DocumentTemplateStanleyProductManual.re_letter_bullet.match(text):
                letter_bullet = 1

            if DocumentTemplateStanleyProductManual.re_caps_fig.match(text):
                caps_fig = 1

            if DocumentTemplateStanleyProductManual.re_fig.match(text):
                fig = 1

            if DocumentTemplateStanleyProductManual.re_right_arrow_bullet.match(text):
                bullet = 1

        return bold, caps, number_bullet, letter_bullet, fig, caps_fig, bullet, len(clean_runs)

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        bold, caps, number_bullet, letter_bullet, fig, caps_fig, bullet, number_runs = \
            DocumentTemplateStanleyProductManual._get_paragraph_properties(
                paragraph)
        rank = 0

        if bold == 1:
            if caps_fig == 1 or caps == 1:
                rank = 3
            elif number_bullet == 1 or fig == 1:
                rank = 2
            elif letter_bullet == 1 or bullet == 1:
                rank = 1
            elif number_runs == 1:
                rank = 2

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        text = DocumentTemplateAbstract.get_plain_text(paragraph)
        text = DocumentTemplateStanleyProductManual.re_right_arrow_bullet.sub(
            r'', text)
        text = DocumentTemplateStanleyProductManual.re_letter_bullet.sub(
            r'', text)
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy, language=LANGUAGES.EN):
        return ''


class CustomizableTemplate(DocumentTemplateAbstract):

    def __init__(self, configuration=None, base_template=None):
        LOGGER.info(f"base_template: {type(base_template)}")
        self.configuration = CustomizableTemplateConfig(
            configuration=configuration)
        self.base_template = base_template
        self.hybrid_lines_header_list = None
        self.hybrid_lines_text_list = None
        if "hybrid_lines" in configuration:
            try:
                self.hybrid_lines_header_list = configuration["hybrid_lines"]["header"]
                self.hybrid_lines_text_list = configuration["hybrid_lines"]["text"]
            except KeyError:
                raise ParsingError(
                    "Incorrect template format provided. Please specify both 'header' and 'text' under 'hybrid_lines'")
        elif self.base_template is None:
            LOGGER.debug(f"Incomplete parsing information")
            raise ParsingError(
                "Incomplete configuration: provide either 'hybrid_lines' in parsing template json or a template key")

        self.junk = self.configuration.junk
        if self.base_template is not None:
            self.junk += self.base_template.junk

    def _get_paragraph_properties(self, paragraph):
        # Store the properties as a dict based on matching from the paragraph attributes
        pass

    def get_subsection_text(self, paragraph, language=LANGUAGES.EN):
        if self.hybrid_lines_text_list is None:
            return self.base_template.get_subsection_text(paragraph, language=language)

        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        plain_text = DocumentTemplateAbstract.get_plain_text(paragraph)
        subsection_text = plain_text
        for condition in self.hybrid_lines_text_list:
            if isinstance(condition, str):
                if re.match(condition, plain_text):
                    text_start = re.match(condition, plain_text).start()
                    subsection_text = plain_text[text_start:].strip()
                    break
            elif isinstance(condition, list):
                no_of_truth_runs = 0
                for run in clean_runs:
                    if all([(style in run["attributes"]) for style in condition]):
                        break
                    no_of_truth_runs += 1
                if no_of_truth_runs:
                    subsection_text = DocumentTemplateAbstract.get_plain_text(
                        clean_runs[no_of_truth_runs:]
                    )
                    break
        return subsection_text

    def get_subsection_header_text(self, paragraph, section_hierarchy, language=LANGUAGES.EN):
        if self.hybrid_lines_header_list is None:
            return self.base_template.get_subsection_header_text(paragraph, section_hierarchy, language=language)

        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        plain_text = DocumentTemplateAbstract.get_plain_text(paragraph)
        subsection_header_text = ''
        if not section_hierarchy:
            section_hierarchy = []
        for condition in self.hybrid_lines_header_list:
            if isinstance(condition, str):
                match = re.match(condition, plain_text)
                if match and match.groups(0):
                    header_length = len(
                        match.groups(0)[0])
                    subsection_header_text = plain_text[:header_length].strip()
                    break
            elif isinstance(condition, list):
                no_of_truth_runs = 0
                for run in clean_runs:
                    if all([(style in run["attributes"]) for style in condition]):
                        no_of_truth_runs += 1
                    else:
                        break
                if no_of_truth_runs:
                    subsection_header_text = DocumentTemplateAbstract.get_plain_text(
                        clean_runs[:no_of_truth_runs]
                    )
                    break
        if not subsection_header_text:
            for section in section_hierarchy[::-1]:
                if section['rank'] > 1:
                    subsection_header_text = section['header'][:]
                    break
        return subsection_header_text

    def _set_paragraph_properties(self, paragraph, headers):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        run_attributes_list = []

        for run in clean_runs:
            run_attributes_list.append(run["attributes"])

        for key, value in headers.items():
            headers[key]["is_true"] = False
            styles = value["attributes"]
            condition = value["condition"]

            if isinstance(styles, str):
                matcher = re.compile(styles)
                for run in clean_runs:
                    if matcher.search(run["text"]):
                        headers[key]["is_true"] = True
            elif isinstance(styles, list):
                bool_list = []
                for run_attributes in run_attributes_list:
                    if all(attr in run_attributes for attr in styles):
                        bool_list.append(True)
                    else:
                        bool_list.append(False)
                if condition == "all":
                    if all(bool_list):
                        headers[key]["is_true"] = True
                elif condition == "first":
                    try:
                        if bool_list[0]:
                            headers[key]["is_true"] = True
                    except:
                        pass
                elif condition == "any":
                    if any(bool_list):
                        headers[key]["is_true"] = True

        return headers

    def get_paragraph_rank(self, paragraph, language=LANGUAGES.EN, parsing_data=None):
        # Define boolean operations to get the rank
        properties = self.configuration.headers
        if not properties:
            if self.base_template is None:
                LOGGER.debug(
                    f"Can't determine rank, no parsing configuration found for 'properties' and 'ranks'; no template class found")
                raise ParsingError(
                    "Not enough information to determine paragraph rank")
            return self.base_template.get_paragraph_rank(paragraph, language, parsing_data)

        rank = 0
        properties = self._set_paragraph_properties(paragraph, properties)
        brackets = self.configuration.brackets

        for given_rank, property_expression in self.configuration.ranks.items():
            expression = []
            property_expression = property_expression.replace("(", "( ")
            property_expression = property_expression.replace(")", " )")
            property_list = property_expression.split(" ")
            for prop in property_list:
                if prop in properties.keys():
                    expression.append(str(properties[prop]["is_true"]))
                elif prop in self.configuration.binary_operators:
                    expression.append(
                        self.configuration.binary_operators[prop])
                elif prop in brackets:
                    expression.append(brackets[prop])
                else:
                    LOGGER.debug(
                        f"CustomizableTemplate.get_paragraph_rank: Incorrect token in rank expression")
                    rank = 0
                    raise ParsingError(
                        f"Unknown token {prop} found in expression provided in custom template for rank {given_rank}")
            try:
                if eval(" ".join(expression)):
                    rank = int(given_rank)
                    break
            except:
                LOGGER.debug(
                    f"CustomizableTemplate.get_paragraph_rank: Unable to evaluate expression")
                raise ParsingError(
                    f"Unable to evaluate expression provided in custom template for rank {given_rank}")

        return rank

    def split_by_run(self, run):
        split = False
        indices = []
        properties = self.configuration.headers
        if properties:
            properties = self._set_paragraph_properties([run], properties)
            expression = []
            for run_split_condition in self.configuration.run_splits:
                run_split_condition = run_split_condition.replace("(", "( ")
                run_split_condition = run_split_condition.replace(")", " )")
                property_list = run_split_condition.split(" ")
                for prop in property_list:
                    if prop in properties.keys():
                        expression.append(str(properties[prop]["is_true"]))
                    elif prop in self.configuration.binary_operators:
                        expression.append(
                            self.configuration.binary_operators[prop])
                    elif prop in self.configuration.brackets:
                        expression.append(self.configuration.brackets[prop])
                    else:
                        raise ParsingError(
                            f"Unknown token '{prop}' found in expression '{run_split_condition}'"
                        )
                try:
                    if eval(" ".join(expression)):
                        split = True
                        indices = [0]
                        break
                except:
                    raise ParsingError(
                        f"Unable to evaluate expression '{''.join(expression)}' for '{run_split_condition}'"
                    )
        return split, indices
