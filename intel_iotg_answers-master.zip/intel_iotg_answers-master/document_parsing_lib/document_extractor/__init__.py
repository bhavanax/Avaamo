from .pptx_reader import PptxReader
from .excel_reader import ExcelReader
from .text_reader import TextReader
