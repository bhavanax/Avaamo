import re

from document_parsing_lib.config.app_config import LANGUAGES
from logger import Logger

from .abstract import DocumentTemplateAbstract

LOGGER = Logger(__name__)


class DocumentTemplateIndexed(DocumentTemplateAbstract):

    junk = ['Intel Confidential', 'User Guide', 'Requirements', '594840',
            'R Alder Lake S—Schematic Design Checklist', "Schematic Design Checklist—Alder Lake S"]

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        if not clean_runs:
            return "", [""], []
        section_indexes = []
        section_reference = ""
        bold = [set(['b', 'section_header', 'header']).intersection(set(run['attributes']))
                for run in paragraph if run['text'].strip() != '']

        text = DocumentTemplateAbstract.get_plain_text(paragraph).strip()
        text = re.sub("(\d)(\.0)(\s+)", r"\1\3", text)

        alpha_count = 0
        for i in text:
            if i.isalpha():
                alpha_count += 1
        if alpha_count <= 3:
            return section_reference, section_indexes, bold

        if re.match(r"^\d\d?\s+\w+", text) or re.match(r"^[A-Z]+\s+Appendix", text):
            section_reference = "number"

        elif re.match(r"^\d+\.\d+\s+", text) or re.match(r"^[A-Z]+\.\d+\s+\w+", text):
            section_reference = "number.number"

        elif re.match(r"^\d+\.\d+\.\d+\s+", text) or re.match(r"^[A-Z]+\.\d+\.\d+\s+\w+", text):
            section_reference = "number.number.number"

        elif re.match(r"^\d+\.\d+\.\d+\.\d+\s+", text):
            section_reference = "number.number.number.number"

        elif re.match(r"^\d+\.\d+\.\d+\.\d+\.\d+\s+", text):
            section_reference = "number.number.number.number.number"

        if len(text) > 1 and text.isupper() and not bool(re.search(r'\d', text)):
            section_reference = "UPPER"

        for run in clean_runs:
            text = run['text'].strip()
            m1 = re.match(r"(^[A-Z\.\d]+\.)", text)

            if m1:
                section_indexes.append(m1.group(0))
            else:
                section_indexes.append("")

        return section_reference, section_indexes, bold

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        section_reference, section_indexes, bold = DocumentTemplateIndexed._get_paragraph_properties(
            paragraph)

        rank = 0

        if section_reference == "number" and ((bold and all(bold)) or (len(bold) > 1 and bold[1])):
            rank = 6
        elif section_reference in ["number.number"]:
            rank = 5
        elif section_reference == "number.number.number":
            rank = 4
        elif section_reference == "number.number.number.number":
            rank = 3
        elif section_reference == "number.number.number.number.number":
            rank = 2

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        _, _, bold = DocumentTemplateIndexed._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = DocumentTemplateAbstract.get_plain_text(paragraph[i:])
        else:
            text = DocumentTemplateAbstract.get_plain_text(paragraph)
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        _, _, bold = DocumentTemplateIndexed._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = ''.join([run['text'].strip('\n') for run in
                            DocumentTemplateAbstract._get_clean_runs(paragraph)[:i]])
        else:
            text = ''
        return text

    @staticmethod
    def split_by_run(run):
        text = run['text']
        if "b" in run["attributes"] and re.match(r"^\d+", text):
            return True, [len(text)]
        else:
            return False, []

    @staticmethod
    def _is_useless(paragraph, klass):
        for run in paragraph:
            if DocumentTemplateIndexed._cleanup_text(run['text']) in DocumentTemplateIndexed.junk:
                return True

        return klass.ignore_paragraph(paragraph)
