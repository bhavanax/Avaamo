from abc import ABC, abstractmethod

from document_parsing_lib.config.app_config import LANGUAGES
from logger import Logger

LOGGER = Logger(__name__)


class DocumentTemplateAbstract(ABC):

    @staticmethod
    @abstractmethod
    def _get_paragraph_properties(paragraph):
        pass

    @staticmethod
    @abstractmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        pass

    @staticmethod
    def _get_clean_runs(paragraph):
        return [run for run in paragraph if run['text'].strip() != '']

    @staticmethod
    def get_plain_text(paragraph):
        return ''.join([run['text'].strip('\n').replace("\n", " ") for run in paragraph])

    @staticmethod
    def _get_token_lengths(paragraph):
        return len(DocumentTemplateAbstract.get_plain_text(paragraph).split())

    @staticmethod
    def get_section_header_text(paragraph):
        return ''.join([run['text'].strip('\n') for run in paragraph])

    @staticmethod
    def _get_section_headers(section_hierarchy):
        return [section['header'] for section in section_hierarchy]

    @staticmethod
    def ignore_paragraph(paragraph):
        return False

    @staticmethod
    def split_by_run(run):
        return False, []

    @staticmethod
    def _is_useless(paragraph, klass):
        for run in paragraph:
            for junk in klass.junk:
                if DocumentTemplateAbstract._cleanup_text(junk) in \
                        DocumentTemplateAbstract._cleanup_text(run['text']):
                    return True
        return klass.ignore_paragraph(paragraph)

    @staticmethod
    def _cleanup_text(text):
        return ' '.join(text.split())
