import re

from document_parsing_lib.config.app_config import LANGUAGES
from logger import Logger

from .abstract import DocumentTemplateAbstract

LOGGER = Logger(__name__)


class DocumentTemplatePPTX(DocumentTemplateAbstract):

    junk = ['Intel Confidential', 'User Guide', 'Requirements', '594840',
            'R Alder Lake S—Schematic Design Checklist', "Schematic Design Checklist—Alder Lake S"]

    @staticmethod
    def _get_paragraph_properties(paragraph):
        clean_runs = DocumentTemplateAbstract._get_clean_runs(paragraph)
        if not clean_runs:
            return []

        bold = ["0" in run['attributes']
                for run in paragraph if run['text'].strip() != '']

        text = DocumentTemplateAbstract.get_plain_text(paragraph).strip()

        alpha_count = 0
        for i in text:
            if i.isalpha():
                alpha_count += 1
        if alpha_count <= 3:
            return bold

        return bold

    @staticmethod
    def get_paragraph_rank(paragraph, language=LANGUAGES.EN, parsing_data=None):
        bold = DocumentTemplatePPTX._get_paragraph_properties(
            paragraph)
        rank = 0
        if bold and all(bold):
            rank = 2

        return rank

    @staticmethod
    def get_subsection_text(paragraph, language=LANGUAGES.EN):
        bold = DocumentTemplatePPTX._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = DocumentTemplateAbstract.get_plain_text(paragraph[i:])
        else:
            text = DocumentTemplateAbstract.get_plain_text(paragraph)
        return text

    @staticmethod
    def get_subsection_header_text(paragraph, section_hierarchy=None, language=LANGUAGES.EN):
        _, _, bold = DocumentTemplatePPTX._get_paragraph_properties(
            paragraph)

        if bold and bold[0]:
            i = 0
            for b in bold:
                if not b:
                    break
                i += 1
            text = ''.join([run['text'].strip('\n') for run in
                            DocumentTemplateAbstract._get_clean_runs(paragraph)[:i]])
        else:
            text = ''
        return text

    @staticmethod
    def split_by_run(run):
        text = run['text']
        if "b" in run["attributes"] and re.match(r"^\d+", text):
            return True, [len(text)]
        else:
            return False, []

    @staticmethod
    def _is_useless(paragraph, klass):
        for run in paragraph:
            if DocumentTemplatePPTX._cleanup_text(run['text']) in DocumentTemplatePPTX.junk:
                return True

        return klass.ignore_paragraph(paragraph)
