import codecs

from document_parsing_lib.config.app_config import LANGUAGES
from commons.utils import file_size, convert_bytes
from document_parsing_lib.nlp.text_normalizer import TextNormalizer

class TextReader:
    FILE_LIMIT = 10 * 1024 * 1024
    @staticmethod
    def extract_text(document_file_path):
        txt_file_size = file_size(document_file_path)
        if txt_file_size and txt_file_size <= TextReader.FILE_LIMIT:
            with codecs.open(document_file_path, "r", encoding='utf-8') as input_file:
                document_text = input_file.readlines()
            return document_text
        else:
            raise IOError(("File size exceeds the maximum allowed "
                             f"size of {convert_bytes(TextReader.FILE_LIMIT)}."))

    @staticmethod
    def split_text(document_text, parsing_template=None, language=LANGUAGES.DEFAULT):
        chunks = []
        chunk = ""

        for line in document_text:
            if not line.strip():
                chunk = chunk.strip()
                if chunk:
                    chunks.append(chunk)
                chunk = ""
                continue
            chunk += "\n" + line.strip()

        chunk = chunk.strip()
        if chunks and chunk and chunks[-1] != chunk:
            chunks.append(chunk)
        return chunks

    @staticmethod
    def learn_from_paragraph_level_chunks(chunks, language, doc_id):
        learnt_chunks = list()
        text_normalizer = TextNormalizer(language=language)
        paragraph_number = 0

        for chunk in chunks:

            text = chunk["text"]
            header = chunk['header']
            augmented_headers = "" if text.startswith(header) else header
            paragraph_number += 1

            learnt_chunk = {
                'text': text,
                'stem_headers': text_normalizer.preprocess(
                    augmented_headers, tokenize=False),
                'augmented_text': augmented_headers + f" {text}",
                'stem_text': text_normalizer.preprocess(text, tokenize=False),
                'header': chunk['header'],
                'section_headers': chunk['section_headers'],
                'doc_id': doc_id,
                'page': chunk['page'],
                'paragraph_number': paragraph_number,
            }
            learnt_chunk.update(chunk)
            learnt_chunks.append(learnt_chunk)

        return learnt_chunks

    @staticmethod
    def chunkize_text(split_text, doc_id, language=LANGUAGES.DEFAULT):
        chunks = []
        for paragraph_number, text in enumerate(split_text):
            content = text
            if len(text.split("\n")) > 1:
                content = "\n".join(text.split("\n")[1:])
            header = text.partition("\n")[0]
            section_headers = [{
                "header": header,
                "rank": 1
            }]
            chunk = {
                'text': content,
                'header': header,
                'section_headers': section_headers,
                'page': 1,
            }
            chunks.append(chunk)

        return chunks
