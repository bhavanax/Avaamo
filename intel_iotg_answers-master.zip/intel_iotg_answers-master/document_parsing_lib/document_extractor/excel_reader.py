import codecs
import os

import numpy as np
import pandas as pd
import xlrd

from document_parsing_lib.config.app_config import LANGUAGES
from document_parsing_lib.nlp.text_normalizer import TextNormalizer
from logger import Logger

LOGGER = Logger(__name__)
SEPARATOR = "##S##"


class ExcelReader:

    MAX_ROW_LIMIT = 100000

    @staticmethod
    def extract_text(document_file_path, resource_type, language=LANGUAGES.DEFAULT):
        total_rows = 0
        text_normalizer = TextNormalizer(language)
        if resource_type and resource_type in ("xlsx, xls, zip"):
            xls = xlrd.open_workbook(document_file_path, on_demand=True)
            sheet_names = xls.sheet_names()
            sheets = []
            for i, sheet in enumerate(sheet_names):
                df = pd.read_excel(document_file_path, sheet_name=sheet)
                df = df.applymap(str)
                df = df.applymap(lambda x: x.replace("\n", " "))
                total_rows += len(df)
                columns = df.columns
                columns = columns.map(lambda x: x.replace("\n", " "))
                sentences = []
                for row in range(len(df)):
                    sentence = []
                    for col_id, column in enumerate(columns):
                        if text_normalizer.convert_lower_case(df.iloc[row][col_id].strip()) != "nan":
                            if "---" not in str(df.iloc[row][col_id]):
                                sentence.append(
                                    f"{column} {df.iloc[row][col_id]}{SEPARATOR}")
                            else:
                                sentence.append(
                                    f"{column} No data provided{SEPARATOR}")
                        else:
                            sentence.append(
                                f"{column} No data provided{SEPARATOR}")
                    sentences.append(" ".join(sentence))
                sheets.append(
                    {"sheet_name": sheet, "sentences": sentences, "columns": columns})
        elif resource_type and resource_type == "csv":
            df = pd.read_csv(document_file_path)
            df = df.applymap(str)
            df = df.applymap(lambda x: x.replace("\n", " "))
            total_rows = len(df)
            columns = df.columns
            sentences = []
            sheets = []
            columns = columns.map(lambda x: x.replace("\n", " "))
            for row in range(len(df)):
                sentence = []
                for col_id, column in enumerate(columns):
                    if text_normalizer.convert_lower_case(df.iloc[row][col_id].strip()) != "nan":
                        if "---" not in str(df.iloc[row][column]):
                            sentence.append(
                                f"{column} {df.iloc[row][col_id]}{SEPARATOR}")
                        else:
                            sentence.append(
                                f"{column} No data provided{SEPARATOR}")
                    else:
                        sentence.append(
                            f"{column} No data provided{SEPARATOR}")
                sentences.append(" ".join(sentence))
            sheet_name = os.path.splitext(
                os.path.basename(document_file_path))[0]
            sheets.append({"sheet_name": sheet_name,
                           "sentences": sentences, "columns": columns})
        else:
            raise IOError(
                f"Unable able to process file of format {resource_type}")

        if total_rows > ExcelReader.MAX_ROW_LIMIT:
            raise IOError((f"File size exceeds the maximum allowed "
                           f"size of {ExcelReader.MAX_ROW_LIMIT} rows")
                          )

        return sheets, total_rows

    @staticmethod
    def split_text(sheets, parsing_template=None, language=LANGUAGES.DEFAULT):

        for sheet in sheets:
            chunks = []
            chunk = []
            for i, sentence in enumerate(sheet["sentences"]):
                sentence = sentence.strip()

        return sheets

    @staticmethod
    def learn_from_paragraph_level_chunks(chunks, language, doc_id):
        learnt_chunks = list()
        text_normalizer = TextNormalizer(language=language)
        paragraph_number = 0

        for chunk in chunks:

            text = chunk["text"]
            paragraph_number += 1

            learnt_chunk = {
                'text': text,
                'stem_headers': "",
                'augmented_text': text,
                'stem_text': text_normalizer.preprocess(text, tokenize=False),
                'header': chunk['header'],
                'section_headers': chunk['section_headers'],
                'doc_id': doc_id,
                'page': chunk['page'],
                'paragraph_number': paragraph_number,
            }
            learnt_chunk.update(chunk)
            learnt_chunks.append(learnt_chunk)

        return learnt_chunks

    @staticmethod
    def chunkize_text(sheets, doc_id, language=LANGUAGES.DEFAULT):
        chunks = []
        c = 0
        for i, sheet in enumerate(sheets):
            columns = sheet["columns"]
            for j, text in enumerate(sheet["sentences"]):
                header = sheet["sheet_name"]
                section_headers = [{
                    "header": header,
                    "rank": 1
                }]
                chunk = {
                    'text': ExcelReader.__text_formatter(text, columns),
                    'header': header,
                    'section_headers': section_headers,
                    'page': i
                }
                c += 1
                chunks.append(chunk)

        return chunks

    @staticmethod
    def __text_formatter(text, columns):
        text_data = []
        row_data = text.split(SEPARATOR)
        row_data.pop(len(row_data)-1)
        for i, col in enumerate(columns):
            val = row_data[i].split(col)
            text_data.append(f"{col}:- {val[1].strip()}.")

        text_data = "\n".join(text_data)
        return text_data
