from urllib.error import HTTPError
from requests.exceptions import RequestException

class ValidationWarning():
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return "Validation Warning :: " + self.text

class ParsingError(Exception):
    pass


STANDARD_ERRORS = (
    IOError,
    OSError,
    ConnectionError,
    PermissionError,
    HTTPError,
    ParsingError,
    RequestException,
)

STANDARD_WARNINGS = (
    ValidationWarning,
)
