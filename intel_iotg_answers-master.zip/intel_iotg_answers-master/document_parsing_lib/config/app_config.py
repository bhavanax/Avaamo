import os
from collections import namedtuple

#CUDA_DEVICE = int(os.getenv('CUDA_DEVICE'))

LANGUAGES = namedtuple("LANGUAGES", ["EN", "KO", "DEFAULT"])
LANGUAGES.EN = "en-US"
LANGUAGES.KO = "ko-KR"
LANGUAGES.DEFAULT = LANGUAGES.EN

LANGUAGE_MAP = {
    'en': LANGUAGES.EN,
    'ko': LANGUAGES.KO,
    LANGUAGES.EN: LANGUAGES.EN,
    LANGUAGES.KO: LANGUAGES.KO,
}