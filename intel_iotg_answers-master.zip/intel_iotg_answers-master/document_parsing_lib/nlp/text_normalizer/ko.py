import re

# from konlpy.tag import Okt

from document_parsing_lib.nlp.lemmatizer import Lemmatizer
from logger import Logger
from document_parsing_lib.config.app_config import LANGUAGES
from .abstract import AbstractTextNormalizer

LOGGER = Logger
OKT = None

class KoreanTextNormalizer(AbstractTextNormalizer):
    def __init__(self):
        self.lemmatizer = Lemmatizer(language=LANGUAGES.KO)

    def get_pos_tag(self, text):
        if not text:
            return []
        doc = OKT.pos(str(text))
        return [(tok[0], tok[1]) for tok in doc]

    def tokenize(self, text):
        if not text:
            return []
        tokens = OKT.morphs(str(text), norm=True)
        return tokens

    def tokenize_and_stem(self, text, stem=True, lemmatize=False):
        tokens = OKT.morphs(text, norm=lemmatize, stem=stem)
        return tokens

    def _is_keyword(self, tag):
        bool_tag = tag.startswith('N') or tag.startswith('J') or tag.startswith('V')
        return bool_tag

    def get_query_keyword_stemmed(self, query, stem=True, lemmatize=False):
        if not query:
            return []
        tagged = self.get_pos_tag(query)
        keywords = [tok[0] for tok in tagged if self._is_keyword(tok[1])]
        if lemmatize:
            keywords = [i for i in [self.lemmatizer.stem_word(t) for t in keywords]]
        if stem:
            keywords = [i for i in [self.lemmatizer.stem_word(t) for t in keywords]]
        return keywords

    def convert_lower_case(self, data):
        return data

    def remove_stop_words(self, data):
        return data

    def stemming(self, data):
        if not data:
            return ""
        return ' '.join(OKT.morphs(str(data), norm=True, stem=True))

    def _roman_to_int(self, input_token):
        if len(input_token) < 2:
            return input_token
        input_token_mod = input_token.upper()
        nums = {'M':1000, 'D':500, 'C':100, 'L':50, 'X':10, 'V':5, 'I':1}
        sum_value = 0
        for i, char in enumerate(input_token_mod):
            try:
                value = nums[char]
                # If the next place holds a larger number, this value is negative
                if i+1 < len(input_token_mod) and nums[input_token_mod[i+1]] > value:
                    sum_value -= value
                else:
                    sum_value += value
            except KeyError:
                return input_token
        return sum_value

    def parse_roman(self, data):
        tokens = self.tokenize(str(data))
        new_data = ""
        for token in tokens:
            new_data += str(self._roman_to_int(token)) + " "

        return new_data

    def preprocess(self, data, tokenize=True, stem=True, remove_stop_words=True):
        data = self.remove_punctuation(data) #remove comma seperately
        data = self.remove_apostrophe(data)
        data = self.convert_numbers(data)
        if remove_stop_words:
            data = self.remove_stop_words(data)
        if stem:
            data = self.stemming(data)

        if tokenize:
            return self.tokenize(data)
        else:
            return data
