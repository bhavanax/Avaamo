from abc import ABC, abstractmethod
import numpy as np
from num2words import num2words

class AbstractTextNormalizer(ABC):
    @abstractmethod
    def get_pos_tag(self, text):
        pass

    @abstractmethod
    def tokenize(self, text):
        pass

    @abstractmethod
    def tokenize_and_stem(self, text, stem=True, lemmatize=False):
        pass

    @abstractmethod
    def convert_lower_case(self, data):
        pass

    @abstractmethod
    def remove_stop_words(self, data):
        pass

    def remove_punctuation(self, data):
        symbols = "!\"#$%&()*+-./:;<=>?@[\]^_`{|}~\n"
        for symbol in symbols:
            data = data.replace(symbol, ' ')
            data = data.replace("  ", " ")
        data = data.replace(',', '')
        return data

    def remove_apostrophe(self, data):
        return data.replace("'", "")

    @abstractmethod
    def stemming(self, data):
        pass

    def convert_numbers(self, data):
        tokens = self.tokenize(str(data))
        new_text = ""
        for token in tokens:
            try:
                token = num2words(int(token))
            except ValueError:
                pass
            new_text = new_text + " " + token
        new_text = new_text.replace("-", " ")
        return new_text

    @abstractmethod
    def preprocess(self, data, tokenize=True, stem=True, remove_stop_words=True):
        pass
