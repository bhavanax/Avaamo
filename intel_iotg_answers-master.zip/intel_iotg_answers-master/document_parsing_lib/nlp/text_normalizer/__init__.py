from document_parsing_lib.config.app_config import LANGUAGES

from .en import EnglishTextNormalizer
from .ko import KoreanTextNormalizer

CONFIG = {
    LANGUAGES.EN: {
        "default": EnglishTextNormalizer
    },
    LANGUAGES.KO: {
        "default": KoreanTextNormalizer
    }
}

class TextNormalizer():

    def __init__(self, language=LANGUAGES.DEFAULT, selector="default"):
        if language in CONFIG:
            app_config = CONFIG[language]
        else:
            app_config = CONFIG[LANGUAGES.DEFAULT]
        if selector in app_config:
            self.normalizer = app_config[selector]()
        else:
            self.normalizer = app_config['default']()

    def __getattr__(self, name):
        return object.__getattribute__(self.normalizer, name)
