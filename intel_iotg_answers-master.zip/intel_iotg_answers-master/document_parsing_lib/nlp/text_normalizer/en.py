import nltk
import numpy as np
import inflect
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
from document_parsing_lib.nlp.lemmatizer import Lemmatizer
from document_parsing_lib.config.app_config import LANGUAGES
from .abstract import AbstractTextNormalizer

class EnglishTextNormalizer(AbstractTextNormalizer):
    stop_words = stopwords.words('english')
    stemmer = PorterStemmer()
    lemmatizer = Lemmatizer(language=LANGUAGES.EN)
    pluralizer = inflect.engine()

    def get_pos_tag(self, text):
        pos_tags = nltk.pos_tag(nltk.word_tokenize(text))
        return pos_tags

    def tokenize(self, text):
        tokens = word_tokenize(text)
        return tokens

    def tokenize_and_stem(self, text, stem=True, lemmatize=False):
        tokens = self.tokenize(text)
        tokens = [tok for tok in tokens if tok not in self.stop_words]
        if lemmatize:
            tokens = [i for i in [self.lemmatizer.stem_word(t) for t in tokens]]
        if stem:
            tokens = [i for i in [self.stemmer.stem(t) for t in tokens]]
        return tokens

    def _is_keyword(self, tok, tag):
        bool_tag = tag.startswith('N') or tag.startswith('J') or tag.startswith('V')
        bool_tok = tok not in self.stop_words
        return bool_tag and bool_tok

    def get_query_keyword_stemmed(self, query, stem=True, lemmatize=False):
        toks = self.tokenize(query)
        tagged = nltk.pos_tag(toks)
        keywords = [tok for tok, tag in tagged if self._is_keyword(tok, tag)]
        if lemmatize:
            keywords = [i for i in [self.lemmatizer.stem_word(t) for t in keywords]]
        if stem:
            keywords = [i for i in [self.stemmer.stem(t) for t in keywords]]
        return keywords

    def convert_lower_case(self, data):
        return data.lower()
    
    def pluralize(self, data):
        data = self.remove_punctuation(data)
        return self.pluralizer.plural(data)

    def remove_stop_words(self, data):
        words = self.tokenize(str(data))
        new_text = ""
        for word in words:
            if word not in self.stop_words and len(word) > 1:
                new_text = new_text + " " + word
        return new_text

    def stemming(self, data):
        stemmer = self.stemmer
        tokens = self.tokenize(str(data))
        new_text = ""
        for token in tokens:
            new_text = new_text + " " + stemmer.stem(token)
        return new_text

    def _roman_to_int(self, input_token):
        if len(input_token) < 2:
            return input_token

        input_token = input_token.upper()
        nums = {'M':1000, 'D':500, 'C':100, 'L':50, 'X':10, 'V':5, 'I':1}
        sum_value = 0
        for i, char in enumerate(input_token):
            try:
                value = nums[char]
                # If the next place holds a larger number, this value is negative
                if i+1 < len(input_token) and nums[input_token[i+1]] > value:
                    sum_value -= value
                else:
                    sum_value += value
            except KeyError:
                return input_token.lower()
        return sum_value

    def parse_roman(self, data):
        tokens = self.tokenize(str(data))
        new_data = ""
        for token in tokens:
            new_data += str(self._roman_to_int(token)) + " "

        return new_data

    def preprocess(self, data, tokenize=True, stem=True, remove_stop_words=True, convert_numbers=True):
        data = self.convert_lower_case(data)
        data = self.remove_punctuation(data) #remove comma seperately
        data = self.remove_apostrophe(data)
        data = self.parse_roman(data)
        data = self.convert_numbers(data)
        if remove_stop_words:
            data = self.remove_stop_words(data)
        if stem:
            data = self.stemming(data)
        data = self.remove_punctuation(data)
        if convert_numbers:
            data = self.convert_numbers(data)
        if stem:
            data = self.stemming(data)
        # data = self.stemming(data) #needed again as we need to stem the words
        #needed again as num2word is giving few hypens and commas fourty-one
        data = self.remove_punctuation(data)
        #needed again as num2word is giving stop words 101 - one hundred and one
        if remove_stop_words:
            data = self.remove_stop_words(data)
        data = data.strip()
        if tokenize:
            data = self.tokenize(data)
        else:
            pass
        return data

