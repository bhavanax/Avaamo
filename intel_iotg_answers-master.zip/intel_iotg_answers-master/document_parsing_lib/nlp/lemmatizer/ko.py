# from konlpy.tag import Okt
OKT = None

STEM_EXCEPTION_LIST = []

class KoreanLemmatizer():

    def __init__(self):
        pass

    def get_lemmatized_phrase(self, phrase):
        response = OKT.morphs(phrase, norm=True)
        return " ".join(response)

    def stem_word(self, word):
        return self.get_lemmatized_phrase(word)
        