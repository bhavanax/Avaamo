import re

import nltk
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer

STEM_EXCEPTION_LIST = []

class EnglishLemmatizer():
    wordnet_stemmer = WordNetLemmatizer()
    replace_regex = re.compile(r"\s*[,.\-]\s*", re.IGNORECASE)
    apostrophe_regex = re.compile(r"\s\'\s", re.IGNORECASE)

    def __init__(self):
        pass

    def get_lemmatized_phrase(self, phrase):
        tokenized_words = nltk.word_tokenize(phrase.lower())
        response = [self.stem_word(tokenized_word) \
            for tokenized_word in tokenized_words]
        return " ".join(response)

    def stem_word(self, word):
        if word.lower() in STEM_EXCEPTION_LIST:
            return word
        t_word = self.wordnet_stemmer.lemmatize(word)
        if t_word == word:
            t_word = self.wordnet_stemmer.lemmatize(word, wordnet.VERB)
        if t_word == word:
            t_word = (lambda x, y: x if len(x) > 1 else y)\
                (self.wordnet_stemmer.lemmatize(word, wordnet.ADJ), word)
        if t_word == word:
            t_word = self.wordnet_stemmer.lemmatize(word, wordnet.NOUN)
        if t_word == word:
            t_word = self.wordnet_stemmer.lemmatize(word, wordnet.ADV)
        return t_word
