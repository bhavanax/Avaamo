from document_parsing_lib.config.app_config import LANGUAGES

from .en import EnglishLemmatizer
from .ko import KoreanLemmatizer

CONFIG = {
    LANGUAGES.EN: {
        "default": EnglishLemmatizer
    },
    LANGUAGES.KO: {
        "default": KoreanLemmatizer
    }
}

class Lemmatizer:

    def __init__(self, language=LANGUAGES.DEFAULT, selector="default"):
        if language in CONFIG:
            app_config = CONFIG[language]
        else:
            app_config = CONFIG[LANGUAGES.DEFAULT]
        if selector in app_config:
            self.lemmatizer = app_config[selector]()
        else:
            self.lemmatizer = app_config['default']()

    def __getattr__(self, name):
        return object.__getattribute__(self.lemmatizer, name)
