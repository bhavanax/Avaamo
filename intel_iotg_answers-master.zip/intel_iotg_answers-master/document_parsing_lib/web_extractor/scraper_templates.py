import json
import math
import os
import re
import time
from abc import ABC, abstractmethod
from urllib.error import HTTPError
from urllib.parse import urljoin, urlparse
from uuid import uuid4

from commons.custom_requests import CustomRequests as requests
import requests as _requests
from bs4 import BeautifulSoup, Comment
from logger import Logger
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait as wait

from document_parsing_lib.errors import ParsingError
from document_parsing_lib.web_extractor.scrapper_config import \
    AvaamoDocsScraperConfig

LOGGER = Logger(__name__)


class Scraper:

    def __init__(self, configuration=None):

        self.user_agent = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/75.0.3770.142 Safari/537.36"
        )
        self.options = Options()
        self.options.add_argument("--headless")
        self.options.add_argument("--disable-gpu")
        self.options.add_argument("--no-sandbox")

    def fetch_url(self, url, kp_id, custom_response, auth):
        headers = {"User-Agent": self.user_agent}
        if auth:
            for key, value in auth.items():
                headers[key] = value
        print(headers)
        try:
            try:
                response = requests.get(url, timeout=5, headers=headers)
                if not response.ok:
                    raise ConnectionError(
                        (
                            f"There was an error in fetching the webpage: '{url}'. "
                            f"The server responded with STATUS CODE: {response.status_code}. Contact support@avaamo.com for assistance."
                        )
                    )
            except _requests.exceptions.SSLError:
                response = requests.get(
                    url, timeout=5, headers=headers, verify=False)

            response = response.content
            title = None

            if custom_response:
                response = response.decode('utf8')
                response = json.loads(response)
                title = response.copy()
                for key in custom_response["title"]:
                    title = title[key]
                for key in custom_response["html"]:
                    response = response[key]

            content = BeautifulSoup(response, "html.parser")
            if not title:
                title = content.title.get_text() if content.title else ""

            content = BeautifulSoup(response, "html.parser")

        except _requests.exceptions.RequestException:
            raise _requests.exceptions.RequestException(
                f"The URL {url} is not reachable. Contact support@avaamo.com for assistance.")

        return title, content

    def _get_driver(self, *args):
        if not args:
            options = self.options
        else:
            options = Options()
            for arg in args:
                options.add_argument(arg)
        driver = Chrome(chrome_options=options)
        return driver

    def fetch_iframe(self, url):
        try:
            driver = self._get_driver(
                "--headless", "--disable-gpu", "--no-sandbox")
            driver.get(url)
            wait(driver, 5).until(
                EC.frame_to_be_available_and_switch_to_it("topic"))
            wait(driver, 10).until(
                EC.presence_of_element_located(
                    (By.CLASS_NAME, "MCBreadcrumbsBox_0"))
            )
            content = BeautifulSoup(driver.page_source, "html.parser")
            driver.quit()
            return content
        except:
            return None


class ScraperTemplateAbstract(ABC):
    @staticmethod
    @abstractmethod
    def _get_paragraph_properties(content):
        pass

    @staticmethod
    @abstractmethod
    def get_paragraph_rank(chunk_runs):
        pass

    @staticmethod
    def _get_clean_runs(chunks_runs):
        return [run for run in chunks_runs if run["text"].strip() != ""]

    @staticmethod
    def get_plain_text(chunks_runs):
        return " ".join([run["text"].strip("\n") for run in chunks_runs])

    @staticmethod
    def _get_token_lengths(chunks_runs):
        return len(ScraperTemplateAbstract.get_plain_text(chunks_runs).split())

    @staticmethod
    def get_section_header_text(chunks_runs):
        return "".join([run["text"].strip("\n") for run in chunks_runs])

    @staticmethod
    def _get_section_headers(section_hierarchy):
        return [section["header"] for section in section_hierarchy]

    @staticmethod
    def split_by_run(run):
        return False, []


class AvaamoDocsScraper(ScraperTemplateAbstract):

    def __init__(self, configuration=None):
        self.configuration = AvaamoDocsScraperConfig(
            configuration=configuration)

    def _update_uuid_set(self, existing_uuids, soup):
        try:
            tag_uuid = soup[self.configuration["uuid_attribute"]]
            existing_uuids.add(tag_uuid)
        except KeyError:
            LOGGER.debug(f"Did not find UUID for {soup}")
        for tag in soup.findAll():
            tag_uuid = None
            try:
                tag_uuid = tag[self.configuration["uuid_attribute"]]
                existing_uuids.add(tag_uuid)
            except KeyError:
                LOGGER.debug(f"Did not find UUID for {tag}")
                continue
        return existing_uuids

    def get_body(self, soup, iframe=False):
        for tag in soup.findAll():
            tag[self.configuration["uuid_attribute"]] = str(uuid4())

        if iframe:
            body = soup
        else:
            content_wrapper_tags = soup.findAll(
                self.configuration["content_wrapper_tags"]["name"],
                self.configuration["content_wrapper_tags"]["attrs"]
            )
            if not content_wrapper_tags:
                content_wrapper_tags = soup.findAll(
                    self.configuration["fallback_for_content_wrapper_tags"]["name"],
                    self.configuration["fallback_for_content_wrapper_tags"]["attrs"]
                )
            if content_wrapper_tags:
                body = "<br/>".join([str(tag) for tag in content_wrapper_tags])
                body = BeautifulSoup(body, "html.parser")
            else:
                body = soup.find("body")

        return body

    def sanitize_html(self, soup, url):
        for comments in soup.findAll(text=lambda text: isinstance(text, Comment)):
            comments.extract()
        uuids_to_remove = set()
        for tag in soup.find_all(True):
            if not tag.attrs:
                continue
            attrs = dict(tag.attrs)
            for attr, value in attrs.items():
                destroy = False
                if attr not in self.configuration["preserve_html_tag_attributes"]:
                    del tag.attrs[attr]
                elif attr == "src":
                    formats = self.configuration["supported_media_extensions"]
                    destroy = True
                    for format_ in formats:
                        if format_ in value:
                            try:
                                tag["src"] = urljoin(url, value)
                            except:
                                pass
                            destroy = False
                            break
                    if destroy:
                        for src_regex in self.configuration["supported_image_source_regexp"]:
                            if re.match(src_regex, value):
                                try:
                                    tag["src"] = urljoin(url, value)
                                except:
                                    pass
                                destroy = False
                                break

                elif attr == "class":
                    destroy = False
                    exclude_class = self.configuration["tag_exclusion_class_rules"]
                    exclude_ambiguous_class = self.configuration["tag_exclusion_class_and_text_rules"]
                    if value in exclude_class:
                        destroy = True

                    key = " ".join(value)
                    if key in list(exclude_ambiguous_class.keys()):
                        for tag_text in exclude_ambiguous_class[key]:
                            if tag_text in tag.get_text():
                                destroy = True
                                break
                elif attr == "href":
                    if not self.is_absolute(value):
                        try:
                            tag["href"] = urljoin(url, value)
                        except:
                            tag["href"] = "#"
                if destroy:
                    self._update_uuid_set(uuids_to_remove, tag)
        for tag in soup.find_all():
            if not tag.attrs:
                continue
            if tag[self.configuration["uuid_attribute"]] in uuids_to_remove:
                tag.decompose()
        return soup

    def scrape(self, url, kp_id, custom_response, auth):
        # LOGGER.debug(f"PATH: {os.getenv('PATH')}")
        scraper = Scraper()
        title, url_soup = scraper.fetch_url(url, kp_id, custom_response, auth)
        contains_iframe = False
        if url_soup.find("iframe"):
            _url_soup = scraper.fetch_iframe(url)
            contains_iframe = True
            if _url_soup:
                LOGGER.debug(f"Using iframe content")
                body = self.get_body(_url_soup, iframe=True)
            else:
                body = self.get_body(url_soup)
        else:
            body = self.get_body(url_soup)
        body = self.sanitize_html(body, url)
        data = self.extract_base_tags(body)
        # title = url_soup.title.get_text() if url_soup.title else ""
        return data, title, contains_iframe, body

    def scrape_local(self, url, kp_id, custom_response, auth, local_path):
        # LOGGER.debug(f"PATH: {os.getenv('PATH')}")

        # open file from html data path
        title = ""
        if local_path.endswith(".html"):
            with open(local_path, "r") as html_file:
                url_soup = BeautifulSoup(html_file, "html.parser")
                if not title:
                    title = url_soup.title.get_text() if url_soup.title else ""
        else:
            url_soup = BeautifulSoup(local_path, "html.parser")
            if not title:
                title = url_soup.title.get_text() if url_soup.title else ""

        body = self.get_body(url_soup)
        body = self.sanitize_html(body, url)
        data = self.extract_base_tags(body)
        # title = url_soup.title.get_text() if url_soup.title else ""
        # LOGGER.info(data)
        return data, title, False, body

    def extract_base_tags(self, body):
        contents = body.findAll(
            self.configuration["relavant_tags_to_extract"]
        )
        data = []
        used_uuids = set()
        for content in contents:
            if content.text.encode("utf-8"):
                try:
                    content_uuid = content[self.configuration["uuid_attribute"]]
                except KeyError:
                    content_uuid = str(uuid4())
                if content_uuid not in used_uuids:
                    # LOGGER.debug(f"WebParser.scrape ---> content: {content}")
                    data.append(content)
                    used_uuids = self._update_uuid_set(used_uuids, content)

        return data

    def _get_default_paragraph_properties(self, content):
        content = [run for run in content if run["text"].strip() != ""]
        bold = [
            "b" in run["attributes"] or "strong" in run["attributes"]
            for run in content
        ]
        header_1 = [
            "h1" in run["attributes"] for run in content
        ]
        header_2 = [
            "h2" in run["attributes"] for run in content
        ]
        header_3 = [
            "h3" in run["attributes"] for run in content
        ]
        header_4 = [
            "h4" in run["attributes"] for run in content
        ]
        li = [
            "li" in run["attributes"] for run in content
        ]
        header_5 = [
            ("h5" in run["attributes"] and "p" not in run["attributes"]
             ) or "dt" in run["attributes"]
            for run in content
        ]
        header_6 = [
            "h6" in run["attributes"] for run in content
        ]
        panel_title = [
            "panel-title" in run["attributes"]
            for run in content
        ]

        attributes = {
            "h1": {"is_true": all(header_1) and bool(len(header_1))},
            "h2": {"is_true": all(header_2) and bool(len(header_2))},
            "h3": {"is_true": all(header_3) and bool(len(header_3))},
            "h4": {"is_true": all(header_4) and bool(len(header_4))},
            "h5": {"is_true": all(header_5) and bool(len(header_5))},
            "h6": {"is_true": all(header_6) and bool(len(header_6))},
            "li": {"is_true": all(li) and bool(len(li))},
            "bold": {"is_true": all(bold) and bool(len(bold))},
            "panel_title": {"is_true": all(panel_title) and bool(len(panel_title))},
        }

        return attributes

    def _get_default_paragraph_rank(self, chunk_runs):
        properties = self._get_default_paragraph_properties(chunk_runs)
        rank = 0

        if properties["h1"]["is_true"]:
            rank = 7
        elif properties["h2"]["is_true"]:
            rank = 6
        elif properties["h3"]["is_true"]:
            rank = 5
        elif properties["panel_title"]["is_true"]:
            rank = 5
        elif properties["h4"]["is_true"]:
            rank = 4
        elif properties["h5"]["is_true"]:
            rank = 3
        elif properties["h6"]["is_true"]:
            rank = 2
        # elif properties["bold"]["is_true"]:
        #     num_tokens = len(' '.join([run["text"]
        #                                for run in chunk_runs]).split())
        #     if num_tokens < 20:
        #         rank = 2

        return rank

    def _get_paragraph_properties(self, runs, properties):
        clean_runs = [run for run in runs if run["text"].strip() != ""]
        run_attributes_list = []

        for run in clean_runs:
            run_attributes_list.append(run["attributes"])

        for key, value in properties.items():
            properties[key]["is_true"] = False
            styles = value["attributes"]
            condition = value["condition"]

            if isinstance(styles, str):
                matcher = re.compile(styles)
                for run in clean_runs:
                    if matcher.search(run["text"]):
                        properties[key]["is_true"] = True
            elif isinstance(styles, list):
                bool_list = []
                for run_attributes in run_attributes_list:
                    if all(attr in run_attributes for attr in styles):
                        bool_list.append(True)
                    else:
                        bool_list.append(False)
                if condition == "all":
                    if all(bool_list):
                        properties[key]["is_true"] = True
                elif condition == "first":
                    try:
                        if bool_list[0]:
                            properties[key]["is_true"] = True
                    except:
                        pass
                elif condition == "any":
                    if any(bool_list):
                        properties[key]["is_true"] = True

        return properties

    def get_paragraph_rank(self, chunk_runs):
        try:
            properties = self.configuration["properties"]
            ranks = self.configuration["ranks"]
            brackets = self.configuration["brackets"]
        except AttributeError:
            return self._get_default_paragraph_rank(chunk_runs)

        properties = self._get_paragraph_properties(
            chunk_runs, properties)
        rank = 0

        for given_rank, property_expression in ranks.items():
            expression = []
            property_expression = property_expression.replace("(", "( ")
            property_expression = property_expression.replace(")", " )")
            property_list = property_expression.split(" ")
            for prop in property_list:
                if prop in properties.keys():
                    expression.append(str(properties[prop]["is_true"]))
                elif prop in self.configuration["binary_operators"]:
                    expression.append(
                        self.configuration["binary_operators"][prop])
                elif prop in brackets:
                    expression.append(brackets[prop])
                else:
                    LOGGER.debug(
                        f"AvaamoDocsScraper.get_paragraph_rank: Incorrect token in rank expression")
                    rank = 0
                    raise ParsingError(
                        f"Unknown token found in expression provided in custom template for rank {given_rank}")
            try:
                if eval(" ".join(expression)):
                    rank = int(given_rank)
                    break
            except:
                LOGGER.debug(
                    f"AvaamoDocsScraper.get_paragraph_rank: Unable to evaluate expression")
                raise ParsingError(
                    f"Unable to evaluate expression provided in custom template for rank {given_rank}")

        return rank

    def get_rank_tag(self, rank):
        tag = "p"
        if rank > 6:
            tag = "h1"
        elif rank == 6:
            tag = "h2"
        elif rank == 5:
            tag = "h3"
        elif rank == 4:
            tag = "h4"
        elif rank == 3:
            tag = "h5"
        elif rank == 2:
            tag = "h6"
        elif rank == 1:
            tag = "b"
        return tag

    def get_subsection_header_text(self, chunk_runs):
        return chunk_runs[0]["text"]

    def get_subsection_text(self, chunk_runs):
        if len(chunk_runs) > 1:
            return " ".join(chunk["text"] for chunk in chunk_runs[1:])
        else:
            return ""

    def is_absolute(self, url):
        return bool(urlparse(url).netloc)
