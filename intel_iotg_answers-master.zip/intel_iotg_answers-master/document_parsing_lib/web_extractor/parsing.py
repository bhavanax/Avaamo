import json
from copy import deepcopy
from uuid import uuid4

from bs4 import BeautifulSoup

from document_parsing_lib.web_extractor.scraper_templates import AvaamoDocsScraper
from document_parsing_lib.document_extractor.parsing import DocumentRunsChunkizer, HTMLDocumentRunsParser
from document_parsing_lib.nlp.text_normalizer import TextNormalizer
from logger import Logger

LOGGER = Logger(__name__)


class Parser:
    SCRAPER_TEMPLATE = AvaamoDocsScraper()
    SCRAPER_TEMPLATE_MAP = {
        "avaamodocs": AvaamoDocsScraper()
    }
    PREVIEW_LIMIT = 0
    PREVIEW_LEN = 30000

    @staticmethod
    def _resolve_section_hierarchy(chunk_runs, section_hierarchy, html_runs):
        rank = Parser.SCRAPER_TEMPLATE.get_paragraph_rank(chunk_runs)
        if rank == 1:
            header = Parser.SCRAPER_TEMPLATE.get_subsection_header_text(
                chunk_runs)
        else:
            header = Parser.SCRAPER_TEMPLATE.get_section_header_text(
                chunk_runs)
            # print(header)

        if section_hierarchy:
            for i, section in enumerate(section_hierarchy):
                if section['rank'] <= rank:
                    section_hierarchy = section_hierarchy[:i]
                    break

        header = header.strip()
        if header:
            existing_headers = [section['header']
                                for section in section_hierarchy]
            if header not in existing_headers:
                section_hierarchy.append({
                    'rank': rank,
                    'header': header,
                    'preview_text': html_runs
                })

        return section_hierarchy

    @staticmethod
    def get_permalink(header_soup, body_soup, url):
        header_uuid = header_soup.get(
            Parser.SCRAPER_TEMPLATE.configuration["uuid_attribute"], None)
        if header_uuid:
            focus_tag = body_soup.find(
                True, {
                    Parser.SCRAPER_TEMPLATE.configuration["uuid_attribute"]: header_uuid
                }
            )
            tag_id = None
            while not tag_id and focus_tag:
                tag_id = focus_tag.get("id", None)
                if tag_id:
                    break
                focus_tag = focus_tag.parent
            if tag_id:
                return f"{url}#{tag_id}"

        return None

    @staticmethod
    def create_hierarchy(doc_runs, title, html_runs):
        formatted_document = {
            'title': title,
            'paragraphs': []
        }
        paragraphs = []
        section_hierarchy = [{
            'rank': 10,
            'header': title,
            'preview_text': BeautifulSoup(
                (f'<h1 {Parser.SCRAPER_TEMPLATE.configuration["uuid_attribute"]}='
                 f'"{str(uuid4())}">{title}</h1>'), "html.parser").h1
        }]
        sentences = []
        preview_sentences = []
        paragraph_number = 1

        min_rank = 11
        for j, chunk_runs in enumerate(doc_runs):
            if any([run["text"].strip() for run in chunk_runs]):
                rank = Parser.SCRAPER_TEMPLATE.get_paragraph_rank(chunk_runs)
                if min_rank > rank:
                    min_rank = rank

        for j, chunk_runs in enumerate(doc_runs):
            rank = Parser.SCRAPER_TEMPLATE.get_paragraph_rank(chunk_runs)
            if rank == min_rank:
                rank = 0

            if rank > 0:
                formatted_paragraph = {
                    'sentences': [sentence.strip() for sentence in sentences],
                    'preview_sentences': preview_sentences,
                    'section_headers': section_hierarchy,
                    'paragraph_number': paragraph_number
                }
                paragraph_number += 1
                paragraphs.append(formatted_paragraph.copy())
                section_hierarchy = Parser._resolve_section_hierarchy(
                    chunk_runs, section_hierarchy.copy(), html_runs[j]
                )
                if rank == 1:
                    sentences = [
                        Parser.SCRAPER_TEMPLATE.get_subsection_text(chunk_runs)]
                    preview_sentences = [html_runs[j]]
                else:
                    sentences = []
                    preview_sentences = []
            else:
                sentences.append(
                    Parser.SCRAPER_TEMPLATE.get_plain_text(chunk_runs))
                preview_sentences.append(html_runs[j])

        formatted_paragraph = {
            'sentences': [sentence.strip() for sentence in sentences],
            'preview_sentences': preview_sentences,
            'section_headers': section_hierarchy,
            'paragraph_number': paragraph_number
        }

        if formatted_paragraph['sentences']:
            paragraphs.append(formatted_paragraph.copy())

        for para in paragraphs:
            if para['sentences']:
                formatted_document['paragraphs'].append(para)

        return formatted_document

    @staticmethod
    def _get_hierarchy_hash(section):
        try:
            section_hash = section[Parser.SCRAPER_TEMPLATE.configuration["uuid_attribute"]]
        except KeyError:
            LOGGER.debug(f"Did not find UUID for {section}")
            section_hash = str(uuid4())
        return section_hash

    @staticmethod
    def _clean_whitespace(text):
        return ' '.join(text.split())

    @staticmethod
    def _is_substring(text, text_list):
        clean_text = Parser._clean_whitespace(text)
        for text_iter in text_list:
            if clean_text in text_iter:
                return True
        return False

    @staticmethod
    def generate_document_preview(document):
        preview = []
        used_sections = set()
        for paragraph in document['paragraphs']:
            paragraph_preview = []
            sections = paragraph['section_headers']
            for idx, section in enumerate(sections):
                if Parser._get_hierarchy_hash(section['preview_text']) not in used_sections:
                    paragraph_preview.append({
                        'text': str(section['preview_text']),
                        'keep': False
                    })
                    used_sections = Parser.SCRAPER_TEMPLATE._update_uuid_set(
                        used_sections, section['preview_text'])
            if paragraph_preview:
                paragraph_preview[-1]['keep'] = True
            for idx, sentence in enumerate(paragraph['sentences']):
                if Parser._get_hierarchy_hash(paragraph['preview_sentences'][idx]) not in used_sections:
                    paragraph_preview.append({
                        'text': str(paragraph['preview_sentences'][idx]),
                        'keep': True
                    })
                    used_sections = Parser.SCRAPER_TEMPLATE._update_uuid_set(
                        used_sections, paragraph['preview_sentences'][idx])

            preview.append(paragraph_preview)
        return preview

    @staticmethod
    def get_paragraph_preview(document_preview, idx, paragraph_text_len):
        preview = [
            [
                element for element in document_preview[idx] if element['keep']
            ]
        ]

        for next_preview in document_preview[idx+1:idx+Parser.PREVIEW_LIMIT]:
            next_preview_len = len(''.join(np['text'] for np in next_preview))
            if len(preview[0][0]['text']) + next_preview_len + paragraph_text_len < Parser.PREVIEW_LEN:
                preview.append(next_preview)

        return preview

    @staticmethod
    def generate_preview_text(document):
        paragraphs = document['paragraphs']
        document_preview = Parser.generate_document_preview(document)
        for idx, paragraph in enumerate(paragraphs):
            paragraph_text_len = len(
                ' '.join(sentence for sentence in paragraph['sentences']))
            paragraph['preview_text'] = json.dumps(Parser.get_paragraph_preview
                                                   (document_preview, idx, paragraph_text_len))
        document['paragraphs'] = paragraphs
        return document

    @staticmethod
    def process_url(auth, custom_response, url, kp_id, scraper_template=None, web=True, local_path=None):
        default_scraper = Parser.SCRAPER_TEMPLATE
        if scraper_template and "key" in scraper_template and scraper_template["key"] in Parser.SCRAPER_TEMPLATE_MAP:
            Parser.SCRAPER_TEMPLATE = Parser.SCRAPER_TEMPLATE_MAP[scraper_template["key"]]
        if scraper_template and "template_json" in scraper_template:
            Parser.SCRAPER_TEMPLATE = AvaamoDocsScraper(
                configuration=scraper_template["template_json"])

        # LOGGER.debug(
        #     f"WebExtractor:process_url: using template {Parser.SCRAPER_TEMPLATE.__class__.__name__}")
        if web:
            html_content, title, contains_iframe, body = Parser.SCRAPER_TEMPLATE.scrape(
                url, kp_id, custom_response, auth)
        else:
            html_content, title, contains_iframe, body = Parser.SCRAPER_TEMPLATE.scrape_local(
                url, kp_id, custom_response, auth, local_path)
        doc_runs = []

        for content in html_content:
            chunk_runs = HTMLDocumentRunsParser.parse_paragraph(content)
            doc_runs.append(chunk_runs)
        # LOGGER.debug(f"WebExtractor:process_url: got {doc_runs} runs for url")
        formatted_document = Parser.create_hierarchy(
            doc_runs, title, html_content)
        formatted_document = Parser.generate_preview_text(formatted_document)
        Parser.SCRAPER_TEMPLATE = default_scraper

        return formatted_document, title, doc_runs, contains_iframe, body

    @staticmethod
    def learn_from_paragraph_level_chunks(chunks, language, doc_id):
        learnt_chunks = list()
        text_normalizer = TextNormalizer(language=language)
        paragraph_number = 0

        for chunk in chunks:

            text = chunk["text"]
            augmented_headers = DocumentRunsChunkizer.augment_section_text(
                [text], chunk['section_headers'], language)
            paragraph_number += 1

            learnt_chunk = {
                'text': text,
                'stem_headers': text_normalizer.preprocess(
                    augmented_headers, tokenize=False),
                'augmented_text': augmented_headers + f" {text}",
                'stem_text': text_normalizer.preprocess(text, tokenize=False),
                'header': chunk['header'],
                'section_headers': chunk['section_headers'],
                'doc_id': doc_id,
                'page': chunk['page'],
                'paragraph_number': paragraph_number,
            }
            learnt_chunk.update(chunk)
            learnt_chunks.append(learnt_chunk)

        return learnt_chunks

    @staticmethod
    def get_paragraph_level_chunks(web_page, doc_id, language, url, body, add_preview_url=True):
        chunks = []
        title = web_page['title']
        preview_url = url
        for paragraph in web_page['paragraphs']:
            section_headers = [{
                'rank': section['rank'],
                'header': section['header'].strip()
            } for section in paragraph['section_headers']]
            # if language != 'en-US':
            #     sentences = Translator.translate(sentences)
            #     section_headers = DocumentRunsChunkizer.translate_section_headers(section_headers)
            #     text = ' '.join(sentences)
            section_headers, header = DocumentRunsChunkizer.get_current_lowest_section(
                section_headers, title)

            if paragraph['section_headers']:
                current_preview_url = Parser.get_permalink(
                    paragraph['section_headers'][-1]['preview_text'],
                    body, url)
                preview_url = current_preview_url or preview_url
            _chunk = {
                'text': '\n'.join(paragraph['sentences']).strip(),
                'header': header.strip(),
                'section_headers': section_headers,
                'page': 1,
                'preview_text': paragraph['preview_text'],
            }
            if add_preview_url:
                _chunk["preview_url"] = preview_url
            chunks.append(_chunk)
        chunks = [
            chunk for chunk in chunks if not DocumentRunsChunkizer.is_junk_chunk(chunk['text'])]
        return chunks
