import os

TOKEN_CONFIG = {
    "TOKEN": {
        "skills": [2211, 2212],
        "username": os.getenv("TOKEN_UNAME"),
        "password": os.getenv("TOKEN_PASSW"),
        "base_url": "https://sesseri*****.ss.sw.se:8443/api/",
        "title_key": "ArticleTitle",
        "section_keys": [
            {
                "key": "RKMTemplateKCSProblem",
                "display": "Problem"
            },
            {
                "key": "RKMTemplateEnvironment",
                "display": "Environment"
            },
            {
                "key": "RKMTemplateResolution",
                "display": "Resolution"
            },
        ]
    }
}

AUTH_CONFIG = {
    "FORM_DATA": {
        "form_data": {
            "username": {
                "id": "user",
                "value": os.getenv("UNAME")
            },
            "password": {
                "id": "password",
                "value": os.getenv("PASSW")
            },
            "action": {
                "id": "IMAGE1"
            }
        },
        "template": (
            '<!DOCTYPE html>\n\n<!-- SiteMinder Encoding=ISO-8859-1; '
            '-->\n<!--[if lte IE 6 ]><html class="ie6"><![endif]-->\n'
            '<!--[if IE 7 ]><html class="ie7"><![endif]-->\n<!--[if I'
            'E 8 ]><html class="ie8"><![endif]-->\n<!--[if IE 9 ]><ht'
            'ml class="ie9"><![endif]-->\n<!--[if gt IE 9]><html><![e'
            'ndif]-->\n<!--[if IE]><![if !IE]><![endif]--><html><!--['
            'if IE]><![endif]><![endif]-->\n<head>\n<meta content="te'
            'xt/html; charset=utf-8" http-equiv="content-type"/>\n<ti'
            'tle>\r\n\t- Enterprise Sign On\r\n</title>\n<!-'
            '-[if IE]><![if !IE]><![endif]-->\n<link delayedhref="sty'
            'les/rebrand-login-mini.css" href="" media="only screen a'
            'nd (min-width: 769px)" rel="stylesheet" type="text/css"/'
            '>\n<link delayedhref="styles/rebrand-login-mobile-mini.c'
            'ss" href="" media="only screen and (max-width: 768px), o'
            'nly screen and (max-device-width: 768px)" rel="styleshee'
            't" type="text/css"/>\n<!--[if IE]><![endif]><![endif]-->'
            '\n<!--[if IE]><link href="" delayedhref="styles/rebrand-'
            'login-mini.css" type="text/css" rel="stylesheet" /><![en'
            'dif]-->\n<link'
            )
    }
}
