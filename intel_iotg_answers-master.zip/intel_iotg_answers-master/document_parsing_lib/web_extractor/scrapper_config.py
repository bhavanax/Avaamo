import re

from document_parsing_lib.errors import ParsingError
from logger import Logger

LOGGER = Logger(__name__)


class AvaamoDocsScraperConfig:

    def __init__(self, configuration=None):
        self.uuid_attribute = "data-uuid"
        self.content_wrapper_tags = {
            "name": "div",
            "attrs": {"class": ["container container-980", "mw-body"]}
        }
        self.fallback_for_content_wrapper_tags = {
            "name": ["div", "section", "article"],
            "attrs": {
                "class": [
                    re.compile(r"\S*content\S*"),
                    "panel-group",
                    "question",
                    "right-container",
                    re.compile(r"main-*"),
                    "msai-free-form",
                    "article-body"
                ]
            }
        }
        self.preserve_html_tag_attributes = [
            "src",
            "href",
            "class",
            "id",
            "style",
            "rowspan",
            self.uuid_attribute
        ]
        self.supported_media_extensions = [
            ".jpg",
            ".jpeg",
            ".png",
            ".gif"
        ]
        self.supported_image_source_regexp = []
        self.tag_exclusion_class_rules = [
            ["footer-content"], ['ocArticleContentFooter'],
            ['ocpIntroduction-banner'], ["ocFooterWrapper"],
            ['supArticleContentFooterWrapper'], ['ocpRelatedTopics'],
            ['supAppliesToSection'], ['supMultimediaLeftNavBreadcrumbLinkContainer']
        ]
        self.tag_exclusion_class_and_text_rules = {
            "ocpSection": ["See Also"]
        }
        self.relavant_tags_to_extract = [
            "h1", "h2", "h3", "h4", "h5", "p", "img", "span", "td",
            "figure", "ol", "ul", "dd", "dt", "a", "table", "details", "summary"
        ]
        self.binary_operators = {
            "__and__": "and",
            "__or__": "or",
            "__not__": "not"
        }
        self.brackets = {
            "(": "(",
            ")": ")",
            "[": "(",
            "]": ")",
            "{": "(",
            "}": ")"
        }
        if configuration:
            self.update_config(configuration=configuration)

    def update_config(self, configuration=None):
        if configuration and isinstance(configuration, dict):
            for key, value in configuration.items():
                if key == "preserve_html_tag_attributes":
                    if isinstance(value, list):
                        value += [attr for attr in self.preserve_html_tag_attributes if attr not in value]
                    else:
                        LOGGER.debug(
                            "AvaamoDocsScraperConfig.update_config: configuration is not in the correct format.")
                        raise ParsingError(
                            "Provided dynamic template is in incorrect format.")
                setattr(self, key, value)
        else:
            LOGGER.debug("AvaamoDocsScraperConfig.update_config: configuration is NoneType or empty."
                         "Using default config....")

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)
