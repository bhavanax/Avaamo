import csv
import os
import time

import configargparse
import pandas as pd
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

from logger import Logger

LOGGER = Logger(__name__)

MAX_TIMEOUT_FAILURES = 10

def resolve_bool(bool_str, default=True):
    if bool_str.lower() == "true":
        return True
    if bool_str.lower() == "false":
        return False
    return default

def click_button(driver, click_element_xpath, wait=5):
    time.sleep(wait)
    driver.find_element_by_xpath(click_element_xpath).click()
    time.sleep(wait)

def get_driver(args):
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--incognito")
    options.add_experimental_option('prefs', {
        "download.default_directory": os.path.abspath(args.output_path)
    })
    return webdriver.Chrome(ChromeDriverManager().install(), chrome_options=options)

def login(driver, args, url):
    driver.get(url)
    wait = WebDriverWait(driver, 5)

    LOGGER.debug(f"Signing in to the portal through url '{driver.current_url}'")
    
    if args.login_method == "ericsson":
        # enter the email
        email = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='userNameInput']")))
        email.send_keys(args.username)

        # enter password
        driver.find_element_by_xpath("//input[@id='passwordInput']").send_keys(args.password)

        # click on signin button
        driver.find_element_by_xpath("//span[@id='submitButton']").click()

        LOGGER.debug(f"Signed in to the portal using the credentials provided")

        if resolve_bool(args.use_secure_token):
            LOGGER.debug(f"Waiting for OTP input prompt...")
            # wait for the 2FA feild to display
            authField = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="OTPInput"]')))

            SECURE_TOKEN = str(input("Please enter your VIP Access Token: ")).strip().lower()

            # enter the token
            authField.send_keys(SECURE_TOKEN)

            # click on the button to complete 2FA
            driver.find_element_by_xpath("//input[@id='submitButton']").click()

    elif args.login_method == "ericsson-msft":
        email = wait.until(EC.presence_of_element_located(
                (By.XPATH, "//input[@name='loginfmt']")))
        email.send_keys(args.username)
        email.send_keys(Keys.ENTER)
        time.sleep(5)

        # enter password
        driver.find_element_by_xpath("//input[@id='passwordInput']").send_keys(args.password)

        # click on signin button
        driver.find_element_by_xpath("//span[@id='submitButton']").click()

        LOGGER.debug(f"Signed in to the portal using the credentials provided")
        if resolve_bool(args.use_secure_token):
            LOGGER.debug(f"Waiting for OTP input prompt...")
            # wait for the 2FA feild to display
            authField = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="OTPInput"]')))

            SECURE_TOKEN = str(input("Please enter your VIP Access Token: ")).strip().lower()

            # enter the token
            authField.send_keys(SECURE_TOKEN)

            # click on the button to complete 2FA
            driver.find_element_by_xpath("//input[@id='submitButton']").click()
    
    elif args.login_method == "azure":
        #enter the email
        email = wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='i0116']")))
        email.send_keys(args.username)

        #click on next button
        driver.find_element_by_xpath("//*[@id='idSIButton9']").click()

        #enter password
        password = wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='i0118']")))
        password.send_keys(args.password)

        #click on sign in button
        driver.find_element_by_xpath("//*[@id='idSIButton9']").click()

        #don't stay signed in
        stay_signed_in = wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='idBtn_Back']")))
        stay_signed_in.click()

    LOGGER.info(f"Sign in complete, starting data download...")

def main(args):


    urls_data = pd.read_csv(args.resource_path_list)
    first_row = urls_data.iloc[0]
    driver = get_driver(args)
    login(driver, args, first_row["Path"])

    if not os.path.exists(args.output_path):
        raise OSError(f"Directory does not exist '{args.output_path}'")

    output_file_path = os.path.join(args.output_path, 'html_paths.csv')
    with open(output_file_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Path", "Local Path"])

    html_file_paths = []
    idx = 0
    length_of_df = len(urls_data)
    num_timeout_failures = 0
    while idx < length_of_df:
        row = urls_data.iloc[idx]
        url_path = row["Path"].strip()
        LOGGER.debug(f"Getting page source of '{url_path}'")
        try:
            driver.get(url_path)
            LOGGER.debug(f"Waiting for content to load...")
            if not args.click_element_xpath:
                time.sleep(5)
            else:
                LOGGER.debug(f"Clicking {args.click_element_xpath} element...")
                click_button(driver, args.click_element_xpath)

            content = driver.page_source
        except TimeoutException:
            if num_timeout_failures >= MAX_TIMEOUT_FAILURES:
                raise
            LOGGER.error(f"Encountered TimeoutException while fetching '{url_path}'... Restarting driver...")
            num_timeout_failures += 1
            driver.close()
            driver = get_driver(args)
            login(driver, args, url_path)
            continue
        html_file = os.path.join(args.output_path, str(url_path.rsplit('/', 1)[-1]) + '.html')
        LOGGER.debug(f"Writing for content to '{html_file}'")

        with open(html_file, 'w') as f:
            f.write(content)

        LOGGER.info(f"Successfully retrieved html page for {url_path}")

        html_file_paths.append(html_file)
        with open(output_file_path, 'a+', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([url_path, html_file])
        idx += 1

    LOGGER.info((
        f"Writing all html paths to '{output_file_path}'. "
        f"This path list can be used as resource_path_list to Parse the urls in "
        f"'{args.resource_path_list}' using resource_type 'html'"
        ))
    
    output_file_path = os.path.join(args.output_path, 'resource_list_local_paths.csv')
    urls_data["Local Path"] = html_file_paths
    urls_data.to_csv(output_file_path, index=False)

    LOGGER.info("----- DONE -----")


if __name__ == "__main__":

    PARSER = configargparse.ArgParser()

    PARSER.add(
        "-c", "--config", is_config_file=True, help="config file path"
    )
    PARSER.add(
        "--resource_path_list",
        default=None,
        type=str,
        required=True,
        help="Local file path to the file that contains a list of URLs",
    )
    PARSER.add(
        "--output_path",
        default=None,
        type=str,
        required=True,
        help="Path to the output dir where results will be stored",
    )
    PARSER.add(
        "--username",
        default=None,
        type=str,
        required=True,
        help="Username to be used for authentication",
    )
    PARSER.add(
        "--password",
        default=None,
        type=str,
        required=True,
        help="password to be used for authentication",
    )
    PARSER.add(
        "--use_secure_token",
        default="true",
        type=str,
        help="Is secure token required for authentication. (true/false)",
    )
    PARSER.add(
        "--click_element_xpath",
        default=None,
        type=str,
        help="XPATH of element which should be clicked after content loads, defaults to None",
    )
    PARSER.add(
        "--login_method",
        default=None,
        choices=["ericsson", "ericsson-msft", "azure"],
        type=str,
        required=True,
        help="Login method to be used depending on the login server"
    )

    ARGS = PARSER.parse_args()

    main(ARGS)
