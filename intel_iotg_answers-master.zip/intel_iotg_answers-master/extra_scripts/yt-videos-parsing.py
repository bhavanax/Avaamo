import json
from urllib.parse import parse_qs, urlparse

from commons.custom_requests import CustomRequests as requests
from bs4 import BeautifulSoup
from youtube_transcript_api import YouTubeTranscriptApi

output_path = "path/to/output/file.json"

video_urls = [
    "https://www.youtube.com/watch?v=**********"
]

output_chunks = {}

embed_format = "https://www.youtube.com/embed/{video_id}"
full_page_format = "https://www.youtube.com/watch?v={video_id}"

for video_url in video_urls:
    parsed_url = urlparse(video_url)
    current_video_id_list = parse_qs(parsed_url.query).get("v")
    if current_video_id_list:
        current_video_id = current_video_id_list[0]
    else:
        print(f"Could not find video_id for URL: '{video_url}'")
        continue

    video_title = BeautifulSoup(
        requests.get(full_page_format.format(
            video_id=current_video_id)).content, 'html.parser').title.get_text().strip(
                " - YouTube")

    transcript = YouTubeTranscriptApi.get_transcript(current_video_id)
    print(f"Recieved {len(transcript)} lines for '{video_title}'")

    transcript_text = '\n'.join([t['text'] for t in transcript])

    doc = {
        "document": {
            "chunks": [{
                "text": transcript_text.strip(),
                "header": video_title,
                "section_headers": [{
                    "header": video_title,
                    "rank": 10
                }]
            }],
            "url": embed_format.format(video_id=current_video_id),
            "name": video_title,
            "document_type": "url"
        }
    }

    output_chunks[video_url] = doc

print(f"Formatted {len(output_chunks)} docs out of {len(video_urls)} URLs")

with open(output_path, 'w') as json_file:
    json.dump(output_chunks, json_file, indent=4)

print(f"Dumped output to '{output_path}'")
