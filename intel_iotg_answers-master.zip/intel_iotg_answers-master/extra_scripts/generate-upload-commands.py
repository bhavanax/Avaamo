import os

working_dir = ""
instance = ""
access_token = "-------------------------------"

working_dir = os.path.abspath(working_dir)
print(f"Using working_dir '{working_dir}'")

json_files = [
    os.path.join(working_dir, file_path)
    for file_path in os.listdir(working_dir)
    if os.path.isfile(os.path.join(working_dir, file_path)) and os.path.splitext(file_path)[-1] == ".json"]
print(f"Got JSON file paths {json_files}")

kp_ids = [int(os.path.basename(file_path).split('_')[0]) for file_path in json_files]
print(f"Got KP-IDs {kp_ids}")

print(f"Generating {len(kp_ids)} commands and configs")

config_paths = [os.path.join(working_dir, f"{kp_id}_config.txt") for kp_id in kp_ids]

config_text = '''
output_path={output_path}
instance={instance}
kp_id={kp_id}
access_token={access_token}
chunks_path={chunks_path}
'''.strip()

for idx, config_path in enumerate(config_paths):
    print(f"Writing config to '{config_path}'")
    with open(config_path, 'w') as config_file:
        config_file.write(config_text.format(
            output_path=working_dir,
            instance=instance,
            kp_id=kp_ids[idx],
            access_token=access_token,
            chunks_path=json_files[idx]
        ))

with open("upload_script.sh", 'w') as shell_file:
    print(f"Writing script to 'upload_script.sh'")
    shell_file.writelines([f"python parsing.py -c {config_path} Upload\n" for config_path in config_paths])

print("--- DONE ---")
