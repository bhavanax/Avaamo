from bs4 import BeautifulSoup
import requests
import re
import pandas as pd


base_domain = "https://wcm-stg.intel.com"
base_url = "https://wcm-stg.intel.com/content/dam/products/ark-seedlist.html"
sitemap_filter = r"us_en"
url_filter = r"/products/[0-9]"
output_path = "./parsing_data/intel_smg/ark/all_urls.csv"

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 "
    "Safari/537.36")


def get_matching_urls(url, filter=None):
    print(f"Sending request for {url}")
    sitemap_html = requests.get(url, headers={"User-Agent": USER_AGENT})

    sitemap_soup = BeautifulSoup(sitemap_html.content, 'html.parser')

    all_urls = []
    for a_tag in sitemap_soup.findAll("a"):
        href = a_tag.attrs.get("href")
        if href == "" or href is None:
            continue
        else:
            if filter is None:
                all_urls.append(href)
            elif re.search(filter, href):
                all_urls.append(href)

    return all_urls


all_sitemaps = get_matching_urls(base_url, sitemap_filter)
all_urls = []
for sitemap in all_sitemaps:
    urls = get_matching_urls(sitemap, url_filter)
    all_urls += urls

df = pd.DataFrame()
df["Path"] = all_urls
df.to_csv(output_path, index=False)
