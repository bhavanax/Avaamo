import json
from urllib.parse import urlparse

import pandas as pd


#constants
INPUT_PATH = "~/path/to/input/file.csv"
OUTPUT_PATH = "~/path/to/output/file.json"

def _resolve_section_hierarchy(chunk_runs, section_hierarchy):
    text, tag = chunk_runs
    rank = get_paragraph_rank(tag)
    header = text.strip()

    if section_hierarchy:
        for i, section in enumerate(section_hierarchy):
            if section['rank'] <= rank:
                section_hierarchy = section_hierarchy[:i]
                break

    if header != "":
        existing_headers = [section['header'] for section in section_hierarchy]
        if header not in existing_headers:
            section_hierarchy.append({
                'rank': rank,
                'header': header
            })

    return section_hierarchy


def get_paragraph_rank(tag):
    tag = tag.strip()

    rank = 0
    if tag == 'h1':
        rank = 7
    if tag == 'h2':
        rank = 6
    if tag == 'h3':
        rank = 5
    if tag == 'h4':
        rank = 4
    if tag == 'h5':
        rank = 3
    if tag == 'h6':
        rank = 2
    if tag == 'strong':
        rank = 2
    return rank


def get_header_text(section_hierarchy):
    header = ""
    if section_hierarchy:
        header = sorted(
            section_hierarchy, key=lambda section: section["rank"], reverse=True)[-1]["header"]
    return header


def format_chunks(doc_runs):
    sentences = []
    paragraphs = []
    section_hierarchy = []
    paragraph_number = 0
    for j, chunk_runs in enumerate(doc_runs):
        text, tag = chunk_runs
        if not isinstance(text, str):
            continue
        rank = get_paragraph_rank(tag)
        paragraph_number = j
        if rank > 0:
            plain_text = "\n".join([sentence.strip()
                                    for sentence in sentences])
            if plain_text:
                formatted_paragraph = {
                    'text': plain_text,
                    'section_headers': section_hierarchy,
                    'header': get_header_text(section_hierarchy),
                    'paragraph_number': j
                }
                paragraphs.append(formatted_paragraph.copy())
            section_hierarchy = _resolve_section_hierarchy(
                chunk_runs, section_hierarchy.copy()
            )
            sentences = []
        else:
            sentences.append(text.strip())
    formatted_paragraph = {
        'text': "\n".join([sentence.strip() for sentence in sentences]),
        'section_headers': section_hierarchy,
        'header': get_header_text(section_hierarchy),
        'paragraph_number': paragraph_number+1
    }

    if formatted_paragraph['text']:
        paragraphs.append(formatted_paragraph.copy())

    for idx, paragraph in enumerate(paragraphs):
        paragraph["paragraph_number"] = idx+1

    return paragraphs


def form_document(df_group):
    paragraphs = format_chunks(
        zip(df_group["content"], df_group["content_type"]))

    url = df_group["url"].unique().tolist()[0]
    parsed_url = urlparse(url)
    return {
        url: {
            "document": {
                "chunks": paragraphs,
                "url": url,
                "name": f"{parsed_url.hostname} - {parsed_url.path.strip('/')}",
                "document_type": "url"
            }
        }
    }

def main(*_args):
    input_df = pd.read_csv(INPUT_PATH)
    all_documents = dict()

    url_groups = input_df.groupby(["url"])
    print(f"Collecting {len(url_groups.groups.keys())} documents to parse...")
    for idx, current_url in enumerate(url_groups.groups.keys()):
        print(f"Processing group {idx:4d} with URL '{current_url}'")
        document = form_document(url_groups.get_group(current_url))
        all_documents.update(document)
    print(f"Parsed {len(all_documents)} documents, saving to {OUTPUT_PATH}...")

    with open(OUTPUT_PATH, 'w') as json_file:
        json.dump(all_documents, json_file, indent=4)

if __name__ == "__main__":
    main()
