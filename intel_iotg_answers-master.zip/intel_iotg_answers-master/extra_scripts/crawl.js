const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
const fs = require('fs');

puppeteer.use(StealthPlugin());

let baseUrl = "---------------------------------------";
let internalLinks = [
    {
        name: "-------- Help",
        url: "---------------------------------------"
    }
];

async function get_all_website_links(url, page) {
  await page.goto(url, {
    waitUntil: "networkidle2",
    timeout: 3000,
  });
  let hrefs = await page.evaluate(() =>
    // let's just get all links and create an array from the resulting NodeList
    Array.from(document.querySelectorAll("a")).map((anchor) => anchor.href));
  let absHrefs = await hrefs.map((href) => new URL(href, baseUrl).href);
  let internalUrls = await internalLinks.map((linkObj) => linkObj.url)
  let validHrefs = await absHrefs.filter(
    (href) => !!href && href.includes(baseUrl) && !internalUrls.includes(href)
  );
  let hrefObjects = await validHrefs.map((href) => { return {name: null, url: href};});
  if (validHrefs.length) console.log(`Found ${validHrefs.length} HREFs`);
  internalLinks.push(...hrefObjects);
  let currentLink = internalLinks.find((linkObject) => linkObject.url === url);
  if (!!currentLink) currentLink.name = await page.title();
  return validHrefs;
}

async function crawl(url, page) {
  let links = await get_all_website_links(url, page);
  for (let link of links) await crawl(link, page);
}

puppeteer.launch({ headless: true }).then(async (browser) => {
  console.log("Running tests..");
  const page = await browser.newPage();
  await crawl(baseUrl, page);
  await browser.close();
  fs.writeFileSync('crawled-urls.json', JSON.stringify(internalLinks));
  console.log(`All done, saved ${internalLinks.length} URLs. ✨`);
});
