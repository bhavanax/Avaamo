import pandas as pd
from progress.bar import Bar
import asyncio
from aiohttp import ClientSession
import traceback

in_csv_path = "../parsing_data/intel_smg/psg_pod/urls.csv"
out_csv_path = "../parsing_data/intel_smg/psg_pod/reachable_urls.csv"

df = pd.read_csv(in_csv_path)
urls = df["Path"].tolist()


def batch(iterable, batch_size=1):
    total_length = len(iterable)
    for ndx in range(0, total_length, batch_size):
        yield iterable[ndx:min(ndx + batch_size, total_length)]


async def run_request(url, session):
    try:
        resp = await session.request(method="HEAD", url=url)
        status = resp.status
    except Exception:
        print(traceback.format_exc())
        status = -1

    return url, status


async def get_status(urls, session):
    all_results = []

    bar = Bar('Processing', max=len(urls)/8)
    for url_batch in batch(urls, 8):
        results = await asyncio.gather(*[run_request(url, session) for url in url_batch])
        all_results += results
        bar.next()

    bar.finish()

    return all_results


loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
client = ClientSession(loop=loop)
all_status = loop.run_until_complete(get_status(urls, client))
loop.close()
client.close()

df = pd.DataFrame(all_status, columns=['Path', 'Status'])
df.to_csv(out_csv_path, index=False)
