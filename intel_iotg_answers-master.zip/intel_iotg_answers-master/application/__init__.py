from flask import Flask, jsonify
from .parse_document import PARSING_APP
from .gunicorn_conf import bind

app = Flask(__name__)
app.register_blueprint(PARSING_APP)


@app.route('/')
def index():
    return jsonify({'ready': True})


print(f"App running at {bind}")
