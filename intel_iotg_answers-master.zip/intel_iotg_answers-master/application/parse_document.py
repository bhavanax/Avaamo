from flask import request, Blueprint
import json
from flask_api import exceptions

from parsing_manager import ParsingManager
from kp_manager.api_helper import APIHelper


PARSING_APP = Blueprint('PARSING_APP', __name__)


@PARSING_APP.route('/parse-document', methods=["POST"])
def parse_document():
    headers = request.headers
    if "Access-Token" not in headers or not headers["Access-Token"]:
        raise exceptions.NotAuthenticated(detail="Access-Token is not present")
    else:
        access_token = headers["Access-Token"]

    upload_result = {"status": False}
    data = json.loads(request.data)
    try:
        document_group_id = data["document_group_id"]
        api_server = data["api_server"]
        document = data["document"]

        doc_type = document["type"]
        if doc_type != "url":
            content = document["content"]
        else:
            content = None
        name = document["name"]
        url = document.get("preview_url")
        document_attributes = document.get("attributes", None)
        parsing_template = document.get("parsing_template", None)
        if parsing_template is not None:
            parsing_template = json.loads(parsing_template)
        language = document.get("language", "en-US")

        summary, parsed_document = ParsingManager.parse_document(url,
                                                                 doc_type,
                                                                 parsing_template,
                                                                 language,
                                                                 None,  # custom_response
                                                                 None,  # auth_token
                                                                 document_attributes,
                                                                 0,  # index_pages,
                                                                 6,  # parsing_template_id default html
                                                                 local_path=content,
                                                                 add_preview_url=False)

        parsed_document[url]["name"] = name
        api_helper = APIHelper(api_server, access_token, document_group_id)
        upload_result = ParsingManager.upload_document(
            url, parsed_document[url], api_helper)

    except KeyError as exc:
        raise exceptions.ParseError(detail=exc)

    return upload_result


@PARSING_APP.route('/delete-document', methods=['DELETE'])
def delete_document():
    headers = request.headers
    if "Access-Token" not in headers or not headers["Access-Token"]:
        raise exceptions.NotAuthenticated(detail="Access-Token is not present")
    else:
        access_token = headers["Access-Token"]

    delete_result = {"status": False}
    data = json.loads(request.data)

    document_group_id = data["document_group_id"]
    api_server = data["api_server"]

    url = data.get("preview_url", None)
    document_id = data.get("document_id", None)

    if document_id is not None:
        data = {
            "id": document_id,
            "document_group": document_group_id
        }
    elif url is not None:
        data = {
            "source_url": url,
            "document_group": document_group_id
        }

    api_helper = APIHelper(api_server, access_token, document_group_id)
    response = api_helper.delete_document(data)
    if response is not None:
        delete_result["status"] = True

    return delete_result
