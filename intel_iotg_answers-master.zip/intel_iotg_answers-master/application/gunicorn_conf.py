import os

# Concurrency
workers = os.getenv("GUNICORN_WORKERS") or '4'
threads = os.getenv("GUNICORN_THREADS") or '2'
worker_class = "gevent"

# Connection
worker_connections = os.getenv("GUNICORN_WORKER_CONNECTIONS") or '100'

bind = "0.0.0.0:" + (os.getenv("APPLICATION_PORT") or '5000')

# Logs
loglevel = "debug"
accesslog = "./logs/server.log"
errorlog = "./logs/server.log"

# Lifecycle
keepalive = os.getenv("GUNICORN_TIMEOUT") or '600'
timeout = os.getenv("GUNICORN_TIMEOUT") or '600'

max_requests = os.getenv("GUNICORN_MAX_REQUESTS") or '250'
max_requests_jitter = os.getenv("GUNICORN_MAX_REQUESTS_JITTER") or '50'
