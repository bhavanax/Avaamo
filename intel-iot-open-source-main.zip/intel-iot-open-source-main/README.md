# Intel Iot Open Source
*Before developing, building or deploying the source code, the following steps needs to be done in the root directory of the project*
1. Install Nodejs and NPM
2. Install the following packages globally
    * @angular/cli
    * grunt-cli
3. Navigate to the root directory of the project
4. Install the local packages in the `package.json` file

# Development
Run the following commands in the Terminal to start the dev server. 
* `ng serve`
    * Navigate to `http://localhost:4200/` in the web browser to see the application.

* *Note: By default, the app will be automatically reloaded if changes are made to the files.*

# Deployment/Production
## Build
* `ng build`
    Build artifacts will be created and stored in the `dist/intel-iot-open-source` directory.
    
## Resources

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
