import { Component, Input, OnInit } from '@angular/core';
import { Repo } from 'src/app/models/Repo';

@Component({
  selector: 'app-repo',
  templateUrl: './repo.component.html',
  styleUrls: ['./repo.component.css']
})
export class RepoComponent implements OnInit {

  @Input() repo: Repo = new Repo('', '', 0, 0, '', '', '', '');
  name: string = '';
  description: string = '';
  stars: number = 0;
  forks: number = 0;
  imageSrc: string = '';
  programmingLanguage: string = '';
  contentType: string = '';
  url: string = '';
  
  constructor() { }

  ngOnInit(): void {
    this.name = this.repo.name;
    this.description = this.repo.description;
    this.imageSrc = this.repo.imageSrc;
    this.programmingLanguage = this.repo.language;
    this.contentType = this.repo.type;
    this.url = this.repo.url;
    this.stars = this.repo.stars
    this.forks = this.repo.forks
  }

}
