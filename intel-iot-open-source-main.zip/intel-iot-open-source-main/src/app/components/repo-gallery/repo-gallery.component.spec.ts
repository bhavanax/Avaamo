import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RepoGalleryComponent } from './repo-gallery.component';

describe('RepoGalleryComponent', () => {
  let component: RepoGalleryComponent;
  let fixture: ComponentFixture<RepoGalleryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RepoGalleryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RepoGalleryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
