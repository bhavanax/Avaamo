import { Component, OnInit } from '@angular/core';
import { Repo } from 'src/app/models/Repo';

@Component({
  selector: 'app-repo-gallery',
  templateUrl: './repo-gallery.component.html',
  styleUrls: ['./repo-gallery.component.css']
})
export class RepoGalleryComponent implements OnInit {
  repos: Array<Repo> = [];
  originalRepos: Array<Repo> = [];
  constructor() { }

  ngOnInit(): void {
    
    /*for (var i = 0; i < 10; i++) {
      // TODO: Create an array with these repos
      this.repos[i] = new Repo('name '+i, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore', '', i % 2 === 0 ? 'Python' : 'C', '', '')
    }*/
    // Initially updated 1/7/2022 4:32pm
    this.repos.push(new Repo('OpenVINO Notebooks', '📚 A collection of Jupyter notebooks for learning and experimenting with OpenVINO 👓', 496, 99,'', 'Jupyter Notebook', '', 'https://github.com/openvinotoolkit/openvino_notebooks'))

    this.repos.push(new Repo('ONNX', 'Accelerate ONNX models on Intel CPUs, GPUs and VPUs with ONNX Runtime and the Intel OpenVINO execution provider.', 0, 2300,'', 'C++', '', 'https://github.com/openvinotoolkit/onnx'))
    
    this.repos.push(new Repo('OpenVINO integration with Tensorflow', 'OpenVINO™ integration with TensorFlow, designed for TensorFlow* developers who want to get started with OpenVINO™ in their inferencing applications.', 112, 21,'', 'C++', '', 'https://github.com/openvinotoolkit/openvino_tensorflow'))

    this.repos.push(new Repo('MMDetection', 'This is an Object Detection and Instance Segmentation toolbox, that is a part of OpenVINO™ Training Extensions.', 74, 6500,'', 'Python', '', 'https://github.com/openvinotoolkit/mmdetection'))

    this.repos.push(new Repo('Model Server', 'A scalable inference server for models optimized with OpenVINO™', 500, 123,'', 'C++', '', 'https://github.com/openvinotoolkit/model_server'))
    
    this.repos.push(new Repo('NNCF', 'Neural Network Compression Framework for enhanced OpenVINO™ inference', 385, 98,'', 'Python', '', 'https://github.com/openvinotoolkit/nncf'))
    
    this.repos.push(new Repo('Meta IoT Cloud', 'OpenEmbedded layer to add support for multiple cloud service provider solutions including IBM Cloud, Microsoft Azure, Amazon Web Services (AWS) & Google Cloud Platform.', 58, 75,'', 'Python', '', 'https://github.com/intel-iot-devkit/meta-iot-cloud'))
    
    this.repos.push(new Repo('Smart Retail Analytics', 'Use computer vision inference in the Intel® Distribution of OpenVINO™ toolkit to provide analytics on customer engagement, store traffic, and shelf inventory.', 52, 30,'', 'Python', '', 'https://github.com/intel-iot-devkit/smart-retail-analytics'))

    this.repos.push(new Repo('Safety Gear Detector', 'Observe workers as they pass in front of a camera to determine if they have adequate safety protection.', 47, 36,'', 'Python', '', 'https://github.com/intel-iot-devkit/safety-gear-detector-python'))

    this.repos.push(new Repo('Smart Video Workshop', 'Learn about the workflow using Intel® Distribution of OpenVINO™ toolkit to accelerate vision, automatic speech recognition, natural language processing, recommendation systems and many other applications.', 293, 65,'', 'Python', '', 'https://github.com/intel-iot-devkit/smart-video-workshop'))

    this.repos.push(new Repo('IoT Developer Kit samples', 'Intel System Studio project code samples using the Intel® IoT Developer Kit libraries.', 79, 68,'', 'C++', '', 'https://github.com/intel-iot-devkit/iot-devkit-samples'))

    this.repos.push(new Repo('People Counter', 'Create a smart video application using the Intel Distribution of OpenVINO toolkit. The toolkit uses models and inference to run single-class object detection.', 76, 44, '', 'Python', '', 'https://github.com/intel-iot-devkit/people-counter-python'))

    this.repos.push(new Repo('Terasic DE10 Nano Development Kit Samples', 'Code samples for the DE10-Nano Developer Kit', 70, 35, '', 'C', '', 'https://github.com/intel-iot-devkit/terasic-de10-nano-kit'))

    this.repos.push(new Repo('Edge Services', 'This repository provides the source code of an Intel® Smart Edge Open edge Node', 29, 25, '', 'Go', '', 'https://github.com/smart-edge-open/edgeservices'))

    this.repos.push(new Repo('Edge Apps', 'Applications that can be onboarded to an Intel® Smart Edge Open edge node.', 34, 51, '', 'Shell', '', 'https://github.com/smart-edge-open/edgeapps'))

    this.repos.push(new Repo('Converged Edge Experience Kits', 'Source code for experience kits with Ansible-based deployment.', 35, 33, '', 'Jinja', '', 'https://github.com/smart-edge-open/converged-edge-experience-kits'))

    this.repos.push(new Repo('Open Developer Experience Kits', 'Source code for experience kits that use Edge Software Provisioner for deployment.', 1, 4, '', 'Python', '', 'https://github.com/smart-edge-open/open-developer-experience-kits'))

    this.repos.push(new Repo('Open Model Zoo', 'Pre-trained Deep Learning models and demos (high quality and extremely fast)', 2900, 1000, '', 'Python', '', 'https://github.com/openvinotoolkit/open_model_zoo'))

    this.repos.push(new Repo('Training Extensions', 'Trainable models and NN optimization tools', 967, 371, '', 'Python', '', 'https://github.com/openvinotoolkit/training_extensions'))




    this.originalRepos = this.repos
  }

  onKeyUpEvent(event: any){
    /**
     * Search for the repo(s) with the corresponding inputted value across the name, description and language properties (case-sensitive)
     */
    let inputValue = String(event.target.value).toLowerCase();

    this.repos = this.originalRepos.filter(repo => {
      return repo.name.toLowerCase().includes(inputValue) || repo.description.toLowerCase().includes(inputValue) || repo.language.toLowerCase().includes(inputValue);
    });
  }

}
