export class Repo {
    name: string;
    description: string;
    stars: number;
    forks: number;
    imageSrc: string;
    language: string;
    type: string;
    url: string;

    constructor(name: string, description: string, stars: number, forks: number, imageSrc: string, language: string, type: string, url: string) {
        this.name = name;
        this.description = description
        this.stars = stars
        this.forks = forks
        this.imageSrc = imageSrc
        this.language = language
        this.type = type
        this.url = url
    }
}